function [f,grad] = NCE_weighted_obj(param,x,w,y,n,nn)
    n1 = sum(w);
    n2 = size(y,1);
    d = size(x,2);
    q = exp(x*param);
    qq = exp(y*param);
    n = n*n2/n1;
    nn = nn*n2/n1;
    f = -w'*(log(q)-log(q+n))+sum(log(qq+nn));
    grad = -sum((w*ones(1,d)).*x.*((n./(q+n))*ones(1,d)))'+sum(y.*((qq./(qq+nn))*ones(1,d)))';
end

