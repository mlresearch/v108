function [f,grad] = NCE_obj(param,x,y,n,nn)
    n1 = size(x,1);
    n2 = size(y,1);
    d = size(x,2);
    q = exp(x*param);
    qq = exp(y*param);
    n = n*n2/n1;
    nn = nn*n2/n1;
    f = -sum(log(q)-log(q+n))+sum(log(qq+nn));
    grad = -sum(x.*((n./(q+n))*ones(1,d)))'+sum(y.*((qq./(qq+nn))*ones(1,d)))';
end

