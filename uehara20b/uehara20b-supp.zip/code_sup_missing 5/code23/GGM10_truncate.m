EPS = 10^-6;
nmc = 100;
d = 10;
E = d*(d-1)/2;
n = 1000;
num_impute = 100;
m = 1000;
invSIGMA = zeros(d,d);
invSIGMA(1:3,1:3) = [1 .5 .5; .5 1 .5; .5 .5 1];
invSIGMA(4:6,4:6) = [1 .5 .5; .5 1 .5; .5 .5 1];
invSIGMA(7:9,7:9) = [1 .5 .5; .5 1 .5; .5 .5 1];
invSIGMA(10,10) = 1;
SIGMA = inv(invSIGMA);
param = [-d/2*log(2*pi)-log(det(SIGMA))/2-log(qsimvn(10^5,SIGMA,zeros(d,1),inf*ones(d,1))); -diag(invSIGMA)/2; zeros(d*(d-1)/2,1)];
k = d+2;
for i=1:d
    for j=i+1:d
        param(k) = -invSIGMA(i,j);
        k = k+1;
    end
end
est_NCE = zeros(d+E+1,nmc);
est_FINCE = zeros(d+E+1,nmc);
coverage_FINCE = zeros(1,d+E+1);
test_FINCE = zeros(1,d+E+1);
est_SCORE = zeros(d+E,nmc);
est_FISCORE = zeros(d+E,nmc);
coverage_FISCORE = zeros(1,d+E);
test_FISCORE = zeros(1,d+E);
for mc=1:nmc
    mc
    x = zeros(n,d);
    k = 1;
    while k <= n
        tmp = mvnrnd(zeros(1,d),SIGMA,n);
        ok = sum(sign(tmp),2)==d;
        x(k:k+nnz(ok)-1,:) = tmp(ok,:);
        k = k+nnz(ok);
    end
    x = x(1:n,:);
    always_obs = [1 2 4 5 7 8 10];
    obs3 = 1-binornd(1,1./(3+exp(x(:,always_obs)*randn(7,1))));
    x(obs3==0,3) = inf;
    obs6 = 1-binornd(1,1./(3+exp(x(:,always_obs)*randn(7,1))));
    x(obs6==0,6) = inf;
    obs9 = 1-binornd(1,1./(3+exp(x(:,always_obs)*randn(7,1))));
    x(obs9==0,9) = inf;
    x0 = x;
    meanx = zeros(1,d);
    for i=1:d
        tmp = x(:,i);
        meanx(i) = mean(tmp(tmp<inf));
    end
    y = exprnd(ones(m,1)*meanx);
    % impute
    x = zeros(n*num_impute,d);
    for i=1:n
        x((i-1)*num_impute+1:i*num_impute,:) = ones(num_impute,1)*x0(i,:);
        if obs3(i) == 0
            x((i-1)*num_impute+1:i*num_impute,3) = abs(2*randn(num_impute,1));
        end
        if obs6(i) == 0
            x((i-1)*num_impute+1:i*num_impute,6) = abs(2*randn(num_impute,1));
        end
        if obs9(i) == 0
            x((i-1)*num_impute+1:i*num_impute,9) = abs(2*randn(num_impute,1));
        end
    end
    % FINCE
    X = [ones(n*num_impute,1) x.^2 zeros(n*num_impute,E)];
    Y = [ones(m,1) y.^2 zeros(m,E)];
    k = d+2;
    for i=1:d
        for j=i+1:d
            X(:,k) = x(:,i).*x(:,j);
            Y(:,k) = y(:,i).*y(:,j);
            k = k+1;
        end
    end
    w = zeros(n*num_impute,1);
    cnt_FINCE = 0;
    while true
        prev = est_FINCE(:,mc);
        for i=1:n
            w((i-1)*num_impute+1:i*num_impute) = exp(X((i-1)*num_impute+1:i*num_impute,:)*prev);
            if obs3(i) == 0
                w((i-1)*num_impute+1:i*num_impute) = w((i-1)*num_impute+1:i*num_impute)./normpdf(x((i-1)*num_impute+1:i*num_impute,3),0,2);
            end
            if obs6(i) == 0
                w((i-1)*num_impute+1:i*num_impute) = w((i-1)*num_impute+1:i*num_impute)./normpdf(x((i-1)*num_impute+1:i*num_impute,6),0,2);
            end
            if obs9(i) == 0
                w((i-1)*num_impute+1:i*num_impute) = w((i-1)*num_impute+1:i*num_impute)./normpdf(x((i-1)*num_impute+1:i*num_impute,9),0,2);
            end
            w((i-1)*num_impute+1:i*num_impute) = w((i-1)*num_impute+1:i*num_impute)/sum(w((i-1)*num_impute+1:i*num_impute));
        end
        est_FINCE(:,mc) = minimize_noshow(est_FINCE(:,mc),'NCE_weighted_obj',10000,X,w,Y,prod(exppdf(x,ones(n*num_impute,1)*meanx),2),prod(exppdf(y,ones(m,1)*meanx),2));
        cnt_FINCE = cnt_FINCE+1;
        if norm(est_FINCE(:,mc)-prev) < EPS
            cnt_FINCE
            break
        end
    end
        nablad = zeros(d+E+1,n*num_impute);
        nablan = zeros(d+E+1,m);
        for i=1:n*num_impute
            nablad(:,i) = -m*prod(exppdf(x(i,:),meanx))/(n*exp(X(i,:)*est_FINCE(:,mc))+m*prod(exppdf(x(i,:),meanx)))*X(i,:)';
        end
        nablad_mean = nablad*w/n;
        for j=1:m
            nablan(:,j) = n*exp(Y(j,:)*est_FINCE(:,mc))/(n*exp(Y(j,:)*est_FINCE(:,mc))+m*prod(exppdf(y(j,:),meanx)))*Y(j,:)';
        end
        nablan_mean = mean(nablan,2);
        J = zeros(d+E+1,d+E+1);
        for i=1:n
            tmp = nablad(:,(i-1)*num_impute+1:i*num_impute)*w((i-1)*num_impute+1:i*num_impute)-nablad_mean;
            J = J+(tmp*tmp')/(n+m);
        end
        for j=1:m
            tmp = nablan(:,j)-nablan_mean;
            J = J+(tmp*tmp')/(n+m);
        end
        I = zeros(d+E+1,d+E+1);
        for i=1:n*num_impute
            I = I+w(i)*n*exp(X(i,:)*est_FINCE(:,mc))*m*prod(exppdf(x(i,:),meanx))/(n*exp(X(i,:)*est_FINCE(:,mc))+m*prod(exppdf(x(i,:),meanx)))^2*X(i,:)'*X(i,:);
        end
        for i=1:n
            tmp = nablad(:,(i-1)*num_impute+1:i*num_impute)*w((i-1)*num_impute+1:i*num_impute);
            for ii=1:num_impute
                I = I+w((i-1)*num_impute+ii)*(nablad(:,(i-1)*num_impute+ii)-tmp)*X(i,:);
            end
        end
        for j=1:m
            I = I+n*exp(Y(j,:)*est_FINCE(:,mc))*m*prod(exppdf(y(j,:),meanx))/(n*exp(Y(j,:)*est_FINCE(:,mc))+m*prod(exppdf(y(j,:),meanx)))^2*Y(j,:)'*Y(j,:);
        end
        I = I/(n+m);
        %{
        I = zeros(d+E+1,d+E+1);
        for i=1:n
            I = I+(nablad(:,(i-1)*num_impute+1:i*num_impute)*w((i-1)*num_impute+1:i*num_impute))*(w((i-1)*num_impute+1:i*num_impute)'*X((i-1)*num_impute+1:i*num_impute,:))/n;
        end
        %}
    var_est = inv(I)*J*inv(I)'/n;
    for j=1:d+E+1
        if abs(est_FINCE(j,mc)-param(j)) < 1.96*sqrt(var_est(j,j))
            coverage_FINCE(j) = coverage_FINCE(j)+1;
        end
        if abs(est_FINCE(j,mc)) > 1.96*sqrt(var_est(j,j))
            test_FINCE(j) = test_FINCE(j)+1;
        end
    end
    k = d+2;
    for i=1:d
        for j=i+1:d
            if abs(est_FINCE(k,mc)) > 1.96*sqrt(var_est(k,k))
                [i,j]
            end
            k = k+1;
        end
    end
    13
    % FISCORE
    X = X(:,2:end);
    w = zeros(n*num_impute,1);
    h = zeros(n*num_impute,d*(d+1)/2,d);
    h2 = zeros(n*num_impute,d*(d+1)/2,d);
    for j=1:d
        h(:,j,j) = 2*x(:,j);
        kk = d+1;
        for k=1:d
            for l=k+1:d
                if k==j
                    h(:,kk,j) = x(:,l);
                end
                if l==j
                    h(:,kk,j) = x(:,k);
                end
                kk = kk+1;
            end
        end
        h2(:,j,j) = 2;
    end
    cnt_FISCORE = 0;
    while true
        prev = est_FISCORE(:,mc);
        for i=1:n
            w((i-1)*num_impute+1:i*num_impute) = exp(X((i-1)*num_impute+1:i*num_impute,:)*prev);
            if obs3(i) == 0
                w((i-1)*num_impute+1:i*num_impute) = w((i-1)*num_impute+1:i*num_impute)./normpdf(x((i-1)*num_impute+1:i*num_impute,3),0,2);
            end
            if obs6(i) == 0
                w((i-1)*num_impute+1:i*num_impute) = w((i-1)*num_impute+1:i*num_impute)./normpdf(x((i-1)*num_impute+1:i*num_impute,6),0,2);
            end
            if obs9(i) == 0
                w((i-1)*num_impute+1:i*num_impute) = w((i-1)*num_impute+1:i*num_impute)./normpdf(x((i-1)*num_impute+1:i*num_impute,9),0,2);
            end
            w((i-1)*num_impute+1:i*num_impute) = w((i-1)*num_impute+1:i*num_impute)/sum(w((i-1)*num_impute+1:i*num_impute));
        end
        A = zeros(d*(d+1)/2,d*(d+1)/2);
        b = zeros(d*(d+1)/2,1);
        for j=1:d
            for i=1:n*num_impute
                A = A+x(i,j)^2*h(i,:,j)'*h(i,:,j)*w(i)/n;
                b = b+(x(i,j)^2*h2(i,:,j)'+2*x(i,j)*h(i,:,j)')*w(i)/n;
            end
        end
        est_FISCORE(:,mc) = -A\b;
        cnt_FISCORE = cnt_FISCORE+1;
        if norm(est_FISCORE(:,mc)-prev) < EPS
            cnt_FISCORE
            break
        end
    end
    I = A;
    for i=1:n
        tmp = zeros(d*(d+1)/2,num_impute);
        for ii=1:num_impute
            AA = zeros(d*(d+1)/2,d*(d+1)/2);
            bb = zeros(d*(d+1)/2,1);
            for j=1:d
                AA = AA+x((i-1)*num_impute+ii,j)^2*h((i-1)*num_impute+ii,:,j)'*h((i-1)*num_impute+ii,:,j);
                bb = bb+(x((i-1)*num_impute+ii,j)^2*h2((i-1)*num_impute+ii,:,j)'+2*x((i-1)*num_impute+ii,j)*h((i-1)*num_impute+ii,:,j)');
            end
            tmp(:,ii) = AA*est_FISCORE(:,mc)+bb;
        end
        for ii=1:num_impute
            I = I+w((i-1)*num_impute+ii)*tmp(:,ii)*X((i-1)*num_impute+ii,:)/n;
        end
        I = I-tmp*w((i-1)*num_impute+1:i*num_impute)*w((i-1)*num_impute+1:i*num_impute)'*X((i-1)*num_impute+1:i*num_impute,:)/n;
    end
    J = zeros(d*(d+1)/2,d*(d+1)/2);
    for i=1:n*num_impute
        AA = zeros(d*(d+1)/2,d*(d+1)/2);
        bb = zeros(d*(d+1)/2,1);
        for j=1:d
            AA = AA+x(i,j)^2*h(i,:,j)'*h(i,:,j);
            bb = bb+(x(i,j)^2*h2(i,:,j)'+2*x(i,j)*h(i,:,j)');
        end
%        I2 = I2+(AA*est_FISCORE(:,mc)+bb)*X(i,:)*w(i)/n;
        J = J+(AA*est_FISCORE(:,mc)+bb)*(AA*est_FISCORE(:,mc)+bb)'*w(i)/n;
    end
    var_est = inv(I)*J*inv(I)'/n;
    for j=1:d+E
        if abs(est_FISCORE(j,mc)-param(j+1)) < 1.96*sqrt(var_est(j,j))
            coverage_FISCORE(j) = coverage_FISCORE(j)+1;
        end
        if abs(est_FISCORE(j,mc)) > 1.96*sqrt(var_est(j,j))
            test_FISCORE(j) = test_FISCORE(j)+1;
        end
    end
    k = d+1;
    for i=1:d
        for j=i+1:d
            if abs(est_FISCORE(k,mc)) > 1.96*sqrt(var_est(k,k))
                [i,j]
            end
            k = k+1;
        end
    end
    dsfsd
end
mse_FINCE = mean((est_FINCE-param*ones(1,nmc)).^2,2);
mse_FISCORE = mean((est_FISCORE-param(2:end)*ones(1,nmc)).^2,2);
FP_FINCE = 0;
FN_FINCE = 0;
FP_FISCORE = 0;
FN_FISCORE = 0;
k = d+2;
for i=1:d
    for j=i+1:d
        if invSIGMA(i,j) == 0
            FN_FINCE = FN_FINCE+100-test_FINCE(k);
        else
            FP_FINCE = FP_FINCE+test_FINCE(k);
        end
        k = k+1;
    end
end
k = d+1;
for i=1:d
    for j=i+1:d
        if invSIGMA(i,j) == 0
            FN_FISCORE = FN_FISCORE+100-test_FISCORE(k);
        else
            FP_FISCORE = FP_FISCORE+test_FISCORE(k);
        end
        k = k+1;
    end
end
save('GGM_truncate');
