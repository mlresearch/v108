dat = csvread('tokyo_wind_2018.csv');
EPS = 10^-6;
d = 6;
n = 365;
x0 = zeros(n,2);
x0(:,1) = dat(1:24:end)/16*2*pi;
x0(:,2) = dat(12:24:end)/16*2*pi;
m = 1000;
y = rand(m,2)*2*pi;
% NCE on full data
est_NCE_full = minimize(randn(d,1),'bvM_obj',10000,x0,y,ones(n,1)/4/pi^2,ones(m,1)/4/pi^2);
est_NCE_full(3) = mod(est_NCE_full(3),2*pi);
est_NCE_full(5) = mod(est_NCE_full(5),2*pi);
if est_NCE_full(2) < 0
    est_NCE_full(2) = -est_NCE_full(2);
    est_NCE_full(3) = mod(est_NCE_full(3)-pi,2*pi);
    est_NCE_full(6) = -est_NCE_full(6);
end
if est_NCE_full(4) < 0
    est_NCE_full(4) = -est_NCE_full(4);
    est_NCE_full(5) = mod(est_NCE_full(5)-pi,2*pi);
    est_NCE_full(6) = -est_NCE_full(6);
end
    xx = [ones(n,1) cos(x0(:,1)-est_NCE_full(3)) est_NCE_full(2)*sin(x0(:,1)-est_NCE_full(3))-est_NCE_full(6)*cos(x0(:,1)-est_NCE_full(3)).*sin(x0(:,2)-est_NCE_full(5)) cos(x0(:,2)-est_NCE_full(5)) est_NCE_full(4)*sin(x0(:,2)-est_NCE_full(5))-est_NCE_full(6)*sin(x0(:,1)-est_NCE_full(3)).*cos(x0(:,2)-est_NCE_full(5)) sin(x0(:,1)-est_NCE_full(3)).*sin(x0(:,2)-est_NCE_full(5))];
    yy = [ones(m,1) cos(y(:,1)-est_NCE_full(3)) est_NCE_full(2)*sin(y(:,1)-est_NCE_full(3))-est_NCE_full(6)*cos(y(:,1)-est_NCE_full(3)).*sin(y(:,2)-est_NCE_full(5)) cos(y(:,2)-est_NCE_full(5)) est_NCE_full(4)*sin(y(:,2)-est_NCE_full(5))-est_NCE_full(6)*sin(y(:,1)-est_NCE_full(3)).*cos(y(:,2)-est_NCE_full(5)) sin(y(:,1)-est_NCE_full(3)).*sin(y(:,2)-est_NCE_full(5))];
    s1 = sin(x0(:,1)-est_NCE_full(3));
    s2 = sin(x0(:,2)-est_NCE_full(5));
    c1 = cos(x0(:,1)-est_NCE_full(3));
    c2 = cos(x0(:,2)-est_NCE_full(5));
    ss1 = sin(y(:,1)-est_NCE_full(3));
    ss2 = sin(y(:,2)-est_NCE_full(5));
    cc1 = cos(y(:,1)-est_NCE_full(3));
    cc2 = cos(y(:,2)-est_NCE_full(5));
    q = exp(est_NCE_full(1)+est_NCE_full(2)*cos(x0(:,1)-est_NCE_full(3))+est_NCE_full(4)*cos(x0(:,2)-est_NCE_full(5))+est_NCE_full(6)*sin(x0(:,1)-est_NCE_full(3)).*sin(x0(:,2)-est_NCE_full(5)));
    qq = exp(est_NCE_full(1)+est_NCE_full(2)*cos(y(:,1)-est_NCE_full(3))+est_NCE_full(4)*cos(y(:,2)-est_NCE_full(5))+est_NCE_full(6)*sin(y(:,1)-est_NCE_full(3)).*sin(y(:,2)-est_NCE_full(5)));
        nablad = zeros(d,n);
        nablan = zeros(d,m);
        for i=1:n
            nablad(:,i) = -m/4/pi^2/(n*q(i)+m/4/pi^2)*xx(i,:)';
        end
        nablad_mean = mean(nablad,2);
        for j=1:m
            nablan(:,j) = n*qq(j)/(n*qq(j)+m/4/pi^2)*yy(j,:)';
        end
        nablan_mean = mean(nablan,2);
        J = zeros(d,d);
        for i=1:n
            tmp = nablad(:,i)-nablad_mean;
            J = J+(tmp*tmp')/(n+m);
        end
        for j=1:m
            tmp = nablan(:,j)-nablan_mean;
            J = J+(tmp*tmp')/(n+m);
        end
        I = zeros(d,d);
        Hess = zeros(d,d);
        for i=1:n
            I = I+n*q(i)*m/4/pi^2/(n*q(i)+m/4/pi^2)^2*xx(i,:)'*xx(i,:);
            Hess(2,:) = [0 0 s1(i) 0 0 0];
            Hess(3,:) = [0 s1(i) -est_NCE_full(2)*c1(i)-est_NCE_full(6)*s1(i)*s2(i) 0 est_NCE_full(6)*c1(i)*c2(i) -c1(i)*s2(i)];
            Hess(4,:) = [0 0 0 0 s2(i) 0];
            Hess(5,:) = [0 0 est_NCE_full(6)*c1(i)*c2(i) s2(i) -est_NCE_full(4)*c2(i)+est_NCE_full(6)*s1(i)*s2(i) -s1(i)*c2(i)];
            Hess(6,:) = [0 0 -c1(i)*s2(i) 0 -s1(i)*c2(i) 0];
            I = I-m/4/pi^2/(n*q(i)+m/4/pi^2)*Hess;
        end
        for j=1:m
            I = I+n*qq(j)*m/4/pi^2/(n*qq(j)+m/4/pi^2)^2*yy(j,:)'*yy(j,:);
            Hess(2,:) = [0 0 ss1(j) 0 0 0];
            Hess(3,:) = [0 ss1(j) -est_NCE_full(2)*cc1(j)-est_NCE_full(6)*ss1(j)*ss2(j) 0 est_NCE_full(6)*cc1(j)*cc2(j) -cc1(j)*ss2(j)];
            Hess(4,:) = [0 0 0 0 ss2(j) 0];
            Hess(5,:) = [0 0 est_NCE_full(6)*cc1(j)*cc2(j) ss2(j) -est_NCE_full(4)*cc2(j)+est_NCE_full(6)*ss1(j)*ss2(j) -ss1(j)*cc2(j)];
            Hess(6,:) = [0 0 -cc1(j)*ss2(j) 0 -ss1(j)*cc2(j) 0];
            I = I+n*qq(j)/(n*qq(j)+m/4/pi^2)*Hess;
        end
        I = I/(n+m);
        var_est_NCE_full = inv(I)*J*inv(I)'/n;
conf_NCE_full = [est_NCE_full-1.96*sqrt(diag(var_est_NCE_full)) est_NCE_full+1.96*sqrt(diag(var_est_NCE_full))];
% missing
%nobs = 200; % fully observed
obs2 = ones(n,1);
for i=1:n
    if rand < 1/(1+exp(cos(x0(i,1))))
        obs2(i) = 0;
    end
end
nobs = sum(obs2); % fully observed
%rp = randperm(n);
% NCE on complete data
x = x0(obs2==1,:);
est_NCE_CC = minimize(randn(d,1),'bvM_obj',10000,x,y,ones(nobs,1)/4/pi^2,ones(m,1)/4/pi^2);
est_NCE_CC(3) = mod(est_NCE_CC(3),2*pi);
est_NCE_CC(5) = mod(est_NCE_CC(5),2*pi);
if est_NCE_CC(2) < 0
    est_NCE_CC(2) = -est_NCE_CC(2);
    est_NCE_CC(3) = mod(est_NCE_CC(3)-pi,2*pi);
    est_NCE_CC(6) = -est_NCE_CC(6);
end
if est_NCE_CC(4) < 0
    est_NCE_CC(4) = -est_NCE_CC(4);
    est_NCE_CC(5) = mod(est_NCE_CC(5)-pi,2*pi);
    est_NCE_CC(6) = -est_NCE_CC(6);
end
    xx = [ones(nobs,1) cos(x(:,1)-est_NCE_CC(3)) est_NCE_CC(2)*sin(x(:,1)-est_NCE_CC(3))-est_NCE_CC(6)*cos(x(:,1)-est_NCE_CC(3)).*sin(x(:,2)-est_NCE_CC(5)) cos(x(:,2)-est_NCE_CC(5)) est_NCE_CC(4)*sin(x(:,2)-est_NCE_CC(5))-est_NCE_CC(6)*sin(x(:,1)-est_NCE_CC(3)).*cos(x(:,2)-est_NCE_CC(5)) sin(x(:,1)-est_NCE_CC(3)).*sin(x(:,2)-est_NCE_CC(5))];
    yy = [ones(m,1) cos(y(:,1)-est_NCE_CC(3)) est_NCE_CC(2)*sin(y(:,1)-est_NCE_CC(3))-est_NCE_CC(6)*cos(y(:,1)-est_NCE_CC(3)).*sin(y(:,2)-est_NCE_CC(5)) cos(y(:,2)-est_NCE_CC(5)) est_NCE_CC(4)*sin(y(:,2)-est_NCE_CC(5))-est_NCE_CC(6)*sin(y(:,1)-est_NCE_CC(3)).*cos(y(:,2)-est_NCE_CC(5)) sin(y(:,1)-est_NCE_CC(3)).*sin(y(:,2)-est_NCE_CC(5))];
    s1 = sin(x(:,1)-est_NCE_CC(3));
    s2 = sin(x(:,2)-est_NCE_CC(5));
    c1 = cos(x(:,1)-est_NCE_CC(3));
    c2 = cos(x(:,2)-est_NCE_CC(5));
    ss1 = sin(y(:,1)-est_NCE_CC(3));
    ss2 = sin(y(:,2)-est_NCE_CC(5));
    cc1 = cos(y(:,1)-est_NCE_CC(3));
    cc2 = cos(y(:,2)-est_NCE_CC(5));
    q = exp(est_NCE_CC(1)+est_NCE_CC(2)*cos(x(:,1)-est_NCE_CC(3))+est_NCE_CC(4)*cos(x(:,2)-est_NCE_CC(5))+est_NCE_CC(6)*sin(x(:,1)-est_NCE_CC(3)).*sin(x(:,2)-est_NCE_CC(5)));
    qq = exp(est_NCE_CC(1)+est_NCE_CC(2)*cos(y(:,1)-est_NCE_CC(3))+est_NCE_CC(4)*cos(y(:,2)-est_NCE_CC(5))+est_NCE_CC(6)*sin(y(:,1)-est_NCE_CC(3)).*sin(y(:,2)-est_NCE_CC(5)));
        nablad = zeros(d,nobs);
        nablan = zeros(d,m);
        for i=1:nobs
            nablad(:,i) = -m/4/pi^2/(nobs*q(i)+m/4/pi^2)*xx(i,:)';
        end
        nablad_mean = mean(nablad,2);
        for j=1:m
            nablan(:,j) = nobs*qq(j)/(nobs*qq(j)+m/4/pi^2)*yy(j,:)';
        end
        nablan_mean = mean(nablan,2);
        J = zeros(d,d);
        for i=1:nobs
            tmp = nablad(:,i)-nablad_mean;
            J = J+(tmp*tmp')/(nobs+m);
        end
        for j=1:m
            tmp = nablan(:,j)-nablan_mean;
            J = J+(tmp*tmp')/(nobs+m);
        end
        I = zeros(d,d);
        Hess = zeros(d,d);
        for i=1:nobs
            I = I+nobs*q(i)*m/4/pi^2/(nobs*q(i)+m/4/pi^2)^2*xx(i,:)'*xx(i,:);
            Hess(2,:) = [0 0 s1(i) 0 0 0];
            Hess(3,:) = [0 s1(i) -est_NCE_CC(2)*c1(i)-est_NCE_CC(6)*s1(i)*s2(i) 0 est_NCE_CC(6)*c1(i)*c2(i) -c1(i)*s2(i)];
            Hess(4,:) = [0 0 0 0 s2(i) 0];
            Hess(5,:) = [0 0 est_NCE_CC(6)*c1(i)*c2(i) s2(i) -est_NCE_CC(4)*c2(i)+est_NCE_CC(6)*s1(i)*s2(i) -s1(i)*c2(i)];
            Hess(6,:) = [0 0 -c1(i)*s2(i) 0 -s1(i)*c2(i) 0];
            I = I-m/4/pi^2/(nobs*q(i)+m/4/pi^2)*Hess;
        end
        for j=1:m
            I = I+nobs*qq(j)*m/4/pi^2/(nobs*qq(j)+m/4/pi^2)^2*yy(j,:)'*yy(j,:);
            Hess(2,:) = [0 0 ss1(j) 0 0 0];
            Hess(3,:) = [0 ss1(j) -est_NCE_CC(2)*cc1(j)-est_NCE_CC(6)*ss1(j)*ss2(j) 0 est_NCE_CC(6)*cc1(j)*cc2(j) -cc1(j)*ss2(j)];
            Hess(4,:) = [0 0 0 0 ss2(j) 0];
            Hess(5,:) = [0 0 est_NCE_CC(6)*cc1(j)*cc2(j) ss2(j) -est_NCE_CC(4)*cc2(j)+est_NCE_CC(6)*ss1(j)*ss2(j) -ss1(j)*cc2(j)];
            Hess(6,:) = [0 0 -cc1(j)*ss2(j) 0 -ss1(j)*cc2(j) 0];
            I = I+nobs*qq(j)/(nobs*qq(j)+m/4/pi^2)*Hess;
        end
        I = I/(nobs+m);
        var_est_NCE_CC = inv(I)*J*inv(I)'/nobs;
conf_NCE_CC = [est_NCE_CC-1.96*sqrt(diag(var_est_NCE_CC)) est_NCE_CC+1.96*sqrt(diag(var_est_NCE_CC))];
% FINCE
num_impute = 100;
x = zeros(n*num_impute,2);
for i=1:n
    if obs2(i) == 1
        x((i-1)*num_impute+1:i*num_impute,:) = ones(num_impute,1)*x0(i,:);
    else
        x((i-1)*num_impute+1:i*num_impute,:) = [x0(i,1)*ones(num_impute,1) rand(num_impute,1)*2*pi];
    end
end
w = zeros(n*num_impute,1);
cnt = 0;
est_FINCE = est_NCE_CC;
while true
        prev = est_FINCE;
        for i=1:n
            w((i-1)*num_impute+1:i*num_impute) = exp(prev(1)+prev(2)*cos(x((i-1)*num_impute+1:i*num_impute,1)-prev(3))+prev(4)*cos(x((i-1)*num_impute+1:i*num_impute,2)-prev(5))+prev(6)*sin(x((i-1)*num_impute+1:i*num_impute,1)-prev(3)).*sin(x((i-1)*num_impute+1:i*num_impute,2)-prev(5)));
            w((i-1)*num_impute+1:i*num_impute) = w((i-1)*num_impute+1:i*num_impute)/sum(w((i-1)*num_impute+1:i*num_impute));
        end
        est_FINCE = minimize(est_FINCE,'bvM_weighted_obj',10000,x,w,y,ones(n*num_impute,1)/4/pi^2,ones(m,1)/4/pi^2);
        cnt = cnt+1;
        cnt,norm(est_FINCE-prev)
        if norm(est_FINCE-prev) < EPS
            cnt
            break
        end
    end
est_FINCE(3) = mod(est_FINCE(3),2*pi);
est_FINCE(5) = mod(est_FINCE(5),2*pi);
if est_FINCE(2) < 0
    est_FINCE(2) = -est_FINCE(2);
    est_FINCE(3) = mod(est_FINCE(3)-pi,2*pi);
    est_FINCE(6) = -est_FINCE(6);
end
if est_FINCE(4) < 0
    est_FINCE(4) = -est_FINCE(4);
    est_FINCE(5) = mod(est_FINCE(5)-pi,2*pi);
    est_FINCE(6) = -est_FINCE(6);
end
    xx = [ones(n*num_impute,1) cos(x(:,1)-est_FINCE(3)) est_FINCE(2)*sin(x(:,1)-est_FINCE(3))-est_FINCE(6)*cos(x(:,1)-est_FINCE(3)).*sin(x(:,2)-est_FINCE(5)) cos(x(:,2)-est_FINCE(5)) est_FINCE(4)*sin(x(:,2)-est_FINCE(5))-est_FINCE(6)*sin(x(:,1)-est_FINCE(3)).*cos(x(:,2)-est_FINCE(5)) sin(x(:,1)-est_FINCE(3)).*sin(x(:,2)-est_FINCE(5))];
    yy = [ones(m,1) cos(y(:,1)-est_FINCE(3)) est_FINCE(2)*sin(y(:,1)-est_FINCE(3))-est_FINCE(6)*cos(y(:,1)-est_FINCE(3)).*sin(y(:,2)-est_FINCE(5)) cos(y(:,2)-est_FINCE(5)) est_FINCE(4)*sin(y(:,2)-est_FINCE(5))-est_FINCE(6)*sin(y(:,1)-est_FINCE(3)).*cos(y(:,2)-est_FINCE(5)) sin(y(:,1)-est_FINCE(3)).*sin(y(:,2)-est_FINCE(5))];
    s1 = sin(x(:,1)-est_FINCE(3));
    s2 = sin(x(:,2)-est_FINCE(5));
    c1 = cos(x(:,1)-est_FINCE(3));
    c2 = cos(x(:,2)-est_FINCE(5));
    ss1 = sin(y(:,1)-est_FINCE(3));
    ss2 = sin(y(:,2)-est_FINCE(5));
    cc1 = cos(y(:,1)-est_FINCE(3));
    cc2 = cos(y(:,2)-est_FINCE(5));
    q = exp(est_FINCE(1)+est_FINCE(2)*cos(x(:,1)-est_FINCE(3))+est_FINCE(4)*cos(x(:,2)-est_FINCE(5))+est_FINCE(6)*sin(x(:,1)-est_FINCE(3)).*sin(x(:,2)-est_FINCE(5)));
    qq = exp(est_FINCE(1)+est_FINCE(2)*cos(y(:,1)-est_FINCE(3))+est_FINCE(4)*cos(y(:,2)-est_FINCE(5))+est_FINCE(6)*sin(y(:,1)-est_FINCE(3)).*sin(y(:,2)-est_FINCE(5)));
        nablad = zeros(d,n*num_impute);
        nablan = zeros(d,m);
        for i=1:n*num_impute
            nablad(:,i) = -m/4/pi^2/(n*q(i)+m/4/pi^2)*xx(i,:)';
        end
        nablad_mean = nablad*w/n;
        for j=1:m
            nablan(:,j) = n*qq(j)/(n*qq(j)+m/4/pi^2)*yy(j,:)';
        end
        nablan_mean = mean(nablan,2);
        J = zeros(d,d);
        for i=1:n
            tmp = nablad(:,(i-1)*num_impute+1:i*num_impute)*w((i-1)*num_impute+1:i*num_impute)-nablad_mean;
            J = J+(tmp*tmp')/(n+m);
        end
        for j=1:m
            tmp = nablan(:,j)-nablan_mean;
            J = J+(tmp*tmp')/(n+m);
        end
        I = zeros(d,d);
        Hess = zeros(d,d);
        for i=1:n*num_impute
            I = I+w(i)*n*q(i)*m/4/pi^2/(n*q(i)+m/4/pi^2)^2*xx(i,:)'*xx(i,:);
            Hess(2,:) = [0 0 s1(i) 0 0 0];
            Hess(3,:) = [0 s1(i) -est_FINCE(2)*c1(i)-est_FINCE(6)*s1(i)*s2(i) 0 est_FINCE(6)*c1(i)*c2(i) -c1(i)*s2(i)];
            Hess(4,:) = [0 0 0 0 s2(i) 0];
            Hess(5,:) = [0 0 est_FINCE(6)*c1(i)*c2(i) s2(i) -est_FINCE(4)*c2(i)+est_FINCE(6)*s1(i)*s2(i) -s1(i)*c2(i)];
            Hess(6,:) = [0 0 -c1(i)*s2(i) 0 -s1(i)*c2(i) 0];
            I = I-w(i)*m/4/pi^2/(n*q(i)+m/4/pi^2)*Hess;
        end
        for i=1:n
            tmp = nablad(:,(i-1)*num_impute+1:i*num_impute)*w((i-1)*num_impute+1:i*num_impute);
            for ii=1:num_impute
                I = I+w((i-1)*num_impute+ii)*(nablad(:,(i-1)*num_impute+ii)-tmp)*xx((i-1)*num_impute+ii,:);
            end
        end
        for j=1:m
            I = I+n*qq(j)*m/4/pi^2/(n*qq(j)+m/4/pi^2)^2*yy(j,:)'*yy(j,:);
            Hess(2,:) = [0 0 ss1(j) 0 0 0];
            Hess(3,:) = [0 ss1(j) -est_FINCE(2)*cc1(j)-est_FINCE(6)*ss1(j)*ss2(j) 0 est_FINCE(6)*cc1(j)*cc2(j) -cc1(j)*ss2(j)];
            Hess(4,:) = [0 0 0 0 ss2(j) 0];
            Hess(5,:) = [0 0 est_FINCE(6)*cc1(j)*cc2(j) ss2(j) -est_FINCE(4)*cc2(j)+est_FINCE(6)*ss1(j)*ss2(j) -ss1(j)*cc2(j)];
            Hess(6,:) = [0 0 -cc1(j)*ss2(j) 0 -ss1(j)*cc2(j) 0];
            I = I+n*qq(j)/(n*qq(j)+m/4/pi^2)*Hess;
        end
        I = I/(n+m);
        var_est_FINCE = inv(I)*J*inv(I)'/n;
conf_FINCE = [est_FINCE-1.96*sqrt(diag(var_est_FINCE)) est_FINCE+1.96*sqrt(diag(var_est_FINCE))];
pval_dep = 2*(1-normcdf(abs(est_FINCE(6)/sqrt(var_est_FINCE(6,6)))));
pval_same = 2*(1-normcdf(abs(est_FINCE(3)-est_FINCE(5))/sqrt(var_est_FINCE(3,3)+var_est_FINCE(5,5))));
pval_same2 = 2*(1-normcdf(abs(est_FINCE(2)-est_FINCE(4))/sqrt(var_est_FINCE(2,2)+var_est_FINCE(4,4))));
% for TeX
for i=2:6
    str = sprintf('[%.2f,%.2f] & [%.2f,%.2f] & [%.2f,%.2f]',conf_FINCE(i,1),conf_FINCE(i,2),conf_NCE_CC(i,1),conf_NCE_CC(i,2),conf_NCE_full(i,1),conf_NCE_full(i,2));
    disp(str);
end
