% bivariate von Mises
function [f,grad] = bvM_weighted_obj(param,x,w,y,n,nn)
    n1 = size(x,1);
    n2 = size(y,1);
    d = length(param);
    q = exp(param(1)+param(2)*cos(x(:,1)-param(3))+param(4)*cos(x(:,2)-param(5))+param(6)*sin(x(:,1)-param(3)).*sin(x(:,2)-param(5)));
    qq = exp(param(1)+param(2)*cos(y(:,1)-param(3))+param(4)*cos(y(:,2)-param(5))+param(6)*sin(y(:,1)-param(3)).*sin(y(:,2)-param(5)));
    n = n*n2/sum(w);
    nn = nn*n2/sum(w);
    f = -w'*(log(q)-log(q+n))+sum(log(qq+nn));
    xx = [ones(n1,1) cos(x(:,1)-param(3)) param(2)*sin(x(:,1)-param(3))-param(6)*cos(x(:,1)-param(3)).*sin(x(:,2)-param(5)) cos(x(:,2)-param(5)) param(4)*sin(x(:,2)-param(5))-param(6)*sin(x(:,1)-param(3)).*cos(x(:,2)-param(5)) sin(x(:,1)-param(3)).*sin(x(:,2)-param(5))];
    yy = [ones(n2,1) cos(y(:,1)-param(3)) param(2)*sin(y(:,1)-param(3))-param(6)*cos(y(:,1)-param(3)).*sin(y(:,2)-param(5)) cos(y(:,2)-param(5)) param(4)*sin(y(:,2)-param(5))-param(6)*sin(y(:,1)-param(3)).*cos(y(:,2)-param(5)) sin(y(:,1)-param(3)).*sin(y(:,2)-param(5))];
    grad = -sum(xx.*((w.*n./(q+n))*ones(1,d)))'+sum(yy.*((qq./(qq+nn))*ones(1,d)))';
end

