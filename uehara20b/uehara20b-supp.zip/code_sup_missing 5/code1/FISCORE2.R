#### FISCORE setting 2
#### Require package ‘tmvtnorm’

sample_n <-500

sample_n2 <- 100
ite <- 50
sigma <- matrix(c(2,1.3,1.3,2.0), ncol=2)
sigma_inv <- solve(matrix(c(2,1.3,1.3,2.0),2,2))

mse_list <- seq(1,1,length.out = ite)
mean_list <- matrix(0,ite,3)
count <- 0.0

for(kkk in 1:ite){
  print(kkk)
  
  ### Whole sample 
  
  sample <- rtmvnorm(sample_n, mean=c(0,0),lower =c(0,0),sigma=sigma)
  
  #### Model 
  
  mix <- function(para,x){
    return(exp(-0.5*(para[1]*x[1]*x[1]+2*para[2]*x[1]*x[2]+para[3]*x[2]*x[2])))
  }
  
  ### Missing data indicator 
  
  delta <- seq(1,1,length.out = sample_n)
  
  logistic <- function(x,location=0.0,scale=1.0){
    return(1/(1+exp(-(x-location)/scale)))
  }
  
  for(iii in 1:sample_n){
    delta[iii] <- rbinom(1,1,logistic(sample[iii,1],location=0.9,scale=0.3))
    ####delta[iii] <- 1
  }
  
  ### Auxi for FI
  sample3 <- rtmvnorm(sample_n2,mean = 0,lower = 0.0,sigma=3.0)
  answer <- c(sigma_inv[1,1],sigma_inv[1,2],sigma_inv[2,2])
  
  ### missing (MAR)
  sample[,2] <- delta*sample[,2]
  
  ### Initial paramter 
  parapara <- answer-0.2
  
  #### Do EM 
  for(iii in 1:13){
    weight <- matrix(0,sample_n,sample_n2)
    weight2 <- matrix(0,sample_n,sample_n2)
    for(i in 1:sample_n){
      for(j in 1:sample_n2){
        weight[i,j] <- mix(parapara,c(sample[i,1],sample3[j]))/dtmvnorm(sample3[j],mean=0,lower = 0,sigma = 3)
      } ### weight
      sumsum <- sum(weight[i,])
      for(j in 1:sample_n2){
        weight2[i,j] <- weight[i,j]/sumsum ### normalized weight 
      }
    }
    
    ### Objective function 
    objective <- function(para,sample_=sample,sample3_=sample3,w=weight2,delta_=delta){
      sum <- 0.0
      for(i in 1:sample_n){
        if(delta_[i]==0){
          for(j in 1:sample_n2){
            ttt <- c(sample_[i,1],sample3_[j])
            sum <- sum + w[i,j]*(-2*ttt[1]*sum(ttt*c(para[1],para[2]))-(ttt[1]**2)*(para[1])+0.5*(sum(ttt*c(para[1],para[2]))**2)*(ttt[1]**2))
            sum <- sum + w[i,j]*(-2*ttt[2]*sum(ttt*c(para[2],para[3]))-(ttt[2]**2)*(para[3])+0.5*(sum(ttt*c(para[2],para[3]))**2)*(ttt[2]**2))
          }
        }
        else{
          sum <- sum - 2*sample_[i,1]*sum(sample[i,]*c(para[1],para[2]))-(sample_[i,1]**2)*(para[1])+0.5*(sum(sample[i,]*c(para[1],para[2]))**2)*(sample_[i,1]**2)
          sum <- sum - 2*sample_[i,2]*sum(sample[i,]*c(para[2],para[3]))-(sample_[i,2]**2)*(para[3])+0.5*(sum(sample[i,]*c(para[2],para[3]))**2)*(sample_[i,2]**2)
        }
      }
      return(sum/sample_n)
    }
    result <-optim(answer,objective,method="L-BFGS-B",lower = answer-3,upper = answer+3)
    print(result$par)
    parapara <- result$par
    
    varivari <- function(para,sample_=sample,sample3_=sample3,w=weight2,delta_=delta){
      listlist_I <- matrix(0:0, nrow = 3, ncol = 3)
      listlist_J <- matrix(0:0, nrow = sample_n, ncol = 3)
      listlist_K <- matrix(0:0, nrow = 3, ncol = 3)
      #### Require package ‘tmvtnorm’
      for(i in 1:sample_n){
        if(delta_[i]==0){
          pesdo <- matrix(0:0,1,3)
          pesdo2 <- matrix(0:0,1,3)
          pesdo3 <- matrix(0:0,3,3)
          for(j in 1:sample_n2){
            pesdo4 <- matrix(0:0,1,3)
            pesdo5 <- matrix(0:0,1,3)
            ttt <- c(sample_[i,1],sample3_[j])
            listlist_I[1,1] <- w[i,j]*ttt[1]**2*(ttt[1]**2)+listlist_I[1,1]
            listlist_I[1,2] <- w[i,j]*ttt[2]*ttt[1]*(ttt[1]**2)+listlist_I[1,2]
            listlist_I[1,3] <- 0 
            
            listlist_I[2,1] <- w[i,j]*ttt[1]*ttt[2]*(ttt[1]**2)+listlist_I[2,1]
            listlist_I[2,2] <- w[i,j]*ttt[2]*ttt[2]*(ttt[1]**2)*2+listlist_I[2,2]
            listlist_I[2,3] <- w[i,j]*ttt[2]*ttt[1]*(ttt[2]**2)+listlist_I[2,3]
            listlist_I[3,1] <- 0
            listlist_I[3,2] <- w[i,j]*ttt[1]*ttt[2]*(ttt[2]**2)+listlist_I[3,2]
            listlist_I[3,3] <- w[i,j]*ttt[2]*ttt[2]*(ttt[2]**2)+listlist_I[3,3]
            
            pesdo[1] <- (-2*ttt[1]*ttt[1]-(ttt[1]**2)+sum(ttt*c(para[1],para[2]))*ttt[1]*(ttt[1]**2))*w[i,j] + pesdo[1]
            pesdo[2] <- (-2*ttt[1]*ttt[2]+sum(ttt*c(para[1],para[2]))*ttt[2]*(ttt[1]**2))*w[i,j] + pesdo[2]
            pesdo[2] <- pesdo[2]+(-2*ttt[2]*ttt[1]+sum(ttt*c(para[2],para[3]))*ttt[1]*(ttt[2]**2))*w[i,j] 
            pesdo[3] <- (-2*ttt[2]*ttt[2]-(ttt[2]**2)+sum(ttt*c(para[2],para[3]))*ttt[2]*(ttt[2]**2))*w[i,j] + pesdo[3]
            
            pesdo2[1] <- -w[i,j]*0.5*ttt[1]**2 + pesdo2[1]
            pesdo2[2] <- -w[i,j]*ttt[2]*ttt[1] + pesdo2[2]
            pesdo2[3] <- -w[i,j]*0.5*ttt[2]**2 + pesdo2[3]
            
            
            pesdo4[1] <- (-2*ttt[1]*ttt[1]-(ttt[1]**2)+sum(ttt*c(para[1],para[2]))*ttt[1]*(ttt[1]**2)) 
            pesdo4[2] <- -2*ttt[1]*ttt[2]+sum(ttt*c(para[1],para[2]))*ttt[2]*(ttt[1]**2)-2*ttt[2]*ttt[1]+sum(ttt*c(para[2],para[3]))*ttt[1]*(ttt[2]**2)
            pesdo4[3] <- (-2*ttt[2]*ttt[2]-(ttt[2]**2)+sum(ttt*c(para[2],para[3]))*ttt[2]*(ttt[2]**2))
            
            pesdo5[1] <- -0.5*ttt[1]**2
            pesdo5[2] <- -ttt[2]*ttt[1]
            pesdo5[3] <- -0.5*ttt[2]**2
            
            pesdo3 <- w[i,j]*t(pesdo4)%*%pesdo5+pesdo[3]
            
            listlist_J[i,1] <- (-2*ttt[1]*ttt[1]-(ttt[1]**2)+sum(ttt*c(para[1],para[2]))*ttt[1]*(ttt[1]**2))*w[i,j]+listlist_J[i,1]
            listlist_J[i,2] <- (-2*ttt[1]*ttt[2]+sum(ttt*c(para[1],para[2]))*ttt[2]*(ttt[1]**2))*w[i,j]+listlist_J[i,2]
            listlist_J[i,2] <- listlist_J[i,2]+(-2*ttt[2]*ttt[1]+sum(ttt*c(para[2],para[3]))*ttt[1]*(ttt[2]**2))*w[i,j]
            listlist_J[i,3] <- (-2*ttt[2]*ttt[2]-(ttt[2]**2)+sum(ttt*c(para[2],para[3]))*ttt[2]*(ttt[2]**2))*w[i,j]+listlist_J[i,3]
          }
          listlist_K <- -t(pesdo)%*%pesdo2+listlist_K 
          listlist_K <- listlist_K + pesdo3
          
        }
        else{
          ######sum <- sum - 2*sample_[i,1]*sum(sample[i,]*c(para[1],para[2]))-(sample_[i,1]**2)*(para[1])+0.5*(sum(sample[i,]*c(para[1],para[2]))**2)*(sample_[i,1]**2)
          listlist_I[1,1] <- sample[i,1]**2*(sample_[i,1]**2)+listlist_I[1,1]
          listlist_I[1,2] <- sample[i,2]*sample[i,1]*(sample_[i,1]**2)+listlist_I[1,2]
          listlist_I[1,3] <- 0 
          listlist_I[2,1] <- sample[i,1]*sample[i,2]*(sample_[i,1]**2)+listlist_I[2,1]
          listlist_I[2,2] <- sample[i,2]*sample[i,2]*(sample_[i,1]**2)*2+listlist_I[2,2]
          listlist_I[2,3] <- sample[i,2]*sample[i,1]*(sample_[i,2]**2)+listlist_I[2,3]
          listlist_I[3,1] <- 0
          listlist_I[3,2] <- sample[i,1]*sample[i,2]*(sample_[i,2]**2)+listlist_I[3,2]
          listlist_I[3,3] <- sample[i,2]*sample[i,2]*(sample_[i,2]**2)+listlist_I[3,3]
          
          listlist_J[i,1] <- -2*sample[i,1]*sample[i,1]-(sample_[i,1]**2)+sum(sample[i,]*c(para[1],para[2]))*sample[i,1]*(sample_[i,1]**2)
          listlist_J[i,2] <- -2*sample[i,1]*sample[i,2]+sum(sample[i,]*c(para[1],para[2]))*sample[i,2]*(sample_[i,1]**2)
          listlist_J[i,2] <- listlist_J[i,2]-2*sample_[i,2]*sample[i,1]+sum(sample[i,]*c(para[2],para[3]))*sample[i,1]*(sample_[i,2]**2)
          listlist_J[i,3] <- -2*sample_[i,2]*sample[i,2]-(sample_[i,2]**2)+sum(sample[i,]*c(para[2],para[3]))*sample[i,2]*(sample_[i,2]**2)
        }
        
      }
      return(list(listlist_I/sample_n,var(listlist_J),listlist_K/sample_n))
    }
    
    
  }
  mse_list[kkk] <- sum((parapara[1:3]-answer[1:3])*(parapara[1:3]-answer[1:3]))
  mean_list[kkk,] <- parapara[1:3]
  ccc <- solve(matrix(unlist(varivari(answer)[1]),3,3))
  ddd <- matrix(unlist(varivari(answer)[2]),3,3)
  eee <- 1/sample_n *ccc %*% ddd %*% ccc 
  if((parapara- answer) %*% solve(eee) %*% (parapara-answer) < qchisq(0.95,3)){
    count <- count + 1
  }
}

ccc <- solve(matrix(unlist(varivari(answer)[1]),3,3))
ddd <- matrix(unlist(varivari(answer)[2]),3,3)
fff <- matrix(unlist(varivari(answer)[3]),3,3)
eee <- 1/sample_n *ccc %*% ddd %*% ccc 


#### MeDIAN MSE 
median(mse_list)
mean(mse_list)
apply(mean_list, 2, median)-answer
