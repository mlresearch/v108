#### FISCORE setting 2
#### Require package ‘tmvtnorm’

sample_n <-500

sample_n2 <- 100
ite <- 1
sigma <- matrix(c(2,1.3,1.3,2.0), ncol=2)
sigma_inv <- solve(matrix(c(2,1.3,1.3,2.0),2,2))

mse_list <- seq(1,1,length.out = ite)
mean_list <- matrix(0,ite,3)
count <- 0.0
answer <- c(sigma_inv[1,1],sigma_inv[1,2],sigma_inv[2,2])

for(kkk in 1:ite){
  print(kkk)
  
  ### Whole sample 
  
  sample <- rtmvnorm(sample_n, mean=c(0,0),lower =c(0,0),sigma=sigma)
  
  #### Model 
  
  mix <- function(para,x){
    return(exp(-0.5*(para[1]*x[1]*x[1]+2*para[2]*x[1]*x[2]+para[3]*x[2]*x[2])))
  }
  
  mix_ <- function(x,y=2.0,para=answer){
    if(x< 0.0){
      z <- -100000000
    }
    else{
      z <- -0.5*(para[1]*x*x+2*para[2]*x*y)
    }
    return(z)
  }
  
  
  ### Missing data indicator 
  
  delta <- seq(1,1,length.out = sample_n)
  
  logistic <- function(x,location=0.0,scale=1.0){
    return(1/(1+exp(-(x-location)/scale)))
  }
  
  for(iii in 1:sample_n){
    delta[iii] <- rbinom(1,1,logistic(sample[iii,2],location=0.9,scale=0.2))
    ###delta[iii] <- 1
  }
  sample3 <- sample
  out <- metrop(mix_, 2.0,scale=0.2,nbatch = 150,blen = 1)
  mat <- matrix(out$batch, nrow = 50, ncol = 3)
}


