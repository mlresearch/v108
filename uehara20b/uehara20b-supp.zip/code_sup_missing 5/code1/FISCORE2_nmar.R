#### FISCORE setting 2
#### Require package ‘tmvtnorm’

sample_n <-500

sample_n2 <- 100
ite <- 50
sigma <- matrix(c(2,1.3,1.3,2.0), ncol=2)
sigma_inv <- solve(matrix(c(2,1.3,1.3,2.0),2,2))

mse_list <- seq(1,1,length.out = ite)
mean_list <- matrix(0,ite,3)
count <- 0.0

for(kkk in 1:ite){
  print(kkk)
  
  ### Whole sample 
  
  sample <- rtmvnorm(sample_n, mean=c(0,0),lower =c(0,0),sigma=sigma)
  
  #### Model 
  
  mix <- function(para,x){
    return(exp(-0.5*(para[1]*x[1]*x[1]+2*para[2]*x[1]*x[2]+para[3]*x[2]*x[2])))
  }
  
  model2 <- function(para,x){
    return(1/(1+exp(-(x-para[1])/para[2])))
  }
  
  ### Missing data indicator 
  
  delta <- seq(1,1,length.out = sample_n)
  
  logistic <- function(x,location=0.0,scale=1.0){
    return(1/(1+exp(-(x-location)/scale)))
  }
  
  for(iii in 1:sample_n){
    delta[iii] <- rbinom(1,1,logistic(sample[iii,2],location=0.9,scale=0.2))
    ###delta[iii] <- 1
  }
  
  ### Auxi for FI
  sample3 <- rtmvnorm(sample_n2,mean = 0,lower = 0.0,sigma=3.0)
  answer <- c(sigma_inv[1,1],sigma_inv[1,2],sigma_inv[2,2])
  answer2 <- c(1.5,0.5)
  
  ### missing (MAR)
  sample[,2] <- sample[,2]*delta
  
  ### Initial paramter 
  parapara <- answer-0.3
  parapara2 <- answer2-0.1
  
  #### Do EM 
  for(iii in 1:30){
    weight <- matrix(0,sample_n,sample_n2)
    weight2 <- matrix(0,sample_n,sample_n2)
    for(i in 1:sample_n){
      for(j in 1:sample_n2){
        weight[i,j] <- mix(parapara,c(sample[i,1],sample3[j]))*(1-model2(parapara2,c(sample3[j])))/dtmvnorm(sample3[j],mean=0,lower = 0,sigma = 3)
      } ### weight
      sumsum <- sum(weight[i,])
      for(j in 1:sample_n2){
        weight2[i,j] <- weight[i,j]/sumsum ### normalized weight 
      }
    }
    
    
    ### Objective function 
    objective <- function(para,sample_=sample,sample3_=sample3,w=weight2,delta_=delta){
      sum <- 0.0
      for(i in 1:sample_n){
        if(delta_[i]==0){
          for(j in 1:sample_n2){
            ttt <- c(sample_[i,1],sample3_[j])
            sum <- sum + w[i,j]*(-2*ttt[1]*sum(ttt*c(para[1],para[2]))-(ttt[1]**2)*(para[1])+0.5*(sum(ttt*c(para[1],para[2]))**2)*(ttt[1]**2))
            sum <- sum + w[i,j]*(-2*ttt[2]*sum(ttt*c(para[2],para[3]))-(ttt[2]**2)*(para[3])+0.5*(sum(ttt*c(para[2],para[3]))**2)*(ttt[2]**2))
          }
        }
        else{
          sum <- sum - 2*sample_[i,1]*sum(sample[i,]*c(para[1],para[2]))-(sample_[i,1]**2)*(para[1])+0.5*(sum(sample[i,]*c(para[1],para[2]))**2)*(sample_[i,1]**2)
          sum <- sum - 2*sample_[i,2]*sum(sample[i,]*c(para[2],para[3]))-(sample_[i,2]**2)*(para[3])+0.5*(sum(sample[i,]*c(para[2],para[3]))**2)*(sample_[i,2]**2)
        }
      }
      return(sum/sample_n)
    }
    objective2 <- function(para,sample_=sample,sample3_=sample3,w=weight2,delta_=delta){
      sum <- 0.0
      for(i in 1:sample_n){
        if(delta_[i]==0){
          for(j in 1:sample_n2){
            sum <- sum - w[i,j]*log(1-model2(para,sample3_[j]))
            sum <- sum - w[i,j]*log(1-model2(para,sample3_[j]))
          }
        }
        else{
          sum <- sum - log(model2(para,sample_[i,2]))
        }
      }
      return(sum/sample_n)
    }

    
    result <-optim(answer,objective,method="L-BFGS-B",lower = answer-3,upper = answer+3)
    result2 <-optim(c(0.9,0.2),objective2)
    
    print(result$par)
    print(result2$par)
    parapara <- result$par
    parapara2 <- result2$par
    
    
    varivari <- function(para,sample_=sample,sample3_=sample3,w=weight2,delta_=delta){
      listlist_I <- matrix(0:0, nrow = 3, ncol = 3)
      listlist_J <- matrix(0:0, nrow = sample_n, ncol = 3)
      for(i in 1:sample_n){
        if(delta_[i]==0){
          
          for(j in 1:sample_n2){
            ttt <- c(sample_[i,1],sample3_[j])
            sum <- sum + w[i,j]*(-2*ttt[1]*sum(ttt*c(para[1],para[2]))-(ttt[1]**2)*(para[1])+0.5*(sum(ttt*c(para[1],para[2]))**2)*(ttt[1]**2))
            listlist_I[1,1] <- w[i,j]*ttt[i,1]**2*(ttt[i,1]**2)+listlist_I[1,1]
            listlist_I[1,2] <- w[i,j]*ttt[i,2]*ttt[i,1]*(ttt[i,1]**2)+listlist_I[1,2]
            listlist_I[1,3] <- 0 
            listlist_I[2,1] <- w[i,j]*ttt[i,1]*ttt[i,2]*(ttt[i,1]**2)+listlist_I[2,1]
            listlist_I[2,2] <- w[i,j]*ttt[i,2]*ttt[i,2]*(ttt[i,1]**2)*2+listlist_I[2,2]
            listlist_I[2,3] <- w[i,j]*ttt[i,2]*ttt[i,1]*(ttt[i,2]**2)+listlist_I[2,3]
            listlist_I[3,1] <- 0
            listlist_I[3,2] <- w[i,j]*ttt[i,1]*ttt[i,2]*(ttt[i,2]**2)+listlist_I[3,2]
            listlist_I[3,3] <- w[i,j]*ttt[i,2]*ttt[i,2]*(ttt[i,2]**2)+listlist_I[3,3]
            
            
            listlist_J[i,1] <- (-2*ttt[i,1]*ttt[i,1]-(ttt[i,1]**2)+sum(ttt[i,]*c(para[1],para[2]))*ttt[i,1]*(ttt[i,1]**2))*w[i,j]+listlist_J[i,1]
            listlist_J[i,2] <- (-2*ttt[i,1]*ttt[i,2]+sum(ttt[i,]*c(para[1],para[2]))*ttt[i,2]*(ttt[i,1]**2))*w[i,j]+listlist_J[i,2]
            listlist_J[i,2] <- listlist_J[i,2]-2*ttt_[i,2]*ttt[i,1]+sum(ttt[i,]*c(para[2],para[3]))*ttt[i,1]*(ttt[i,2]**2)*w[i,j]
            listlist_J[i,3] <- (-2*ttt[i,2]*ttt[i,2]-(ttt[i,2]**2)+sum(ttt[i,]*c(para[2],para[3]))*ttt[i,2]*(ttt[i,2]**2))*w[i,j]+listlist_J[i,3]
          }
        }
        else{
          ######sum <- sum - 2*sample_[i,1]*sum(sample[i,]*c(para[1],para[2]))-(sample_[i,1]**2)*(para[1])+0.5*(sum(sample[i,]*c(para[1],para[2]))**2)*(sample_[i,1]**2)
          listlist_I[1,1] <- sample[i,1]**2*(sample_[i,1]**2)+listlist_I[1,1]
          listlist_I[1,2] <- sample[i,2]*sample[i,1]*(sample_[i,1]**2)+listlist_I[1,2]
          listlist_I[1,3] <- 0 
          listlist_I[2,1] <- sample[i,1]*sample[i,2]*(sample_[i,1]**2)+listlist_I[2,1]
          listlist_I[2,2] <- sample[i,2]*sample[i,2]*(sample_[i,1]**2)*2+listlist_I[2,2]
          listlist_I[2,3] <- sample[i,2]*sample[i,1]*(sample_[i,2]**2)+listlist_I[2,3]
          listlist_I[3,1] <- 0
          listlist_I[3,2] <- sample[i,1]*sample[i,2]*(sample_[i,2]**2)+listlist_I[3,2]
          listlist_I[3,3] <- sample[i,2]*sample[i,2]*(sample_[i,2]**2)+listlist_I[3,3]
          
          listlist_J[i,1] <- -2*sample[i,1]*sample[i,1]-(sample_[i,1]**2)+sum(sample[i,]*c(para[1],para[2]))*sample[i,1]*(sample_[i,1]**2)
          listlist_J[i,2] <- -2*sample[i,1]*sample[i,2]+sum(sample[i,]*c(para[1],para[2]))*sample[i,2]*(sample_[i,1]**2)
          listlist_J[i,2] <- listlist_J[i,2]-2*sample_[i,2]*sample[i,1]+sum(sample[i,]*c(para[2],para[3]))*sample[i,1]*(sample_[i,2]**2)
          listlist_J[i,3] <- -2*sample_[i,2]*sample[i,2]-(sample_[i,2]**2)+sum(sample[i,]*c(para[2],para[3]))*sample[i,2]*(sample_[i,2]**2)
        }
        
      }
      return(list(listlist_I/sample_n,var(listlist_J)))
    }
    
    
  }
  mse_list[kkk] <- sum((parapara[1:3]-answer[1:3])*(parapara[1:3]-answer[1:3]))
  mean_list[kkk,] <- parapara[1:3]
  # ccc <- solve(matrix(unlist(varivari(answer)[1]),3,3))
  # ddd <- matrix(unlist(varivari(answer)[2]),3,3)
  # eee <- 1/sample_n *ccc %*% ddd %*% ccc 
  # if((parapara- answer) %*% solve(ee) %*% (parapara-answer) < qchisq(0.95,3)){
  #   count <- count + 1
  # }
  
}




#### MeDIAN MSE 
median(mse_list)
apply(mean_list, 2, median)-answer
