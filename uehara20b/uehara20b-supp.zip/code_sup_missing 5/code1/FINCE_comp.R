#### FINCE under setting 2
#### Require package ‘tmvtnorm’

sample_n <- 500

sample_n2 <- 100
ite <- 50
sigma <- matrix(c(2,1.3,1.3,2.0), ncol=2)
sigma_inv <- solve(matrix(c(2,1.3,1.3,2.0),2,2))

mse_list <- seq(1,1,length.out = ite)
mean_list <- matrix(0,ite,3)
count <- 0.0

for(kkk in 1:ite){
  print(kkk)
  
  ### Whole sample 
  
  sample <- rtmvnorm(sample_n, mean=c(0,0),lower =c(0,0),sigma=sigma)
  
  #### Model 
  
  mix <- function(para,x){
    return(exp(para[4]-0.5*(para[1]*x[1]*x[1]+2*para[2]*x[1]*x[2]+para[3]*x[2]*x[2])))
  }
  
  model2 <- function(para,x){
    return(1/(1+exp(-(x-para[1])/para[2])))
  }
  
  ### Missing data indicator 
  
  delta <- seq(1,1,length.out = sample_n)
  
  logistic <- function(x,location=0.0,scale=1.0){
    return(1/(1+exp(-(x-location)/scale)))
  }
  
  for(iii in 1:sample_n){
    delta[iii] <- rbinom(1,1,logistic(sample[iii,2],location=0.9,scale=0.3))
    ####delta[iii] <- 1
  }
  ### Auxi 1 for NCE 
  sigma2 <- matrix(c(3,0,0,3), ncol=2)
  sample2 <- rtmvnorm(sample_n, mean=c(0,0), lower=c(0,0), sigma=sigma2)
  
  ### Auxi 2 for FI
  sample3 <- rtmvnorm(sample_n2,mean = 0,lower = 0.0,sigma=3.0)
  answer <- c(sigma_inv[1,1],sigma_inv[1,2],sigma_inv[2,2],-2.5)
  answer2 <- c(0.9,0.3)
  ### missing (MAR)
  sample[,2] <- delta*sample[,2]
  
  ### Initial paramter 
  parapara <- answer-0.2
  parapara2 <- answer2-0.1
  
  ### Density for auxi 1 
  auxi2 <- seq(1,1,length.out = sample_n)
  for(i in 1:sample_n){
    auxi2[i] <- dtmvnorm(sample2[i,],mean=c(0,0),sigma = sigma2)
  }
  auxi3 <- seq(1,1,length.out = sample_n)
  for(i in 1:sample_n){
    auxi3[i] <- dtmvnorm(sample[i,],mean=c(0,0),sigma = sigma2)
  }
  
  for(iii in 1:1){
    ### Objective function  (monte carlo MLE)
    objective <- function(para,sample_=sample,sample2_=sample2,sample3_=sample3,w=weight2,auxi2.=auxi2, auxi3. =auxi3){
      sum <- 0.0
      for(i in 1:sample_n){
        if(delta[i]==1){
          sum <- sum + log(mix(para,c(sample[i,])))
        sum2 <- sum2 + mix(para,sample2[i,])/auxi2.[i]
      }
      return(-sum+sum2)
    }
    
    
    result <-optim(answer,objective,method="L-BFGS-B",lower = answer-3,upper = answer+3)
    
    print(result$par)
    parapara <- result$par
    
  }
  
  
  
  # ccc <- solve(matrix(unlist(varivari(parapara)[1]),4,4))
  # ddd1 <- matrix(unlist(varivari(parapara)[2]),4,4)
  # ddd2 <- matrix(unlist(varivari(parapara)[3]),4,4)
  # eee <- 1/sample_n *ccc %*% (ddd1 +ddd2) %*% ccc 
  # if((parapara[1:3]- answer[1:3]) %*% solve(eee[1:3,1:3]) %*% (parapara[1:3]-answer[1:3]) < qchisq(0.95,3)){
  #   count <- count +1
  # }
  mse_list[kkk] <- sum((parapara[1:3]-answer[1:3])*(parapara[1:3]-answer[1:3]))
  mean_list[kkk,] <- parapara[1:3]
}

#### Mean MSE 
mean(mean_list)
