#### FISCORE setting 2
#### Require package ‘tmvtnorm’

sample_n <- 1000

sample_n2 <- 50
ite <- 50
sigma <- matrix(c(2,1.3,1.3,2.0), ncol=2)
sigma_inv <- solve(matrix(c(2,1.3,1.3,2.0),2,2))

mse_list <- seq(1,1,length.out = ite)
mean_list <- matrix(0,ite,3)

for(kkk in 1:ite){
  print(kkk)
  
  ### Whole sample 
  
  sample <- rtmvnorm(sample_n, mean=c(0,0),lower =c(0,0),sigma=sigma)
  
  #### Model 
  
  mix <- function(para,x){
    return(exp(-0.5*(para[1]*x[1]*x[1]+2*para[2]*x[1]*x[2]+para[3]*x[2]*x[2])))
  }
  
  ### Missing data indicator 
  
  delta <- seq(1,1,length.out = sample_n)
  
  logistic <- function(x,location=0.0,scale=1.0){
    return(1/(1+exp(-(x-location)/scale)))
  }
  
  for(iii in 1:sample_n){
    delta[iii] <- rbinom(1,1,logistic(sample[iii,1],location=0.9,scale=0.3))
  }
  
  ### Auxi for FI
  sample3 <- rtmvnorm(sample_n2,mean = 0,lower = 0.0,sigma=3.0)
  answer <- c(sigma_inv[1,1],sigma_inv[1,2],sigma_inv[2,2])
  
  ### missing (MAR)
  sample4 <- sample[,2]
  sample[,2] <- delta*sample[,2]
  
  ### Initial paramter 
  parapara <- answer
  
  #### Do EM 
  for(iii in 1:1){
    sample3 <- matrix(0,sample_n,sample_n2)
    for(i in 1:sample_n){
      print(i)
      if(delta[i]==0){
      for(j in 1:sample_n2){
        mix_ <- function(x,y=sample[i],para=parapara){
          if(x< 0.0){
            z <- -100000
          }
          else{
            z <- -0.5*(para[3]*x*x+2*para[2]*x*y)
          }
          return(z)
        }
        out <- metrop(mix_,sample[i],scale=0.2,nbatch = 20+sample_n2*4 ,blen = 1)
        mat <- matrix(out$batch, nrow = 2+sample_n2, ncol = 4)
        sample_n3 <- sample_n2+1
        sample3[i,] <- mat[2:sample_n3,1]
        }
      }
    }
    
    ### Objective function 
    objective <- function(para,sample_=sample,sample3_=sample3,delta_=delta){
      sum <- 0.0
      for(i in 1:sample_n){
        if(delta_[i]==0){
          for(j in 1:sample_n2){
            ttt <- c(sample_[i,1],sample3_[i,j])
            sum <- sum + 1.0/sample_n2 * (-2*ttt[1]*sum(ttt*c(para[1],para[2]))-(ttt[1]**2)*(para[1])+0.5*(sum(ttt*c(para[1],para[2]))**2)*(ttt[1]**2))
            sum <- sum + 1.0/sample_n2 *(-2*ttt[2]*sum(ttt*c(para[2],para[3]))-(ttt[2]**2)*(para[3])+0.5*(sum(ttt*c(para[2],para[3]))**2)*(ttt[2]**2))
          }
        }
        else{
          sum <- sum - 2*sample_[i,1]*sum(sample[i,]*c(para[1],para[2]))-(sample_[i,1]**2)*(para[1])+0.5*(sum(sample[i,]*c(para[1],para[2]))**2)*(sample_[i,1]**2)
          sum <- sum - 2*sample_[i,2]*sum(sample[i,]*c(para[2],para[3]))-(sample_[i,2]**2)*(para[3])+0.5*(sum(sample[i,]*c(para[2],para[3]))**2)*(sample_[i,2]**2)
        }
      }
      return(sum/sample_n)
    }
    result <-optim(answer,objective,method="L-BFGS-B",lower = answer-3,upper = answer+3)
    print(result$par)
    parapara <- result$par
    
  }
  mse_list[kkk] <- sum((parapara[1:3]-answer[1:3])*(parapara[1:3]-answer[1:3]))
  mean_list[kkk,] <- parapara[1:3]
}


#### MeDIAN MSE 
median(mse_list)
apply(mean_list, 2, median)-answer
