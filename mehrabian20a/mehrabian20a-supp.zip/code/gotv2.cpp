#include "multiplayer_bandits.h"

//set algorithm's hyperparameters
double epsilon = 0.01;
double c = 1.4;
double c1 = 500;
double c2 = 6000;
double c3 = 6000;
double delta = 0.1;

double rewardObserved [maxM][maxK];	//sum of observed reward during the game
int pullCount [maxM][maxK];		//number of pulls during the game
double mu [maxM][maxK];				//estimated mean
int arm [maxM];						//arm played by a player
double utility [maxM];				//utility of a player in a given round
int rounds;							//keeps track of the number of rounds passed
double obtainedReward;				//keeps track of the total reward obtained by the algorithm

void proceedOneRound() {
	rounds++;
	int wasPulled[maxK];
	int pulledBy[maxK];
	for (int k=1; k<=K; k++) wasPulled[k] = 0;
	for (int m=1; m<=M; m++) {
		utility[m]=0;
		wasPulled[arm[m]]++;
		pulledBy[arm[m]] = m;
	}
	for (int k=1; k<=K; k++)
		if (wasPulled[k]==1) {
			int m = pulledBy[k];
			utility[m] = mu[m][k];
			obtainedReward += U[m][k];
			rewardObserved[m][k] += reward(m,k);
			pullCount[m][k]++;
		}
}

int main() {
	srand(time(0));
	time_t timer;
	time(&timer);
	cout << "Program GoTv2 starts" << endl;
	readParams("params.txt");

	int maxMatching[maxM];
	double bestValue, secondBestValue;
	findTwoMaxMatchings (U, maxMatching, bestValue, secondBestValue);
	cout << "best matching has value = " << bestValue << " and gap = " << bestValue-secondBestValue << endl;

	ofstream output;				//record numbers in a file for plotting later
	
	if (plotting) {
		output.open("output.txt", ofstream::app);
		output << "GoTRegret = [";
	}
	
	for (int T = minT; T<=maxT; T*=Tmultiplier) {
		double totalRegret = 0.0;
		cout << "Running " << runs << " runs with T = " << T << endl;

		for (int run = 1; run <= runs; run++) {
			if (run%20==0) show(run);
			cout.flush();
			
			//initialize variables
			rounds = 0;
			obtainedReward = 0;
			int lastActionPlayed[maxM][maxP];
			int contentCount[maxP][maxM][maxK];
			
			for (int m=1; m<=M; m++)
				for (int k=1; k<=K; k++) {
					rewardObserved [m][k]=0;
					pullCount[m][k] = 0;
					mu[m][k] = 0;
				}
				
			//algorithm actually starts
			for (int p = 1; rounds<T; p++) {
				if (p>=maxP) {
					cerr << "Sorry: this version does not allow more than " << maxP-1 << " epochs ... please increase maxP\n";
					exit(1);
				}
				for (int m=1; m<=M; m++)
					for (int k=1; k<=K; k++)
						contentCount[p][m][k]=0;
				
				//Explore for c1 * p^(delta) rounds
				for (int i=1; i<= round (c1 * pow(p, delta)) && rounds<T; i++) {
					for (int m=1; m<=M && rounds<T; m++)
						arm[m] = uniformlyRandomArm();
					proceedOneRound();
				}
				if (rounds>=T) break;

				//update the estimated means and the maximum mean
				double maxMu[maxM];
				for (int m=1; m<=M; m++) maxMu[m] = mu[m][1];
				for (int m=1; m<=M; m++)
					for (int k=1; k<=K; k++) {
						mu[m][k] = 1.0*rewardObserved[m][k] / pullCount[m][k];
						if (mu[m][k] > maxMu[m]) maxMu[m] = mu[m][k];
					}
				
				//GoT phase: initialize variables
				bool content[maxM];
				int oldArm[maxM];
				for (int m=1; m<=M; m++) {
					content[m] = true;
					if (p>2) {
						oldArm[m] = lastActionPlayed[m][p - (int)floor(p/2) - 1];
					} else {
						oldArm[m] = uniformlyRandomArm();
					}
				}			
				
				//GoT phase starts
				for (int i=1; i<= round(c2 * pow(p, delta)) && rounds<T; i++) {
					//first each player chooses an arm (line (a))
					for (int m=1; m<=M; m++) {
						if (content[m]) {
							if (Bernoulli(pow(epsilon,c)) == 1) {
								//deviate to another arm
								int newArm=oldArm[m];
								while (newArm==oldArm[m])
									newArm = uniformlyRandomArm();
								arm[m] = newArm;
							} else //keep current arm
								arm[m] = oldArm[m];
						} else
							arm[m] = uniformlyRandomArm();
					}
					//then play one round
					proceedOneRound();
					
					//line (b): update the content vector
					for (int m =1; m<=M; m++) {
						if (arm[m]!=oldArm[m] || utility[m]==0 || !content[m]) {
							if (Bernoulli( utility[m] * pow(epsilon, maxMu[m] - utility[m]) / maxMu[m]) == 1)
								content[m] = true;
							else
								content[m] = false;
						}
						if (content[m])
							contentCount[p][m][arm[m]]++;
						oldArm[m] = arm[m];
						lastActionPlayed[m][p] = arm[m];
					}
				}
				
				//exploitation phase: choose the throne for each player
				int contentCountSum[maxM][maxK];
				int bestArm[maxM];
				for (int m=1; m<=M; m++) {
					bestArm[m] = 1;
					for (int k=1; k<=K; k++) {
						contentCountSum[m][k]=0;
						for (int r=0; r<=floor(p/2); r++)
							contentCountSum[m][k]+=contentCount[p-r][m][k];
						if (contentCountSum[m][k] > contentCountSum[m][bestArm[m]]) bestArm[m] = k;
					}
					arm[m] = bestArm[m];
				}
				//exploitation phase: play the throne
				for (int i=1; i<=round(c3 * pow(2,p)) && rounds < T; i++)
					proceedOneRound();
			}
			
			totalRegret += (bestValue * rounds - obtainedReward);
		}
		cout << "average regret over " << runs << " runs was " << 1.0*totalRegret / runs << " with T = " << T << endl;
		
		if (plotting)
			output << setprecision(10) << 1.0*totalRegret/runs << ", ";
	}
	
	if (plotting) {
		output << "]" << endl;
		output << "gotT = [";
		for (int T = minT; T<=maxT; T*=Tmultiplier) output << T << ", ";
		output << "]" << endl << endl; 
		output.close();
	}
	cout << "Program took " << time(NULL) - timer << " seconds to complete" << endl;		
}