#include "multiplayer_bandits.h"

double rewardObserved [maxM][maxK];	//sum of observed reward during the game
int pullCount [maxM][maxK];		//number of pulls during the game
int arm [maxM];						//arm played by a player
int rounds;							//keeps track of the number of rounds passed
double obtainedReward;				//keeps track of the total reward obtained by the algorithm

double machinezero = 1e-8;			//computer truncation error: numbers within distance zero are considered equal

void proceedOneRound() {
	int wasPulled[maxK];
	int pulledBy[maxK];
	zeroOut(wasPulled,K);
	for (int m=1; m<=M; m++) {
		wasPulled[arm[m]]++;
		pulledBy[arm[m]] = m;
		pullCount[m][arm[m]]++;
	}
	for (int k=1; k<=K; k++) {
		if (wasPulled[k]==1) {
			int m = pulledBy[k];
			obtainedReward += U[m][k];
			rewardObserved[m][k] += reward(m,k);
		}
	}
}

int main() {
	time_t timer;
	time(&timer);
	cout << "Program selfishUCB starts" << endl;
	readParams("params.txt");

	int maxMatching[maxM];
	double bestValue, secondBestValue;
	findTwoMaxMatchings (U, maxMatching, bestValue, secondBestValue);
	cout << "best matching has value = " << bestValue << " and gap = " << bestValue-secondBestValue << endl;

	ofstream output;					//record numbers for plotting
	if (plotting) {
		output.open("output.txt",ofstream::app);
		output << "selfishucbRegret = [";
	}
	
	for (int T = minT; T<=maxT; T*=Tmultiplier) {
		double totalRegret = 0.0;
		cout << "Running " << runs << " runs with T = " << T << endl;

		for (int run = 1; run <= runs; run++) {
			if (run%20==0) show(run);
			cout.flush();
			
			//initialize variables
			obtainedReward = 0;
			for (int m=1; m<=M; m++)
				for (int k=1; k<=K; k++) {
					//some initialization is needed to avoid division by zero
					rewardObserved [m][k]=1;
					pullCount[m][k] = 1;
				}
				
			//algorithm starts
			for (rounds=1; rounds<=T; rounds++) {
				double ucb [maxM][maxK];
				
				for (int m =1; m<=M; m++) {
					double bestUCB = -highestPossibleUtility;					
					for (int k=1; k<=K; k++)
						if (BernoulliRewards) {
							ucb[m][k] = 1.0 * rewardObserved [m][k] / pullCount[m][k]
							+ sqrt ((log(K) + 2 * log(M)+ 2*log(T))/(2*pullCount[m][k])  );
							bestUCB = max (ucb[m][k], bestUCB);
						} else if (GaussianRewards) {
							ucb[m][k] = 1.0 * rewardObserved [m][k] / pullCount[m][k]
							+ sqrt (2 * variance*(log(K) + 2 * log(M)+ 2*log(T))/pullCount[m][k]  );
							bestUCB = max (ucb[m][k], bestUCB);							
						} else {
							cerr<< "sorry, only bernoulli and gaussian rewards are supported now!" << endl;
							exit(1);
						}
						
					while (true) {
						arm[m] = uniformlyRandomArm();
						if (ucb[m][arm[m]] >= bestUCB - machinezero) break;
					}
				}
				//play one round
				proceedOneRound();
			}
			totalRegret += (bestValue * T - obtainedReward);
		}
		cout << "average regret over " << runs << " runs was " << 1.0*totalRegret / runs << " with T = " << T << endl;

		if (plotting)
			output << setprecision(10) << 1.0*totalRegret/runs << ", ";
	}
	
	if (plotting) {
		output << "]" << endl; 
		output  << "selfishucbT = [";
		for (int T = minT; T<=maxT; T*=Tmultiplier) output << T << ", ";
		output << "]" << endl << endl;
		output.close();
	}
	cout << "Program took " << time(NULL) - timer << " seconds to complete" << endl;		
}