#include "multiplayer_bandits.h"

const double theta = 0.1;	//a hyperparameter: controls the amount of error introduced by truncation
int c = 1;	//a hyperparameter for the length of epochs

int init ( double failProbReciprocal, int& roundsSpent, double& rewardObtained) {
	int externalRank [maxM+1];				//external ranking of players
	for (int i=1;i<=M;i++) externalRank[i]=0;
	rewardObtained=0;
	
	int musicalChairsLength = floor(K * log(K) + K * log(failProbReciprocal));	
	//first part: musical chairs
	{
		int wasPulled [maxK+1];				//how many players pulled each arm
		int pulledBy [maxK+1];				//which player pulled each arm 
		
		//Musical Chairs algorithm
		for (int round=1; round <= musicalChairsLength; round++) {
			zeroOut(wasPulled,K);
			
			for (int m=1; m<=M; m++) {
				if (externalRank[m] == 0) {
					int randomArm = uniformlyRandomArm();
					wasPulled[randomArm]++;
					pulledBy[randomArm]=m;
				} else {
					wasPulled[externalRank[m]]++;
					pulledBy[externalRank[m]]=m;
				}
			}
			
			for (int k=1; k<=K; k++) {
				if (wasPulled[k]==1) {
					externalRank[pulledBy[k]]=k;
					rewardObtained += U[pulledBy[k]][k];
				}
			}
		}
		
		//check that each player has occupied a distinct arm
		zeroOut(wasPulled,K);
		for (int m=1; m<=M; m++) {
			if (externalRank[m]==0) {
				cout << "Musical chair failed: some player did not find a chair" << endl;
				return -1;
			}
			wasPulled[externalRank[m]]++;
			if (wasPulled[externalRank[m]] > 1) {
				cout << "Musical chair failed: more than one player on a chair" << endl;
				return -1;
			}
		}
	}
	
	//end of musical chair: second part starts: estimation of internal rank and total number of players
	int numberofPulls[2*maxK][maxK];	//records in each of the next 2K-2 rounds, how many times each arm is pulled
	for (int i = 1; i<=2*K-2; i++) for (int j=1;j<=K; j++) numberofPulls[i][j] = 0;
	
	for (int m = 1; m<=M; m++) {
		int k = externalRank[m];
		
		//player m pulls arm k for 2k-2 rounds
		for (int round = 1; round <= 2*k-2; round++) {
			numberofPulls[round][k]++;
		}
		
		for (int round = 2*k-1; round <= K+k-2; round++) {
			//player m pulls arm round-k+2 for all these rounds
			numberofPulls[round][round-k+2]++;
		}
		
		for (int round = K+k-1; round <= 2*K-2; round++) {
			//player m pulls arm 1 for all these rounds
			numberofPulls[round][1]++;
		}
	}

	//estimation of R and M for each player
	int internalR [maxM], internalM [maxM];
	for (int m=1; m<=M; m++) internalR[m]=internalM[m] = 1;
	
	for (int m = 1; m<=M; m++) {
		int k = externalRank[m];
		
		//player m pulls arm k for all these rounds
		for (int round = 1; round <= 2*k-2; round++) {
			if (numberofPulls[round][k]>1) 
				{internalR[m]++;internalM[m]++;}
			else {
				rewardObtained += U[m][k];
			}
		}
		
		//player m pulls arm round-k+2 for all these rounds
		for (int round = 2*k-1; round <= K+k-2; round++) {
			if (numberofPulls[round][round-k+2]>1)
				{internalM[m]++;}
			else
				rewardObtained += U[m][k];
		}

		//player m pulls arm 1 for all these rounds		
		for (int round = K+k-1; round <= 2*K-2; round++) {
			if (numberofPulls[round][1]==1)
				rewardObtained += U[m][1];
		}
	}

	//check that each player has computed R and M correctly
	int occupied [maxM];
	for (int i=1;i<=M;i++) occupied[i]=0;
	for (int m=1;m<=M;m++) {
		if (internalM[m]!=M) {
			cerr << "init failed in finding M " << endl;
			exit(1);
		}
		occupied[internalR[m]]++;
	}
	for (int i=1;i<=M;i++) 
		if (occupied[i]!=1) {
			cerr << "init failed in occupying an internal rank " << i << endl;
			exit(1);
		}
	roundsSpent = musicalChairsLength + 2*K-2;
	
	return 0;
}

int main() {
	cout << "please enter c: ";
	cin >> c;

	time_t timer;
	time(&timer);

	storePowersOfTwo();

	readParams("params.txt");
	cout << "Running M-ETC-Elim with c = " << c << endl;

	ofstream output;						//record numbers for plotting
	if (plotting) {
		output.open("output.txt", ofstream::app);
		output << "metcelimRegretc" << c << " = [";
	}

	int maxMatching[maxM];
	double bestValue, secondBestValue;
	findTwoMaxMatchings (U, maxMatching, bestValue, secondBestValue);
	cout << "best matching has value = " << bestValue << " and gap = " << bestValue-secondBestValue << endl;
	
	for (int T = minT; T<=maxT; T*=Tmultiplier) {
		double totalRegret = 0;
		cout << "Running " << runs << " runs with T = " << T << endl;

		for (int run = 1; run <= runs; run++) {
			if (run%20==0) show(run);
			cout.flush();
			int rounds = 0;
			double rewardObtained = 0;
			
			if (init ((double)K*T, rounds, rewardObtained) != 0) {	
				//init failed! we upper bound the regret by bestValue * T
				totalRegret += bestValue * T;
				continue;
			}
		
			int matchingsToExploreCount = K;
			int matchingToExplore[maxM * maxK][maxM];	//set of matchings to be explored in each epoch
			for (int i=1; i<=K; i++)
				for (int m=1; m<=M; m++)
					matchingToExplore[i][m] = 1+((m + i)%K);
				
			int bestEmpiricalMatching[maxM];
			for (int m=1; m<=M; m++) 
				bestEmpiricalMatching[m] = matchingToExplore[1][m];

			double rewardObserved [maxM][maxK];		//sum of observed reward during the game for each edge
			int pullCount = 0;					//lower bound for number of times any active edge was pulled
			int pullCountForEdge[maxM][maxK];	//number of times a given edge was pulled
			for (int m=1; m<=M; m++)
				for (int k=1; k<=K; k++) {
					rewardObserved [m][k]=0;
					pullCountForEdge[m][k]=0;
				}
				
			bool activeEdges[maxM][maxK];		//set of active (candidate) edges
			for (int m=1; m<=M; m++)
				for (int k=1; k<=K; k++)
					activeEdges[m][k] = true;	//initially all edges are active (candidate)

			for (int p = 1;rounds<T ; p++) {
				//explore: each player pulls each arm twopower[p^c] times
				if (pow(p,c) > twoPowerMax || 
				rounds + matchingsToExploreCount * twoPower((int)pow(p,c)) >= T) {
					//special case: game will end during exploration
					double valueOfMatchingsToExplore = 0;
					for (int i=1; i<=matchingsToExploreCount; i++)
						for (int m = 1; m<=M; m++)
							valueOfMatchingsToExplore += U[m][matchingToExplore[i][m]];
						
					rewardObtained += valueOfMatchingsToExplore * 1.0 * (T - rounds) / matchingsToExploreCount;
					rounds = T;
					break;
				}
				
				int explorationCountForEachEdge = twoPower((int)pow(p,c));
				for (int m=1;m<=M; m++)
					for (int i=1;i<=matchingsToExploreCount; i++) {
						for (int j = 1; j<=explorationCountForEachEdge; j++) {
							rewardObserved[m][matchingToExplore[i][m]] += reward(m,matchingToExplore[i][m]);
							rewardObtained += U[m][matchingToExplore[i][m]];
						}
						pullCountForEdge[m][matchingToExplore[i][m]] += explorationCountForEachEdge;
					}
				rounds += matchingsToExploreCount * explorationCountForEachEdge;
				if (rounds>=T) break;
				pullCount += explorationCountForEachEdge;
				//end of exploration
		
				//start of first communication
				double epsilon;	//upper bound for error in estimation of each edge, whp
				if (BernoulliRewards) {
					epsilon = sqrt((log (M)*2 + log(T) + log(K))/(2*pullCount) );
				} else if (GaussianRewards) {
					epsilon = sqrt(2 * variance * (log (M)*2 + log(T) + log(K))/pullCount );
				} else {
					cerr << "Error: rewards must be either Bernoulli or Gaussian!" << endl;
					exit(1);
				}
				int b = (int)ceil (-log2(theta * epsilon));	
				//the number of bits for truncation so that the amount of error introduced by truncation < theta * epsilon

				double mutilde[maxM][maxK];	//estimated and truncated arm means
				for (int m=2; m<=M; m++)
					for (int k=1; k<=K; k++)
						if (activeEdges[m][k])
							mutilde[m][k] = truncate(1.0*rewardObserved[m][k]/pullCountForEdge[m][k], b);	
						else
							mutilde[m][k] = -M * highestPossibleUtility;//set to -infinity for inactive edges

				for (int k=1; k<=K; k++)
					if (activeEdges[1][k])
						mutilde[1][k] = 1.0*rewardObserved[1][k]/pullCountForEdge[1][k];//leader does not need truncation
					else
						mutilde[1][k] = -M * highestPossibleUtility;
					
				//communicate: players send the estimates to leader, while others pull best empirical matching
				for (int m = 2; m<= M; m++)
					rewardObtained += U[m][bestEmpiricalMatching[m]]*(M-2) * b;
				rounds += b * (M-1);
				if (rounds >= T) break;
				//end of first communication

				//leader updates the set of active edges and the set of matching to explore
				double bestEmpiricalMatchingValue;
				int newBestEmpiricalMatching[maxM];
				findMaxMatching (mutilde, newBestEmpiricalMatching, bestEmpiricalMatchingValue);

				bool coveredEdges[maxM][maxK];		//set of covered edges
				for (int m=1; m<=M; m++)
					for (int k=1; k<=K; k++)
						coveredEdges[m][k] = false;
				
				//add the best empirical matching to the set of matchings to be explored, and marks its edges as covered
				matchingsToExploreCount = 1;
				for (int m=1; m<=M; m++) {
					matchingToExplore[1][m] = newBestEmpiricalMatching[m];
					coveredEdges[m][newBestEmpiricalMatching[m]] = true;
				}
				
				//for each edge, check whether it must still be active, and if yes, find a good matching covering it
				for (int m=1; m<=M; m++)
					for (int k=1; k<=K; k++) 
						if (activeEdges[m][k] && !coveredEdges[m][k]) {
							//find the max matching containing edge [m][k]
							mutilde[m][k] += 2 * M * highestPossibleUtility;
							
							double bestValueContainingThisEdge;
							int bestMatchingContainingThisEdge[maxM];
							findMaxMatching (mutilde, bestMatchingContainingThisEdge, bestValueContainingThisEdge);
							
							mutilde[m][k] -= 2 * M * highestPossibleUtility;
							bestValueContainingThisEdge -= 2 * M * highestPossibleUtility;
							if (bestValueContainingThisEdge < bestEmpiricalMatchingValue - 2 * (1+theta) * M * epsilon) {
								activeEdges[m][k] = false;	//this edge is useless, forget about it!
							}
							else {
								matchingsToExploreCount++;
								for (int m=1; m<=M; m++) {
									matchingToExplore[matchingsToExploreCount][m] = bestMatchingContainingThisEdge[m];
									coveredEdges[m][bestMatchingContainingThisEdge[m]] = true;
								}
							}
						}
				
				//second communication: the leader sends to the players the list of matchings to be explored
				int bitsToCommunicate = (int) (ceil(log2(M*K)) + matchingsToExploreCount* ceil(log2(M)) );
	
				//the leader communicates the (updated) set of matchings to explore
				for (int m = 2; m<= M; m++)
					rewardObtained += U[m][bestEmpiricalMatching[m]]*(M-2) * bitsToCommunicate;
				rounds += bitsToCommunicate * (M-1);
				
				for (int m=1; m<=M; m++)
					bestEmpiricalMatching[m] = matchingToExplore[1][m];
				
				if (rounds >= T) 
					break;	//time is up!

				if (matchingsToExploreCount == 1) 
					break;	//optimal matching has been found!
			}
			
			//exploit
			if (rounds < T) {
				for (int m = 1; m<= M; m++)
					rewardObtained += U[m][bestEmpiricalMatching[m]] * (T-rounds);
				rounds = T;
			}
			totalRegret += (bestValue * rounds - rewardObtained);
		}
		
		cout << "With T = " << T << ", average regret over " << runs << " runs was " << 1.0*totalRegret/runs << endl;
	
		if (plotting)
			output << setprecision(10) << 1.0*totalRegret/runs << ", ";
	}
	
	if (plotting) {
		output << "]" << endl; 
		output << "metcelimTc" << c << " = [";
		for (int T = minT; T<=maxT; T*=Tmultiplier) output << T << ", ";
		output << "]" << endl << endl; 
		output.close();
	}
	cout << "Program took " << time(NULL) - timer << " seconds to complete" << endl;		
}