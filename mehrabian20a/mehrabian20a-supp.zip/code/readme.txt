In this folder you can find three C++ source files m-etc-elim.cpp, gotv2.cpp, and selfish.cpp, which implement the algorithms M-ETC-Elim (proposed by this paper), Game-Of-Thrones (https://arxiv.org/abs/1810.11162v3), and Selfish-UCB (described in the paper). There is also a utility file multiplayer_bandits.h which is used by the three files.

Input format: the input must be put in the file params.txt, and here is an example input:
2 3 
0.1   0.05  0.9
0.1   0.25  0.3
Gaussian 0.05
1000 10 100000
10
The first line indicates we have 2 players and 3 arms. In the next two lines, the reward matrix is given (one line per player). In the following line, the rewards distribution appears: it is either "Gaussian" followed by a variance, or just "Bernoulli". In the next line, we see the time horizons for which the simulations are run: in this example, the time horizons are 1000, 10000, and 100000 (the first number is the smallest one, the second one is a multiplier, and the third one is the largest one). In the next line, the number of runs per time horizon is written, which is 10 in this example.

Moreoever, the algorithm M-ETC-Elim also has a hyperparameter c, which is read from the standard input when this program is executed.