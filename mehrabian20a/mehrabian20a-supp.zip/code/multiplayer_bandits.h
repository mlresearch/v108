#include <iostream>
#include <cmath>
#include <ctime>
#include <string>
#include <fstream>
#include <random>
#include <chrono>
#include <climits>
#include <iomanip>
using namespace std;

#define double long double
#define show(x) cout << #x << "= " << x << endl;
const bool plotting = false;					//record numbers in a file for plotting?

const int maxK = 20;
const int maxM = 20;
const int maxP = 30;
const double highestPossibleUtility = 10;

int M    ;						//number of players
int K    ;						//number of arms
double U[maxM][maxK]; 			//arms utilities for players
int runs;						//number of runs for each T

int minT, maxT, Tmultiplier; //time horizons to study

bool BernoulliRewards = false;
bool GaussianRewards = false;
double variance = -1;

int twopower[100];
int twoPowerMax = 1;

int twoPower(int p) {
	if (p > twoPowerMax) {
		cerr << "Error: cannot compute 2^" << p << endl;
		exit(1);
	} else return twopower[p];
}

inline void storePowersOfTwo() {
	twopower[0] = 1;
	while (true) {
		twopower[twoPowerMax] = twopower[twoPowerMax-1]*2;
		if (twopower[twoPowerMax] <= 0 || twopower[twoPowerMax] >= LLONG_MAX) {
			twoPowerMax--;
			break;
		}
		twoPowerMax++;
	}
}

inline void zeroOut (int array[], int length) {
	for (int i=1; i<=length; i++) array[i]=0;
}
inline void zeroOut (double array[], int length) {
	for (int i=1; i<=length; i++) array[i]=0.0;
}
inline int max(int a, int b) {
	return a>b ? a : b;
}
inline double max(double a, double b) {
	return a>b ? a : b;
}
inline int min(int a, int b) {
	return a<b ? a : b;
}
inline double min(double a, double b) {
	return a<b ? a : b;
}

//receives a number between 0 and 1, returns the b most significant bits
double truncate(double number, int b) {
	if (number <=0) return 0;
	if (number >=1) return 1;
	return ((double)((int)(1.0*number * twoPower(b))) / twoPower(b));
}

default_random_engine generator (1);

//returns a uniformly random arm
int uniformlyRandomArm () {
	uniform_int_distribution<int> distribution(1,K);
	return distribution(generator);
}

//returns a uniformly random player
int uniformlyRandomPlayer () {
	uniform_int_distribution<int> distribution(1,M);
	return distribution(generator);
}

//generate Bernoulli random variable with mean p
int Bernoulli (double p) {
	bernoulli_distribution distribution(p);
	if (distribution(generator)) return 1; else return 0;
}

double Gaussian(double mean, double variance) {
	normal_distribution<double> distribution (mean,sqrt(variance));
	return distribution(generator);
}

void readParams(string filename) {
	ifstream input;
	input.open(filename);
	if (!input) {cerr << "Unable to open file " << filename; exit(1);}
	input >> M >> K;
	cout << "Players = " << M << endl;
	cout << "Arms = " << K << endl;
	
	if (K >= maxK || M >= maxM) {
		cerr << "Error: current code assumes at most " << maxK-1 << " arms and " << maxM-1 << " players,";
		cerr << " but it's easy to change it to support more! Fix the constants maxK and maxM in the source file!\n";
		exit(1);
	}
	
	if (M>K) {
		cerr << "Warning: number of players > number of arms ... are you sure?" << endl;
		exit(1);
	}
	
	for (int i=1; i<=M; i++)
		for (int j=1; j<=K; j++) {
			input >> U[i][j];
			if (U[i][j] > highestPossibleUtility || U[i][j] < 0) {
				cerr << "0 <= utilities <= " << highestPossibleUtility << " is required in this version: please update these constants!\n";
				exit(1);
			}
		}
	
	//permute the rows of U randomly
	double V [maxM][maxK];
	int used[maxM];
	zeroOut(used,M);
	for (int m=1; m<=M; m++) {
		int n;
		while (true) {
			n = uniformlyRandomPlayer();
			if (used[n]==0) break;
		}
		for (int k=1; k<=K; k++) 
			V[m][k] = U[n][k];
		used[n]=1;
	}
	for (int m=1; m<=M; m++)
		for (int k=1; k<=K; k++)
			U[m][k] = V[m][k];
	
	cout << "Utility matrix:" << endl;
	
	for (int i=1; i<=M; i++) {
		for (int j=1; j<=K; j++)
			cout << U[i][j] << " ";
		cout << endl;
	}	
	
	string rewardType;
	input >> rewardType;
	
	if (rewardType == "Bernoulli" || rewardType == "bernoulli")
		BernoulliRewards = true;
	else if (rewardType == "Gaussian" || rewardType == "gaussian" || rewardType == "normal"|| rewardType == "Normal") {
		GaussianRewards = true;
		input >> variance;
	} else {
		cerr << "I could not find the reward distribution: enter either bernoulli or gaussian\n";
		exit(1);
	}
	
	input >> minT >> Tmultiplier >> maxT;
	cout << "time horizons " << minT << " to " << maxT << " with multiplier = " << Tmultiplier << endl;

	input >> runs;
	cout << "Number of runs = " << runs << endl;
	
	input.close();
	cout << "parameters read successfully, now the algorithm starts...\n\n";
	
	unsigned seed = chrono::system_clock::now().time_since_epoch().count();
	cout << "random seed = " << seed << endl;
	generator.seed(seed);
}

//returns the utility of a matching
double value(double matrix[][maxK], int matching[]) {
	double answer = 0;
	int pulled[maxK];
	zeroOut(pulled,K);
	for (int i=1;i<=M;i++) {
		pulled[matching[i]]++; 
		if (pulled[matching[i]]>1) return -M*highestPossibleUtility;
		answer+=matrix[i][matching[i]];
	}
	return answer;
}

//finds the maximum matching and its value (uses brute force search at the moment!)
void findMaxMatching (double matrix[][maxK], int maxMatching[], double& bestValue) {
	int candidate [maxM];
	for (int i=1; i<=M; i++) candidate[i] = i;
	bestValue = -highestPossibleUtility*M;
	
	while (true) {
		double candidateValue = value(matrix, candidate);
		if (candidateValue > bestValue) {
			bestValue = candidateValue;
			for (int i=1; i<=M; i++) maxMatching[i]=candidate[i];
		}

		//find next matching
		int indexToMove = M;
		while (candidate[indexToMove] == K) indexToMove--;
		if (indexToMove<=0) break;
		candidate[indexToMove]++;
		for (int i=indexToMove+1; i<=M; i++) candidate[i] = i-indexToMove;
	}
}

//finds the two best matchings of the matrix (using a very slow, brute force algorithm at the moment!)
void findTwoMaxMatchings 
	(double matrix[][maxK], int* maxMatching, double& bestValue, double& secondBestValue) {
			findMaxMatching(matrix, maxMatching, bestValue);

			secondBestValue = -M*highestPossibleUtility;
			for (int m = 1; m <= M; m++) {
				matrix[m][maxMatching[m]] -= M*highestPossibleUtility;				
				//temporarily mask this entry: find the best matching without using this entry
				
				int tempMaxMatching[maxM];
				double tempBestValue;
				findMaxMatching (matrix, tempMaxMatching, tempBestValue);
				secondBestValue = max (secondBestValue,tempBestValue);
				matrix[m][maxMatching[m]] += M*highestPossibleUtility;
			}
}

//generate random reward with mean U[m][k] with Bernoulli/Gaussian distribution
double reward (int m, int k) {
	if (!(BernoulliRewards^GaussianRewards)) {
		cerr << "Error: Bernoulli rewards or Gaussian rewards?!\n";
		exit(1);
	}
	if (BernoulliRewards)
		return Bernoulli(U[m][k]);
	else
		return Gaussian(U[m][k], variance);
}