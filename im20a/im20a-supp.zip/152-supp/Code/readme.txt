- In this folder, you can find the C++ codes for the 7 algorithms discussed in the paper. 
- All codes are g++ 4.2 friendly. 
- After running the codes, proper comments are printed on the screen to guide you on the input format. We bring them below as well.
- Input: each code takes
	- the number of instances (n)
	- the dimension (d)
	- the number of clusters (k)
	- the number of noisy instances aka outliers (z)
	- the directory of the input file (i.e. /home/owner/inputfile.txt)
	* the input file should have n rows and d columns. values in each row must be separated by space.
	- the input file name
	- the directory of the ground truth outliers file (i.e. /home/owner/outliersfile.txt)
	* this file should have z values from 0 to n-1, separated by space, indicating the labels of the outliers.
	- the outliers file name
	- the destination of the outputted-centers file (i.e. /home/owner/MyCentersfile.txt)
	* this file will be filled by k rows and d columns, each row indicating a center outputted by the algorithm. The values in each row are separated by space
	- the desired file name for the outputted-centers
	- the directory of the outputted-outliers file. (i.e. /home/owner/MyOutliersfile.txt)
	* this file will be filled by z values from 0 to n-1, separated by space, each indicating the label of an outlier outputted by the algorithm.
	- The desired file name for the outputted-outliers

Each algorithm's code also outputs the number of correctly detected outliers, the precision, the algorithm's objective and the running time (seconds).