'''class for Environment'''

__version__ = "0.1"

class Environment:
    def __init__(self): pass
