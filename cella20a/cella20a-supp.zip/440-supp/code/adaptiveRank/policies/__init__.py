''' Policies for the non-stationary bandit  model'''

__version__ = "0.1"
