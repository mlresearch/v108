class Policy:
    def __init__(self, MOD, T):
        pass
    
    def choice(self, arms):
        pass

    def update(self, choice, rwd, delay):
        pass
