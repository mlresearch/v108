'''Generic Arm'''

__version__ = "0.1"

from .Arm import Arm

