'''Generic Arm'''
__version__ = "0.1"

class Arm:
    def __init__(self, mean, gamma, maxDelay):
        pass

    def draw(self, currentDelay, repIndex):
        pass

    def computeState(self, currentDelay):
        pass
