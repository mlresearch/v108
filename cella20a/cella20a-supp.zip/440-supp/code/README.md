# Rested Bandits with Delay Dependent Payout. R2DEP.
Install the adaptiveRank package with its requirements. Run the commands:
```
python setup.py
source adaptiveRank/bin/activate
```

Run a single experiment:
```
source adaptiveRank/bin/activate
python run.py
```
