# SEPG code

How to install (tested on Ubuntu 18):

```bash
apt-get update
apt-get install python3 python3-pip
pip3 install -e .
```

Scripts for reproducing the experiments are provided.


