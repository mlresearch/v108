#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from gym.envs.registration import register
from gym import spaces

register(
    id='ContCartPole-v0',
    entry_point='potion.envs.cartpole:ContCartPole'
)

register(
    id='LQG1D-v0',
    entry_point='potion.envs.lqg1d:LQG1D'
)
