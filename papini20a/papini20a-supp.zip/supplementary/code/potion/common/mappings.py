#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import torch.nn as nn
import potion.common.torch_utils as tu

class LinearMapping(tu.FlatModule):
    def __init__(self, d_in, d_out, bias=False):
        """
        Linear mapping (single fully-connected layer with linear activations)
        
        d_in: input dimension
        d_out: output dimension
        bias: whether to use a bias parameter (default: false)
        """
        super(LinearMapping, self).__init__()
        self.d_in = d_in
        self.d_out = d_out
        self.linear = nn.Linear(d_in, d_out, bias)
        
    def forward(self, x):
        return self.linear(x)
        
    
"""
Testing
"""
if __name__ == '__main__':
    import torch
    m = LinearMapping(2,2, bias=False)
    m.set_from_flat(torch.tensor([1,2,3,4]))    
    for p in m.parameters():
        print(p)
    print(m.num_params())
    print(m.get_flat())
    m.save_flat('../../logs/y.pt')
    m.load_from_flat('../../logs/x.pt')
    print(m.get_flat())
    m.load_from_flat('../../logs/y.pt')
    print(m.get_flat())
    
