#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import math

class InfiniteHorizonConfidence:
    def __init__(self, delta):
        self.delta = delta
    def next(self, t):
        return 6 * self.delta / (math.pi ** 2 + t ** 2)
