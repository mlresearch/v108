#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Sep 29 16:49:22 2019

@author: zandieh
"""
import numpy as np
from numpy import linalg as LA

def LSHLaplaceFindBuckets(x,w,z):
    n=x.shape[0]
    d=x.shape[1]
    h= np.around((x-z)/w)
    
    buckets = [np.arange(0, n, 1)]
    
    hash_buckets = np.matmul(h,np.random.randint(n, size=d))
    uniq, idx = np.unique(hash_buckets, return_inverse=True)
    L = [[] for i in range(len(uniq))]
    
    for i in range(n):
        L[idx[i]].append(buckets[0][i])
        
    for i in range(len(L)):
        L[i] = np.array(L[i])
    return L

#    for l in range(d):
#        lenbuckets = len(buckets)
#        for j in range(lenbuckets):
#            
#            bucketcontent = h[buckets[j],l]
#            
#            uniq, idx = np.unique(bucketcontent, return_inverse=True)
#            L = [[] for i in range(len(uniq))]
#            
#            for i in range(len(buckets[j])):
#                L[idx[i]].append(buckets[j][i])
#                
#            for i in range(len(L)):
#                L[i] = np.array(L[i])
#            
#            buckets[j] = L[0]
#            
#            if len(L)>1:
#                buckets = buckets + L[1:len(L)]
#    
#    return buckets



def GenKernel(v, s, x):
    if v==0:
        return np.exp(-LA.norm(x, 1, axis=1)/s)
    
    
    if v==1:
        k = np.ones(x.shape[0])
        for i in range(x.shape[1]):
            k = np.multiply(k,(2*np.exp(-np.abs(x[:,i])/(s)) - 8*np.exp(-np.abs(x[:,i])/(2*s)) - 243*np.exp(-np.abs(x[:,i])/(3*s)) + 1536*np.exp(-np.abs(x[:,i])/(4*s)) - 3125*np.exp(-np.abs(x[:,i])/(5*s)) + 1944*np.exp(-np.abs(x[:,i])/(6*s)))/106)
        return k
    
    if v==2:
        return np.exp(-(LA.norm(x, 2, axis=1)**2)/s)
    
    if v==3:
        return (1+LA.norm(x, 2, axis=1)/s+((LA.norm(x, 2, axis=1)/s)**2)/3)*np.exp(-LA.norm(x, 2, axis=1)/s)
    
    
    return 0


def KernelExact(x,b,s,v):
    
    n=x.shape[0]
    y = np.zeros(b.shape)
    
    for i in range(n):
        y[i] = np.inner(GenKernel(v, s, x-x[i,:]),b)
    
    return y



def LSHLaplaceMatMul(buckets,b,m):
    n = len(b)
    
    
    y = np.zeros(n)
    
    y = np.zeros(b.shape)
    for j in range(len(buckets)):
        
        y[buckets[j]] = y[buckets[j]] + np.sum(b[buckets[j]])/m
    
    return y 


