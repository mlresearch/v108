#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 29 12:15:56 2019

@author: zandieh
"""
import os 

import numpy as np
from numpy import linalg as LA
import time

def MaternKernel(v, s, x):
    
    if v==1:
        return (1+LA.norm(x, 2, axis=1)/s)*np.exp(-LA.norm(x, 2, axis=1)/s)
    if v==2:
        return (1+LA.norm(x, 2, axis=1)/s+((LA.norm(x, 2, axis=1)/s)**2)/3)*np.exp(-LA.norm(x, 2, axis=1)/s)
    if v==3:
        return np.exp(-(LA.norm(x, 2, axis=1)**2)/s)
    return 0

def GenKernel(v, s, x):
    if v==0:
        return np.exp(-LA.norm(x, 1, axis=1)/s)
    
    if v==1:
        k = np.ones(x.shape[0])
        for i in range(x.shape[1]):
            k = np.multiply(k,(2*np.exp(-np.abs(x[:,i])/(s)) - 16*np.exp(-np.abs(x[:,i])/(2*s)) + 6075000*np.exp(-np.abs(x[:,i])/(30*s)) - 28629151*np.exp(-np.abs(x[:,i])/(31*s)) + 50331648*np.exp(-np.abs(x[:,i])/(32*s)) - 39135393*np.exp(-np.abs(x[:,i])/(33*s)) + 11358856*np.exp(-np.abs(x[:,i])/(34*s)))/946)
        return k
    
    if v==2:
        k = np.ones(x.shape[0])
        for i in range(x.shape[1]):
            k = np.multiply(k,(2*np.exp(-np.abs(x[:,i])/(s)) - 8*np.exp(-np.abs(x[:,i])/(2*s)) - 243*np.exp(-np.abs(x[:,i])/(3*s)) + 1536*np.exp(-np.abs(x[:,i])/(4*s)) - 3125*np.exp(-np.abs(x[:,i])/(5*s)) + 1944*np.exp(-np.abs(x[:,i])/(6*s)))/106)
        return k
    if v==3:
        return np.exp(-(LA.norm(x, 2, axis=1)**2)/s)
    return 0
    
def RidgeRegressMatern(v, s, lambda_, Xtrain, Ytrain, Xtest, Ytest):
    start_time = time.time()
    n = Xtrain.shape[0]
    m = Xtest.shape[0]
    
    K = np.zeros((n,n))
    for i in range(n):
        K[i,:] = GenKernel(v, s, Xtrain - Xtrain[i,:])
    
    w = np.linalg.solve(K+lambda_*np.identity(n), Ytrain)
    elapsed_time = time.time() - start_time
    
    TrainErr = LA.norm(np.matmul(K,w)-Ytrain, 2)/np.sqrt(n)
    
    TestErr = 0
    for i in range(m):
        est = np.inner(GenKernel(v, s, Xtrain - Xtest[i,:]), w)
        
        TestErr = TestErr + (est - Ytest[i])**2
    TestErr = np.sqrt(TestErr/m)
    
    return TrainErr, TestErr, elapsed_time


#Data = np.genfromtxt('Insurance Company/ticdatafull.csv',delimiter=',')
#Data = Data[1:Data.shape[0],1:Data.shape[1]]

#D = np.genfromtxt('Wine Quality/winequality-white.csv',delimiter=';')
#D = D[1:D.shape[0],:]

#Data = np.concatenate((Data, D), axis=0)

#Data = np.take(Data,np.random.permutation(Data.shape[0]),axis=0)
#
#Normalizer = np.max(Data[:,0:85],axis=0) - np.min(Data[:,0:85],axis=0)
#
#Data[:,0:85] = np.divide(Data[:,0:85], Normalizer, out=np.zeros_like(Data[:,0:85]), where=Normalizer!=0) 
#
#Xtrain = Data[0:5822,0:85]
#Ytrain = Data[0:5822,85]
#
#Xtest = Data[5822:Data.shape[0],0:85]
#Ytest = Data[5822:Data.shape[0],85]
#
#BASE_PATH = "Insurance Company"
#
#np.savez(os.path.join(BASE_PATH, "InsuranceCompany"), Xtrain, Ytrain, Xtest, Ytest)

data = np.load('Insurance Company/InsuranceCompany.npz')

Xtrain = data['arr_0']
Ytrain = data['arr_1']
Xtest = data['arr_2']
Ytest = data['arr_3']

#Wine: lambda=1, (s,v) = {(1,0), (0.25,1), (0.19,2), (0.4,3)}

#Synthetic Matern 5/2 s1 d5: lambda=0.5, (s,v) = { (1.1,0),(0.5,1), (0.3,2), (0.64,3)}
#Synthetic Laplace s1 d5: lambda=0.1, (s,v) = { (0.88,0),(0.1,1), (0.16,2), (0.1,3)}
#Synthetic Laplace s4 d5: lambda=0.01, (s,v) = { (2.9,0),(0.7,1), (0.36,2), (0.5,3)}
#Synthetic Gaussian s1 d5: lambda=0.5, (s,v) = { (0.75,0),(0.3,1), (0.2,2), (0.4,3)}
#Synthetic Gaussian s1 d5: lambda=0.3, (s,v) = { (0.8,0), (0.22,2), (0.39,3)}
#Synthetic Matern 5/2 s1 d5: lambda=0.3, (s,v) = { (1.1,0), (0.3,2), (0.64,3)}


#Synthetic Laplace s15 d30: lambda=0.3, (s,v) = { (9.5,0),(1.2,1), (0.85,2), (5.5,3)}
#Synthetic Gaussian s15 d30: lambda=0.3, (s,v) = { (7.4,0),(1.1,1), (0.8,2), (4.8,3)}
#Synthetic Matern 5/2 s4 d30: lambda=0.5, (s,v) = { (7.6,0),(1.1,1), (0.8,2), (5.1,3)}
#Synthetic Matern 5/2 s1 d30: lambda=0.5, (s,v) = { (6.4,0),(0.9,1), (0.67,2), (3.3,3)}

#Learning with Gen Kernel:
#Wine: lambda=1, (s,v) = {(0.0075,1), (0.04,2)}

#Synthetic Matern 5/2 s1 d30: lambda=0.5, (s,v) = { (0.037,1), (0.16,2)}
#Synthetic Gaussian s15 d30: lambda=0.3, (s,v) = { (0.045,1), (0.19,2)}
#Synthetic Gaussian s1 d5: lambda=0.5, (s,v) = { (0.0065,1), (0.045,2)}
#Synthetic Gaussian s1 d5: lambda=0.3, (s,v) = { (0.047,2)}
#Synthetic Laplace s15 d30: lambda=0.3, (s,v) = { (0.04,1), (0.18,2)}
#Synthetic Laplace s1 d5: lambda=0.1, (s,v) = { (0.038,2)}
#Synthetic Laplace s4 d5: lambda=0.01, (s,v) = { (0.059,2)}
#Synthetic Matern 5/2 s1 d5: lambda=0.3, (s,v) = { (0.06,2)}

lambda_ = 1

s =20
v=3

Output = RidgeRegressMatern(v, s, lambda_, Xtrain, Ytrain, Xtest, Ytest)

print('Elapsed Time=', Output[2], 'Error =', Output[1],'v =', v, 'Sigma =', s, 'lambda =', lambda_)

