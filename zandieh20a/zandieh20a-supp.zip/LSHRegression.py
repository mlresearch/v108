#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 30 11:48:05 2019

@author: zandieh
"""
import numpy as np
import time
import random
from numpy import linalg as LA
from LSHLaplace import LSHLaplaceMatMul, KernelExact, GenKernel, LSHLaplaceFindBuckets
from ConjugateGradient import CGLSH, CGExactKer, CGFF


def RidgeRegressLSH(s, m, lambda_, eps_, Xtrain, Ytrain, Xtest, Ytest):
    start_time = time.time()
    n = Xtrain.shape[0]
    d = Xtest.shape[1]
    
    w = np.random.gamma(2, s, (d,m))
    z = np.zeros((d,m))
    for i in range(m):
        z[:,i] = np.random.uniform(np.zeros(d),w[:,i])
    
    buckets = []
    
    for i in range(m):
        buckets = buckets + LSHLaplaceFindBuckets(Xtrain,w[:,i],z[:,i])
    print(len(buckets))
    alpha_star = CGLSH(buckets,lambda_,Ytrain,m,eps_)
    
    elapsed_time = time.time() - start_time
    
    TrainErr = LA.norm(LSHLaplaceMatMul(buckets,alpha_star,m)-Ytrain, 2)/np.sqrt(n)
 
    buckets_q = []
    for i in range(m):
        buckets_q = buckets_q + LSHLaplaceFindBuckets(np.concatenate((Xtrain, Xtest), axis=0),w[:,i],z[:,i])
    
    est = LSHLaplaceMatMul(buckets_q,np.concatenate((alpha_star,np.zeros(len(Ytest)))),m)[len(Ytrain):len(Ytrain)+len(Ytest)]
        
    TestErr = LA.norm(est - Ytest,2)/np.sqrt(len(Ytest))
    
    return TrainErr, TestErr, elapsed_time

def RidgeRegressConjGrad(s, v, lambda_, eps_, Xtrain, Ytrain, Xtest, Ytest):
    start_time = time.time()
    n = Xtrain.shape[0]
    
    alpha_star = CGExactKer(Xtrain,lambda_,s,v,Ytrain,eps_)
    
    TrainErr = LA.norm(KernelExact(Xtrain,alpha_star,s,v)-Ytrain, 2)/np.sqrt(n)
    elapsed_time = time.time() - start_time
    
    TestErr = 0
    for i in range(len(Ytest)):
        est = np.inner(GenKernel(v, s, Xtrain - Xtest[i,:]),alpha_star)
        TestErr = TestErr + (est - Ytest[i])**2
    TestErr = np.sqrt(TestErr/len(Ytest))
    
    return TrainErr, TestErr, elapsed_time


def RidgeRegressFF(s, m, lambda_, eps_, Xtrain, Ytrain, Xtest, Ytest):
    start_time = time.time()
    n = Xtrain.shape[0]
    d = Xtest.shape[1]
    
    w = np.random.normal(0, 1/(np.pi*np.sqrt(2*s)), (d,m))
    z = np.random.uniform(0,2*np.pi,m)
    
    Features_train = np.zeros((m,n))
    
    for i in range(m):
        Features_train[i,:] = np.cos(2*np.pi*np.matmul(Xtrain,w[:,i]) + z[i])
    
    
    alpha_star = CGFF(Features_train,lambda_,Ytrain,m,eps_)
    
    elapsed_time = time.time() - start_time
    
    TrainErr = LA.norm(np.matmul( Features_train.T ,np.matmul(Features_train,alpha_star))/m -Ytrain, 2)/np.sqrt(n)
 
    Features_test = np.zeros((m,Xtest.shape[0]))
    
    for i in range(m):
        Features_test[i,:] = np.cos(2*np.pi*np.matmul(Xtest,w[:,i]) + z[i])

   
    
    est = np.matmul( Features_test.T ,np.matmul(Features_train,alpha_star))/m
        
    TestErr = LA.norm(est - Ytest,2)/np.sqrt(len(Ytest))
    
    return TrainErr, TestErr, elapsed_time

data = np.load('Location of CT slices/LocationCTData.npz')

Xtrain = data['arr_0']
Ytrain = data['arr_1']
Xtest = data['arr_2']
Ytest = data['arr_3']


#wine data : lambda=0.5, (s,v) = {(1.1,lsh), (0.9,0), (0.15,3), (0.28,2), (0.035,1), (0.5,ff)}

#Insurance data : lambda=1, (s,v) = {(60,lsh), (70,0), (2,3), (20,2), (20,ff)}

#Forest data : lambda=0.5, (s,v) = {(0.9,lsh), (0.8,0), (0.13,3), (0.25,2), (5,ff)}

#CT data : lambda=0.5, (s,v) = {(15,lsh), (10,0), (1.7,3), (3,2), (ff,40)}

#v=2 > gaussian, v=3 > matern5/2, v=0 > laplace, v=3 > GenKernel

eps_ = 1
lambda_ = 0.5
s=40
v=0
m=4000
###############
Output = RidgeRegressFF(s, m, lambda_, eps_, Xtrain, Ytrain, Xtest, Ytest)
print('Elapsed Time=', Output[2], 'Error =', Output[1],'v =', v, 'Sigma =', s, 'lambda =', lambda_)
#start_time = time.time()
#n = Xtrain.shape[0]
#d = Xtest.shape[1]
#
#w = np.random.gamma(2, s, (d,m))
#z = np.zeros((d,m))
#for i in range(m):
#    z[:,i] = np.random.uniform(np.zeros(d),w[:,i])
#
#buckets = []
#
#for i in range(m):
#    buckets = buckets + LSHLaplaceFindBuckets(Xtrain,w[:,i],z[:,i])
#print(len(buckets))
#
#elapsed_time = time.time() - start_time
#print(elapsed_time)
#################
#Error=np.zeros((6,10))
#for i,m in enumerate(range(5,51,8)):
#    for j in range(10):
#        Output = RidgeRegressLSH(s, m, lambda_, eps_, Xtrain, Ytrain, Xtest, Ytest)
#        Error[i,j]=Output[1]
#        print(i,j)
#print(Error)
#print('Elapsed Time=', Output[2], 'Error =', Output[1],'v =', v, 'Sigma =', s, 'lambda =', lambda_)


#s=0.25
#v=2
#Output1 = RidgeRegressConjGrad(s, v, lambda_, eps_, Xtrain, Ytrain, Xtest, Ytest)
#
#print('Elapsed Time=', Output1[2], 'Error =', Output1[1],'v =', v, 'Sigma =', s, 'lambda =', lambda_)
#
#
#s=0.13
#v=3
#Output2 = RidgeRegressConjGrad(s, v, lambda_, eps_, Xtrain, Ytrain, Xtest, Ytest)
#
#print('Elapsed Time=', Output2[2], 'Error =', Output2[1],'v =', v, 'Sigma =', s, 'lambda =', lambda_)
