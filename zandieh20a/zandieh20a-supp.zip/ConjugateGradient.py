#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 30 09:54:42 2019

@author: zandieh
"""

import numpy as np
from numpy import linalg as LA
from LSHLaplace import LSHLaplaceMatMul, KernelExact, GenKernel, LSHLaplaceFindBuckets

def CGLSH(buckets,lambda_,b,m,eps_):
    
    x = np.zeros(b.shape)
    r = b
    p = r
    
    
    while(LA.norm(r, 2)>eps_):
        
        Ap = LSHLaplaceMatMul(buckets,p,m) + lambda_*p
        
        alpha_ = np.inner(r,r)/(np.inner(p,Ap))
        x = x+alpha_*p
        
        r_n = r-alpha_*Ap
        
        beta_ = (np.inner(r_n,r_n))/(np.inner(r,r))
        p = r_n+beta_*p
        
        r = r_n
        
    return x

def CGExactKer(A,lambda_,s,v,b,eps_):
    
    x = np.zeros(b.shape)
    r = b
    p = r
    
        
    while(LA.norm(r, 2)>eps_):
        
        Ap = KernelExact(A,p,s,v) + lambda_*p
        
        alpha_ = np.inner(r,r)/(np.inner(p,Ap))
        x = x+alpha_*p
        
        r_n = r-alpha_*Ap
        
        beta_ = (np.inner(r_n,r_n))/(np.inner(r,r))
        p = r_n+beta_*p
        
        r = r_n
        
    return x

def CGFF(A,lambda_,b,m,eps_):
    
    x = np.zeros(b.shape)
    r = b
    p = r
    
    
    while(LA.norm(r, 2)>eps_):
        Ap = np.inner( A.T ,np.matmul(A,p))/m + lambda_*p
        #Ap= np.zeros(len(p))
        #for i in range(len(p)):    
        #    Ap[i] = np.inner( A[:,i] ,np.matmul(A,p))/m + lambda_*p[i]
        
        alpha_ = np.inner(r,r)/(np.inner(p,Ap))
        x = x+alpha_*p
        
        r_n = r-alpha_*Ap
        
        beta_ = (np.inner(r_n,r_n))/(np.inner(r,r))
        p = r_n+beta_*p
        
        r = r_n
        
    return x