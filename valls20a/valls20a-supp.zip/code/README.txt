Download Julia 1.1 from: https://julialang.org

Install the necessary packages by executing the following commands in the Julia terminal:

	import Pkg
	Pkg.add("MathProgBase")
	Pkg.add("Ipopt")
	Pkg.add("Clp")
	Pkg.add("ProgressMeter")
	Pkg.add("Plots")

Run the code with the following command:

	include("/your_directory/942.jl")
