#### Code submitted to AISTATS 2020. Submission 942 ####

using MathProgBase, Ipopt, Clp
using ProgressMeter
using Random
using Plots
using LinearAlgebra

println("\n########### Submission 942 ###########")
epsilons = [0.5];               # parameter learning rate
n = 10;                         # number of websites
T = 5000;                       # horizon

i = 0;
log_regret = zeros(Float64, T, size(epsilons,1));
log_compare = zeros(Float64, T, 3); # fix for the three types of regrets
log_cv = zeros(Float64, T, size(epsilons,1));

# Run a simulation for every epsilon (seed is fixed)
for ϵ in epsilons

  global i

  i = i + 1;
  Random.seed!(1);      # the seed is the same for every epsilon

  # Initialize variables
  x = zeros(n,1)
  y = 0;
  cost = 0;
  penalty = 0;
  sumat = zeros(n,1);
  sumx = zeros(n,1);
  sumc = 0;
  sumbt = 0;
  suml = zeros(n,1);
  sumy = 0;
  df = 0;
  l = -rand(n);
  l = l/sum(-l);

  p = Progress(T)

  global cost, l, a, at, bt, adv, c, slater, x, y, ρ, b_T, sumx, sumc, df, sumbt, suml, sumat, cost, gamma, penalty, sumy, bt_max, logs_matrix, io

  a = rand(n);
  a = a / sum(a);
  at = a;
  bt = 0;
  bt_max = 0;
  b_T = 0;
  slater = 0.01;
  c = 1/n;

  j = 1;

  for t = 1:T

    ## Algorithm 1 starts
    ρ  = 1 / t^(ϵ);

    x = min.(1, max.(0, x - (1/2)*ρ*(l + y.*a)));

    # adversarial cost function
    adv = sign.(-x .+ minimum(x)).+1;
    l = adv / sum(-adv);

    # adversarial constraint
    if(t < T/2)
        bt = 1/n - slater;
    else
        bt = 0;
    end

    # save b_max
    if(t == 1)
        bt_max = bt;
    else
        bt_max = max.(bt,bt_max);
    end

    y = max.(0, y + (1/2)*ρ*((a'*x)[1] + bt - c));      # dual variable update
    ## Algorithm 1 ends


    ## Logs and computing the fixed decision in hindsight
    sumx = sumx + x;
    sumy = sumy + y;
    suml = suml + l;
    sumc = sumc + c;
    sumbt = sumbt + bt;
    sumat = sumat + at;

    df = df + y'*bt;

    cost  =  cost + (l'*x)[1];
    penalty = penalty + (at'*x)[1] + bt - c;

    b_T = (1-ρ)* bt_max + ρ * sumbt/t;
    omega = max(min(df/sumy,bt_max),sumbt/t);

    sol_var = linprog( suml[:,1], sumat'/t, '<', - b_T + c, 0, 1, ClpSolver());
    sol_max = linprog( suml[:,1], sumat'/t, '<', - bt_max + c, 0, 1, ClpSolver());
    sol_min = linprog( suml[:,1], sumat'/t, '<', - sumbt/t + c, 0, 1, ClpSolver());
    sol_omega = linprog( suml[:,1], sumat'/t, '<', - omega + c, 0, 1, ClpSolver());

    cost_var = (suml'*sol_var.sol)[1];
    cost_max = (suml'*sol_max.sol)[1];
    cost_min = (suml'*sol_min.sol)[1];
    cost_omega = (suml'*sol_omega.sol)[1];

    regret_var = cost - cost_var;
    regret_max = cost - cost_max;
    regret_min = cost - cost_min;
    regret_omega = cost - cost_omega;

    violation = penalty;

    log_regret[t,i] = regret_var;
    log_compare[t,1] = regret_max;
    log_compare[t,2] = regret_min;
    log_compare[t,3] = regret_omega;
    log_cv[t,i] = violation;

    ProgressMeter.next!(p; showvalues = [(:t,t), (:ϵ,ϵ), (:ρ,ρ)])

  end
end

#####################################

# Plots
p_regret = plot(hcat(log_regret,log_compare),title="Regret",label=["w_cvx" "b_max" "b_avg" "w_0"]);
p_cv = plot(log_cv,title="Constraint Violation");
plot(p_regret,p_cv,layout=(2,1))
