library(plyr)

devtools::load_all("likeliest")


## Parameters
prefix <- "data/synthetic/"
dir.create(prefix, showWarnings = FALSE)
train_sizes <- c(50, 100, 500, 1000, 10000)
n_neighbors <- 1
n_samples <- 200
n_iters <- 100

n_cores <- 5
if (!is.na(n_cores)) {
    library(doMC)
    doMC::registerDoMC(cores = n_cores)
}

## Script
source("synthetic.R")

run_params <- expand.grid(n_train = train_sizes,
                          iter = seq_len(n_iters))

m_ply(run_params, function(iter, n_train) {
    set.seed(iter)

    dat <- synthetic_data(n_train = n_train, n_test = n_samples)

    x_train <- dat$x_train
    x_test <- dat$x_test
    theta <- dat$theta
    train_ids <- dat$train_ids
    test_ids <- dat$test_ids

    # Prepare methods
    methods <- list(
        ## Kernel density
        "kcde" = function(x_train, theta_train, train_ids, theta_sample,
                          sample_ids) {
            sampler <- kcde_sample
            return(local_sample(x_train = x_train, theta_train = theta,
                                train_ids = train_ids, theta_sample = theta,
                                sample_ids = sample_ids,
                                k = n_neighbors, sample_fun = sampler))
        },
        "kcde-discrete" = function(x_train, theta_train, train_ids, theta_sample,
                          sample_ids) {
            sampler <- kcde_sample
            return(round(local_sample(x_train = x_train, theta_train = theta,
                                      train_ids = train_ids, theta_sample = theta,
                                      sample_ids = sample_ids,
                                      k = n_neighbors, sample_fun = sampler)))
        },
        ## Gaussian density
        "gauss" = function(x_train, theta_train, train_ids, theta_sample,
                           sample_ids) {
            sampler <- gaussian_sample
            return(local_sample(x_train = x_train, theta_train = theta,
                                train_ids = train_ids, theta_sample = theta,
                                sample_ids = sample_ids,
                                k = n_neighbors, sample_fun = sampler))

        },

        ## Poisson density
        "poisson" = function(x_train, theta_train, train_ids, theta_sample,
                             sample_ids) {
            sampler <- poisson_sample
            return(local_sample(x_train = x_train, theta_train = theta,
                                train_ids = train_ids, theta_sample = theta,
                                sample_ids = sample_ids,
                                k = n_neighbors, sample_fun = sampler))
        },

        ## True distribution
        "true" = function(x_train, theta_train, train_ids, theta_sample,
                          sample_ids) {
            return(t(apply(theta_sample[sample_ids, ], 1, gen_data)))
        })
        ## },

        ## Masked auto-regressive flow
        ## "maf" = function(x_train, theta_train, train_ids, theta_sample,
        ##                  sample_ids) {
        ##     theta_train <- as.matrix(theta_train[train_ids, , drop = FALSE])
        ##     theta_sample <- as.matrix(theta_sample[sample_ids, , drop = FALSE])

        ##     perm <- sample(nrow(theta_train))
        ##     x_train <- x_train[perm, ]
        ##     theta_train <- theta_train[perm, ]

        ##     stopifnot(nrow(x_train) == nrow(theta_train))
        ##     samples <- maf_gen(theta_train, x_train, theta_sample,
        ##                        n_hiddens = c(30L, 30L), n_mades = 10L,
        ##                        batch_size = 100L)
        ##     return(samples)
        ## })


    l_ply(names(methods), function(method) {
        dirname <- paste0(prefix, method, "-", n_train, "-", iter, "/")
        print(dirname)
        if (dir.exists(dirname)) {
            warning(paste("Sim already ran:", dirname))
            return()
        }

        try({samples <- methods[[method]](x_train = x_train, theta_train = theta,
            train_ids = train_ids, theta_sample = theta, sample_ids = test_ids)

            dat <- list(x_test = x_test, samples = samples,
                        test_ids = test_ids,
                        sample_ids = test_ids)

            dir.create(dirname)
            saveRDS(dat, paste0(dirname, "samples.rds"))
        })
    }, .parallel = TRUE)
})
