library(pryr)
library(pdp)
library(tidyverse)
source(file = 'regreesion_test_functions.R')

## First function is a reproduction of the SBC test by Talts et al.
## We compare both with the posterior and the marginal, which is equal to the prior.
## Plotting code taken from https://github.com/seantalts/simulation-based-calibration.

talts_example_function <- function(n_rep = 1000, n_dataset = 1000){
  l_value <- n_rep/10
  normal_level_99 <- qnorm(0.995, 0, 1)
  
  plot_vec <- list()
  for (type_post in c('prior', 'post')){
    results_stats <- c()
    for (i in c(1:n_rep)){
      prior_sample <- rnorm(n = 1, mean = 0, sd = 1)
      data_sample <- rnorm(n = n_dataset, mean = prior_sample, sd = 1)
      
      if (type_post == 'prior'){
        post_samples <- rnorm(n = l_value, mean = 0, sd = 1)
      } else {
        sd_post <- sqrt(1/(n_dataset + 1))
        post_samples <- rnorm(n = l_value, mean = sum(data_sample)*(sd_post**2), 
                              sd = sd_post)
      }
      results_stats <- c(results_stats, sum(post_samples < prior_sample))
    }
    
    expected_mean <- n_rep/(l_value + 1)
    expected_variance <- n_rep*l_value/(l_value+1)**2
    rr <- as.data.frame(results_stats)
    mean <- n_rep/l_value
    sd <- sqrt(expected_variance)
    CI <- qbinom(c(0.005,0.5,0.995), size=n_rep, prob  =  1/(l_value+1))
    
    title_plot <- 'SBC Test'
    
    p1 <- ggplot(rr,aes(x=results_stats))  + 
      geom_segment(aes(x=0, y=mean, xend=l_value, yend=mean),colour="grey25") + 
      geom_polygon(data=data.frame(x=c(-5,0,-5,l_value + 5,l_value,l_value + 5,-5), 
                                   y=c(CI[1],CI[2],CI[3],CI[3],CI[2],CI[1],CI[1])),
                   aes(x=x,y=y), fill="grey45", color="grey25", alpha=0.5) +
      geom_histogram(breaks=seq(-1, l_value, by=1),fill="#A25050",colour="black", alpha=0.25) +
      theme_bw(base_size = 14) + labs(y='Frequency', x='Rank Statistic', title=title_plot) + 
      xlim(c(-5, l_value+5)) + theme(plot.title = element_text(hjust = 0.5))
    plot_vec[[type_post]] <- p1
  }
  pdp::grid.arrange(plot_vec[['post']], plot_vec[['prior']])
  return(plot_vec)
}

plot_vec_talts <- talts_example_function(n_rep = 500)


## The next test concerns the posterior quantiles from Cook et al.
## Same story here, we compare using the marginal (= Prior) with the actual posterior
## COOK Quantiles

post_quantiles_cook_function <- function(n_rep=1000, n_breaks=100, n_dataset=1000){
  
  plot_vec <- list()
  for (type_post in c('prior', 'post')){
    results_stats <- c()
    for (i in c(1:n_rep)){
      prior_sample <- rnorm(n = 1, mean = 0, sd = 1)
      data_sample <- rnorm(n = n_dataset, mean = prior_sample, sd = 1)
      
      if (type_post == 'prior'){
        temp_post <- function(x){
          return(dnorm(x = x, mean = 0, sd = 1))
        }
      } else {
        sd_post <- sqrt(1/(n_dataset + 1))
        temp_post <- function(x){
          return(dnorm(x = x, mean = sum(data_sample)*(sd_post**2), sd = sd_post))
        }
      }
      results_stats <- c(results_stats, integrate(temp_post, lower = -20, upper = prior_sample)$value)
    }
    
    expected_mean <- n_rep/(n_breaks + 1)
    expected_variance <- n_rep*n_breaks/(n_breaks+1)**2
    rr <- as.data.frame(results_stats)
    mean <- n_rep/n_breaks
    sd <- sqrt(expected_variance)
    CI <- qbinom(c(0.005,0.5,0.995), size=n_rep, prob = 1/(n_breaks+1))
    
    title_plot <- 'PQ Test'
    
    p1 <- ggplot(rr,aes(x=results_stats))  + 
      geom_segment(aes(x=0, y=mean, xend=1, yend=mean),colour="grey25") + 
      geom_polygon(data=data.frame(x=c(-0.02, 0, -0.02, 1.02, 1, 1.02, -0.02),
                                   y=c(CI[1], CI[2], CI[3], CI[3], CI[2], CI[1], CI[1])),
                   aes(x=x,y=y),fill="grey45",color="grey25",alpha=0.5) +
      geom_histogram(breaks=seq(0, 1, length.out = n_breaks),fill="#A25050",colour="black", alpha=0.25) +
      theme_bw(base_size = 14) + labs(y='Frequency', x='Posterior Quantiles', title=title_plot) + 
      theme(plot.title = element_text(hjust = 0.5))
    
    plot_vec[[type_post]] <- p1
  }
  pdp::grid.arrange(plot_vec[['post']], plot_vec[['prior']])
  return(plot_vec)
}

plot_vec_cook <- post_quantiles_cook_function(n_rep = 500, n_breaks = 50)


#### Now we consider the case in which we use our global test.
#### We compare n_samples from the true posterior with the true_posterior and the prior
#### distribution, and then we provide the same histogram.

regression_test_posterior_function <- function(n_rep, n_dataset = 1000, n_breaks = 50,
                                          type_post = 'prior', preloaded_results = NULL){
  
  if (is.null(preloaded_results)){
    results_stats <- c()
    for (i in c(1:n_rep)){
      print(paste0('Working on iteration ', i, ' of ', n_rep))
      prior_sample <- rnorm(n = 1, mean = 0, sd = 1)
      data_sample <- rnorm(n = n_dataset, mean = prior_sample, sd = 1)
      sd_post <- sqrt(1/(n_dataset + 1))
      post_samples <- rnorm(n = l_value, mean = sum(data_sample)*(sd_post**2), sd = sd_post)
      
      if (type_post == 'prior'){
        comp_samples <- rnorm(n = l_value, mean = 0, sd = 1)
      } else {
        comp_samples <- rnorm(n = l_value, mean = sum(data_sample)*(sd_post**2), sd = sd_post)
      }
      p_value <- regression_test(sample = post_samples, generated = comp_samples, n_bootstrap = 100)
      results_stats <- c(results_stats, p_value)
    }
  } else {
    results_stats <- preloaded_results
  }
  
  expected_mean <- n_rep/(n_breaks + 1)
  expected_variance <- n_rep*n_breaks/(n_breaks+1)**2
  rr <- as.data.frame(results_stats)
  mean <- n_rep/n_breaks
  sd <- sqrt(expected_variance)
  CI <- qbinom(c(0.005,0.5,0.995), size=n_rep, prob = 1/(n_breaks+1))
  
  title_plot <- 'Global Regression Test'
  
  p1 <- ggplot(rr,aes(x=results_stats))  + 
    geom_segment(aes(x=0, y=mean, xend=1, yend=mean),colour="grey25") + 
    geom_polygon(data=data.frame(x=c(-0.02, 0, -0.02, 1.02, 1, 1.02, -0.02),
                                 y=c(CI[1], CI[2], CI[3], CI[3], CI[2], CI[1], CI[1])),
                 aes(x=x,y=y),fill="grey45",color="grey25",alpha=0.5) +
    geom_histogram(breaks=seq(0, 1, length.out = n_breaks),fill="#A25050",colour="black", alpha=0.25) +
    theme_bw(base_size=14) + labs(y='Frequency', x='P-Value', title=title_plot) + 
    theme(plot.title = element_text(hjust = 0.5))
  
  return(list(plot=p1, result=results_stats))
}

plot_regression <- list()
regression_post <- regression_test_posterior_function(n_rep = 500, type_post = 'post')
plot_regression[['post']] <- regression_post[['plot']]

regression_prior <- regression_test_posterior_function(n_rep = 500, type_post = 'prior')
plot_regression[['prior']] <- regression_prior[['plot']]


## Arranging the Histograms

library(ggplot2)
library(gtable)
library(gridExtra)
library(grid)
library(ggpubr)

#igure <- pdp::grid.arrange(plot_vec_cook[['post']] + theme(axis.title.x=element_blank()), 
#                            plot_vec_talts[['post']] + theme(axis.title.x=element_blank(),
#                                                               axis.title.y=element_blank()),  
#                            plot_regression[['post']] + theme(axis.title.x=element_blank(),
#                                                              axis.title.y=element_blank()),
#                  plot_vec_cook[['prior']] + theme(plot.title = element_blank()), 
#                  plot_vec_talts[['prior']] + theme(plot.title = element_blank(),
#                                                    axis.title.y=element_blank()), 
#                  plot_regression[['prior']] + theme(plot.title = element_blank(),
#                                                     axis.title.y=element_blank()), nrow = 2)

#annotate_figure(figure, left = text_grob('\n (a) \n \n \n \n \n \n \n \n (b) \n \n', size = 16, face = 'bold'))

figure <- pdp::grid.arrange(plot_vec_cook[['post']] + theme(axis.title.x=element_blank()), 
                            plot_vec_talts[['post']] + theme(axis.title.x=element_blank(),
                                                             axis.title.y=element_blank()),  
                            plot_regression[['post']] + theme(axis.title.x=element_blank(),
                                                              axis.title.y=element_blank()),
                            plot_vec_cook[['prior']] + theme(plot.title = element_blank()), 
                            plot_vec_talts[['prior']] + theme(plot.title = element_blank(),
                                                              axis.title.y=element_blank()), 
                            plot_regression[['prior']] + theme(plot.title = element_blank(),
                                                               axis.title.y=element_blank()), nrow = 2)

annotate_figure(figure, left = text_grob('\n (a) \n \n \n \n \n \n \n \n \n \n (b) \n \n', size = 16))

