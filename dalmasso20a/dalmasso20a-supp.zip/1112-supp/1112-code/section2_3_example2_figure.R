library(pdp)
library(tidyverse)
library(ggridges)
library(cowplot)
library(latex2exp)

# This file relies on running results for the three cases in Section 2.3, Example 2
# separately. See the `global_test_...` and `local_test_...` files to see how 
# to run and save such examples.


###########################################
### LOCAL TEST - PARAMETER SPACE ##########
###########################################

## The following local test looks at what happens with the power
## against the values of theta.
## Functions have hard-coded three plots in it.

local_test_theta_plot_runtype <- function(n_sim_vector, d_vector, length_out, 
                                          n_bootstrap = 100, data_loc = 'data/',
                                          run_type = 'variance', return_flag = F,
                                          model = 'random_forest'){
  plot_vec <- list()
  for (i in c(1:length(d_vector))){
    filename_load <- paste0(data_loc, 'test_results_localtest_', run_type, '_n',
                            n_sim_vector[i], '_dim', d_vector[i], '_lenout', 
                            length_out, '_model', model, 'bootstrap', 
                            n_bootstrap, '.RData')
    load(filename_load)
    plot_df <- out_list[[1]] %>% as.data.frame() %>%
      group_by(theta) %>% summarise(power_ilmun = mean(ilmun_test < 0.05),
                                    power_et = mean(energy_test < 0.05),
                                    power_mdd = mean(mmd_test < 0.05)) %>%
      as.data.frame()
    rep <- dim(out_list[[1]] %>% as.data.frame())[1]/length_out
    
    local_test_plot_df <- reshape2::melt(plot_df, id = c('theta'))
    local_test_plot_df$Test <- plyr::revalue(local_test_plot_df$variable, 
                                             c("power_ilmun" = "Regression", "power_et" = "Energy", "power_mdd" = "MMD")) 
    
    if (run_type == 'variance'){
      title_run <- 'Shrinking Variance Case, '
    } else if (run_type == 'bernoulli'){
      title_run <- 'Bernoulli Case, '
    } else if (run_type == 'mixture'){
      title_run <- 'Mixture of Gaussians Case, '
    } else {
      title_run <- ''
    }
    title_plot_local <- paste0('Power of Local Test  (D=', d_vector[i], ')')
    
    p1 <- ggplot(local_test_plot_df, aes(x=theta, y=value, group = Test)) +
      geom_line(size=1.5, aes(color = Test, lty=Test)) + theme_bw(base_size = 14) + 
      labs(x=latex2exp::TeX("$\\theta$"), y="Power", title=title_plot_local) +
      ylim(c(0,1)) + theme(plot.title = element_text(hjust = 0.5),
                           legend.text=element_text(size=12)) +
      scale_color_brewer(palette = "Set1")
      
    plot_vec[[i]] <- p1
  }
  grid.arrange(plot_vec[[1]], plot_vec[[2]], plot_vec[[3]])
  if (return_flag == T){
    return(plot_vec) 
  }
}

p_local_var <- local_test_theta_plot_runtype(n_sim_vector = c(50, 25, 100), 
                                             d_vector = c(100, 50, 100),
                                             length_out = 10, 
                                             run_type = 'variance', 
                                             return_flag = T)

p_local_mix <- local_test_theta_plot_runtype(n_sim_vector = c(25, 50, 100), 
                                             d_vector = c(50, 100, 100),
                                             length_out = 10, 
                                             run_type = 'mixture', 
                                             return_flag = T)

p_local_bern <- local_test_theta_plot_runtype(n_sim_vector = c(25, 50, 100), 
                                              d_vector = c(50, 100, 100),
                                              length_out = 10, 
                                              run_type = 'bernoulli', 
                                              return_flag = T)

####################################
### LOCAL TEST - DIMENSIONS ########
####################################

## The following local test looks at what happens with the power when dimension
## is changed.
## Functions have hard-coded three plots in it.

local_test_dimension_plot_runtype <- function(n_sim_vector, d_vector, length_out, 
                                              n_bootstrap = 100, return_flag = F,
                                              run_type = 'variance',
                                              model = 'random_forest', 
                                              data_loc = 'data/'){
  plot_vec <- list()
  for (i in c(1:length(d_vector))){
    filename_load <- paste0(data_loc, 'test_results_globaltest_', run_type, '_n', 
                            n_sim_vector[i], 'dim_max', d_vector[i], 'lenout', 
                            length_out, 'model', model, 'bootstrap', 
                            n_bootstrap, '.RData')
    
    load(filename_load)
    mat_results <- out_list[[1]]
    global_mat_results <- mat_results %>% 
      tibble::as.tibble() %>% 
      dplyr::group_by(dimension, n_bootstrap, n_sim) %>%
      dplyr::summarize(ilmun_test_global = mean(ilmun_test < 0.05),
                       energy_test_global = mean(energy_test < 0.05),
                       mmd_test_global = mean(mmd_test < 0.05)) %>%
      as.data.frame()
    rep <- dim(out_list[[1]] %>% as.data.frame())[1]/length_out
    local_test_plot_df <- reshape2::melt(global_mat_results[, c(1,4,5,6)],
                                         id = c('dimension'))
    local_test_plot_df$Test <- plyr::revalue(local_test_plot_df$variable, 
                                             c("ilmun_test_global" = "Regression", "energy_test_global" = "Energy", "mmd_test_global" = "MMD")) 
    
    dim1_df <- local_test_plot_df %>% filter(dimension == 1)
    print(dim1_df)
    
    if (run_type == 'variance'){
      title_run <- 'Shrinking Variance Case, '
    } else if (run_type == 'bernoulliuniftheta'){
      title_run <- 'Bernoulli Case, '
    } else if (run_type == 'mixture'){
      title_run <- 'Mixture of Gaussians Case, '
    } else {
      title_run <- ''
    }
    
    title_plot_local <- 'Average Local Power vs. Dimension'
    p2 <- ggplot(local_test_plot_df, aes(x=dimension, y=value, color=Test, lty=Test)) +
      geom_line(size=1.5) + theme_bw(base_size = 14) + 
      labs(color="Test", x="Dimension", y="Power", title=title_plot_local) +
      ylim(c(0,1)) + xlim(c(1, d_vector[i])) + 
      geom_point(data=dim1_df, aes(x=dimension, y=value), shape = 1, size = 3) +
      theme(plot.title = element_text(hjust = 0.5),
            legend.text=element_text(size=12)) +
      scale_color_brewer(palette = "Set1")
    
    plot_vec[[i]] <- p2
  }
  grid.arrange(plot_vec[[1]], plot_vec[[2]], plot_vec[[3]])
  if (return_flag == T){
    return(plot_vec) 
  }
}

p_localdim_var <- local_test_dimension_plot_runtype(
  n_sim_vector = c(50, 100, 100), d_vector = c(200, 200, 250), return_flag = T,
  length_out = 8, run_type = 'variance')

p_localdim_mix <- local_test_dimension_plot_runtype(
  n_sim_vector = c(50, 100, 100), d_vector = c(250, 250, 250), return_flag = T,
  length_out = 8, run_type = 'mixture')

p_localdim_bern <- local_test_dimension_plot_runtype(
  n_sim_vector = c(50, 50, 100), d_vector = c(250, 250, 250), return_flag = T,
  length_out = 8, run_type = 'bernoulliuniftheta')


##########################
## FIGURE (3x3 PLOT) #####
##########################
library(ggplot2)
library(gtable)
library(gridExtra)
library(grid)
library(ggpubr)


figure <- ggarrange(p_local_bern[[3]] + theme(axis.title.x=element_blank()), 
                    p_localdim_bern[[3]] + theme(axis.title.x=element_blank(),
                                                 axis.title.y=element_blank()),
                    p_local_var[[3]] + theme(plot.title = element_blank(),
                                             axis.title.x=element_blank()), 
                    p_localdim_var[[3]] + theme(plot.title = element_blank(),
                                                axis.title.x=element_blank(),
                                                axis.title.y=element_blank()),
                    p_local_mix[[3]] + theme(plot.title = element_blank()), 
                    p_localdim_mix[[3]] + theme(plot.title = element_blank(),
                                                axis.title.y=element_blank()),
                    common.legend = T, nrow = 3, ncol = 2, legend = "bottom")


annotate_figure(figure, left = text_grob('(a) \n \n \n \n  \n \n \n  (b) \n \n \n \n  \n \n \n (c) \n \n ', size = 16))








