## This file generates a number of p-values across different dimensions, so it
## can be used for both local test against different dimensions and global test
## at a specific dimension.

suppressPackageStartupMessages(library(argparse))
source(file = 'regression_test_functions.R')
data_loc <- "~/icml_tests/data/"
#data_loc <- '~/Desktop/icml_tests/data/'

parser <- ArgumentParser()
parser$add_argument("-n", "--nsim", type="integer", default=50, 
                    help="Sample sizes for samples S1 and S2 [default %(default)s]",
                    metavar="number")
parser$add_argument("-r", "--rep", type="integer", default=30, 
                    help="Number of repetitions [default %(default)s]",
                    metavar="number")
parser$add_argument("-b", "--bootstrap", type="integer", default=100, 
                    help="Number of bootstrap rounds [default %(default)s]",
                    metavar="number")
parser$add_argument("-d", "--dim", type="integer", default=500, 
                    help="Maximum dimension reached by simulation [default %(default)s]",
                    metavar="number")
parser$add_argument("-l", "--length-dim", type="integer", default=10, 
                    help="Number of dimension tested [default %(default)s]",
                    metavar="number")
parser$add_argument("-m", "--model", default="random_forest", 
                    help="Model type - currently either log_reg or random_forest [default %(default)s]")

args <- parser$parse_args()
n_sim <- args$nsim
d_max <- args$dim
length_out <- args$length_dim
n_rep <- args$rep
n_bootstrap <- args$bootstrap

if (args$model == 'log_reg'){
  model_func <- regstat
} else {
  model_func <- rf_fit
  model <- 'random_forest'
}

d_vector <- rep(sapply(X = seq(1, d_max, length.out = length_out), FUN = as.integer), n_rep)
bootstrap_vector <- rep(n_bootstrap, n_rep*length_out)
nsim_vector <- rep(n_sim, n_rep*length_out)
list_results <- c()
for (i in 1:length(d_vector)){
  print(paste0('Working on iteration ', i, ' of ', length(d_vector)))
  theta_val <- runif(n = 1, min = -5, max = 5)
  list_results[[i]] <- local_test_function_mixture(n = nsim_vector[i], 
                                                   d = d_vector[i],
                                                   theta = theta_val, 
                                                   model_func = model_func,
                                                   n_bootstrap = bootstrap_vector[i])
}
mat_test_results <- do.call(rbind, list_results)
mat_results <- cbind(d_vector, bootstrap_vector, nsim_vector,
                     mat_test_results)
colnames(mat_results) <- c('dimension', 'n_bootstrap', 'n_sim', 
                           'regression_test', 'energy_test', 'mmd_test')

out_list <- list()
out_list[[1]] <- mat_results
filename_out <- paste0(data_loc, 'test_results_globaltest_mixture_n', n_sim, 'dim_max', 
                       d_max, 'lenout', length_out, 'model', model, 
                       'bootstrap', n_bootstrap, '.RData')
save(out_list, file=filename_out)


############## Temp Plots for Assessing Performances Locally ####################

global_mat_results <- out_list[[1]] %>% 
  tibble::as.tibble() %>% 
  dplyr::group_by(dimension, n_bootstrap, n_sim) %>%
  dplyr::summarize(regression_test_global = mean(regression_test < 0.05),
                   energy_test_global = mean(energy_test < 0.05),
                   mmd_test_global = mean(mmd_test < 0.05)) %>%
  as.data.frame()
rep <- dim(out_list[[1]] %>% as.data.frame())[1]/length_out
local_test_plot_df <- reshape2::melt(global_mat_results[, c(1,4,5,6)],
                                     id = c('dimension'))

title_plot_local <- paste0('Local Test, n=', n_sim, ', ',
                           ', Boostrap Number: ', n_bootstrap, ', Reps: ', rep)
ggplot(local_test_plot_df, aes(x=dimension, y=value, color=variable)) +
  geom_line(size=1.5) + theme_bw(base_size = 8) + 
  labs(color="Test", x="Dimension", y="Power", title=title_plot_local) +
  scale_color_hue(labels = c("Our GoF Test", "Energy Test", "MMD Test")) +
  ylim(c(0,1)) + xlim(c(1, d_max))
