suppressPackageStartupMessages(library(MASS))
suppressPackageStartupMessages(library(kernlab))
suppressPackageStartupMessages(library(randomForest))
suppressPackageStartupMessages(library(energy))
suppressPackageStartupMessages(library(goftest))
suppressPackageStartupMessages(library(dplyr))
suppressPackageStartupMessages(library(tibble))

#########################
### General Functions ###
#########################

## Logspace function - like Python or Matlab
logspace <- function(d1, d2, n) exp(log(10)*seq(d1, d2, length.out=n))

## Energy Test Function
energy_test <- function(sample, generated, n_bootstrap = 10000) {
  sample <- as.matrix(sample)
  generated <- as.matrix(generated)
  combined <- rbind(sample, generated)
  
  etest <- energy::eqdist.etest(combined,
                                sizes = c(nrow(sample), nrow(generated)),
                                R = n_bootstrap)
  return(etest$p.value)
}

## Maximum mean discrepancy, using a gaussian kernel (default)
mmd_test <- function(sample, generated, n_bootstrap = 10000) {
  sample <- as.matrix(sample)
  generated <- as.matrix(generated)
  combined <- rbind(sample, generated)
  kpar <- list(sigma = kernlab::sigest(combined, scaled = FALSE)[2])
  mmdstat <- kernlab::mmdstats(kernlab::kmmd(sample, generated, kpar = kpar))[1]
  
  boot_stats <- replicate(n_bootstrap, {
    boot_ids <- sample(nrow(combined), nrow(sample))
    sample_boot <- combined[boot_ids, , drop = FALSE]
    generated_boot <- combined[-boot_ids, , drop = FALSE]
    return(kernlab::mmdstats(kernlab::kmmd(sample_boot, generated_boot, kpar = kpar))[1])
  })
  
  return((1 + sum(mmdstat <= boot_stats)) / (1 + n_bootstrap))
}


## Fitting models functions. In this case we have a logistic regression and
## a random forest using the `ranger` package implementation.
regstat <- function(X, y) {
  mod <- glm(y ~ X, family = "binomial")
  return(mean((fitted(mod) - mean(y)) ^ 2))
}

rf_fit <- function(X, y){
  rf_model <- randomForest::randomForest(as.data.frame(X), as.factor(y))
  rf_predictions <- predict(rf_model, type='prob')[, 2]
  return(mean((rf_predictions - mean(y)) ^ 2))
}

## Two-Sample Regression Test via Permutations
regression_test <- function(sample, generated, n_bootstrap = 10000,
                       func_fit = rf_fit) {
  sample <- as.matrix(sample)
  generated <- as.matrix(generated)
  
  y <- c(rep(0, nrow(sample)), rep(1, nrow(generated)))
  X <- rbind(sample, generated)
  stat <- func_fit(X, y)
  
  null <- replicate(n_bootstrap, {
    y <- base::sample(y)
    return(func_fit(X, y))
  })
  
  p_value <- (sum(stat <= null) + 1) / (n_bootstrap + 1)
  return(p_value)
}


## Functions to sample from different distribution on the first dimension.
## Corresponding to the three cases highlighted in Example 2.

sample_bernoulli_distribution <- function(n, d, theta = 0){
  if (d==1){
    sample <- as.numeric(purrr::rbernoulli(n = n, p = theta))
    return(sample)
  }
  
  sample_t <- as.numeric(purrr::rbernoulli(n = n, p = theta))
  sample_mvnorm <- mvrnorm(n = n, mu = rep(theta, d-1), Sigma = diag(d-1))
  return(as.matrix(cbind(sample_t, sample_mvnorm)))
}


sample_mixture_distribution <- function(n, d, theta = 0){
  components <- sample(1:2, prob = c(0.5, 0.5), size = n, replace = T)
  mus <- c(-theta, theta)
  sds <- sqrt(c(0.5, 0.5))
  sample_mixture <- rnorm(n = n, mean = mus[components], sd = sds[components])

  if (d==1){
    return(sample_mixture)
  }
  
  sample_mvnorm <- mvrnorm(n = n, mu = rep(0, d-1), Sigma = diag(d-1))
  return(as.matrix(cbind(sample_mixture, sample_mvnorm)))
}


sample_custom_variance_distribution <- function(n, d, theta = 0){
  if (d==1){
    sample <- rnorm(n = n, mean = 0, sd = sqrt(theta))
    return(sample)
  }
  
  sample_mvnorm <- mvrnorm(n = n, mu = rep(0, d), Sigma = diag(c(theta, rep(1, d-1))))
  return(sample_mvnorm)
}


## Testing for uniformity, using the Cramer von Mises uniformity test
uniform_test <- function(sample){
  test_results <- goftest::cvm.test(x = sample, null = 'punif')
  return(test_results$p.value)
}


###################################
### DIFFERENT LOCAL FUNCTIONS #####
###################################
## Functions to compute the local test, in which the p-values are obtained for
## all the three tests considered.


local_test_function_mixture <- function(n, d, theta, n_bootstrap = 10000,
                                model_func = rf_fit){
  
  sample_custom <- sample_mixture_distribution(n = n, d = d, theta = theta)
  sample_mvrnorm <- mvrnorm(n = n, mu = rep(0, d), Sigma = diag(d))
  
  regression_test_pvalue <- regression_test(sample = sample_custom,
                                  generated = sample_mvrnorm,
                                  n_bootstrap = n_bootstrap,
                                  func_fit = model_func)
  
  energy_test_pvalue <- energy_test(sample = sample_custom,
                                    generated = sample_mvrnorm,
                                    n_bootstrap = n_bootstrap)
  
  mmd_test_pvalue <- mmd_test(sample = sample_custom,
                              generated = sample_mvrnorm,
                              n_bootstrap = n_bootstrap)
  
  return(c(regression_test_pvalue, energy_test_pvalue, mmd_test_pvalue))
}


local_test_function_bernoulli <- function(n, d, theta, n_bootstrap = 10000,
                                          model_func = rf_fit){
  
  sample_custom <- sample_bernoulli_distribution(n = n, d = d, theta = theta)
  sample_mvrnorm <- mvrnorm(n = n, mu = rep(theta, d), Sigma = diag(d))
  
  regression_test_pvalue <- regression_test(sample = sample_custom,
                                  generated = sample_mvrnorm,
                                  n_bootstrap = n_bootstrap,
                                  func_fit = model_func)
  
  energy_test_pvalue <- energy_test(sample = sample_custom,
                                    generated = sample_mvrnorm,
                                    n_bootstrap = n_bootstrap)
  
  mmd_test_pvalue <- mmd_test(sample = sample_custom,
                              generated = sample_mvrnorm,
                              n_bootstrap = n_bootstrap)
  
  return(c(regression_test_pvalue, energy_test_pvalue, mmd_test_pvalue))
}


local_test_function_variance <- function(n, d, theta, n_bootstrap = 10000,
                                          model_func = rf_fit){
  
  sample_custom <- sample_custom_variance_distribution(n = n, d = d, theta = theta)
  sample_mvrnorm <- mvrnorm(n = n, mu = rep(0, d), Sigma = diag(d))
  
  regression_test_pvalue <- regression_test(sample = sample_custom,
                                  generated = sample_mvrnorm,
                                  n_bootstrap = n_bootstrap,
                                  func_fit = model_func)
  
  energy_test_pvalue <- energy_test(sample = sample_custom,
                                    generated = sample_mvrnorm,
                                    n_bootstrap = n_bootstrap)
  
  mmd_test_pvalue <- mmd_test(sample = sample_custom,
                              generated = sample_mvrnorm,
                              n_bootstrap = n_bootstrap)
  
  return(c(regression_test_pvalue, energy_test_pvalue, mmd_test_pvalue))
}



