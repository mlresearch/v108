library(plyr)
library(ggplot2)
library(latex2exp)

library(FITSio)
library(RcppCNPy)

devtools::load_all("likeliest")

n.neighbors <- 1
train_sizes <- c(1000, 5000)
n_test <- 200

##
ReadFits <- function(fname) {
    fits <- FITSio::readFITS(fname)

    nrow <- length(fits$col[[1]])
    ncol <- length(fits$col)

    dat <- matrix(NA, nrow, ncol)
    for (ii in seq_len(ncol)) {
        dat[, ii] <- fits$col[[ii]]
    }

    return(dat)
}

ReadThetas <- function(fname) {
    fits <- FITSio::readFITS(fname)

    omega.m <- as.numeric(fits$hdr[which(fits$hdr == "OMEGAM") + 1])
    sigma.8 <- as.numeric(fits$hdr[which(fits$hdr == "SIGMA8") + 1])

    return(data.frame(omega.m = omega.m,
                      sigma.8 = sigma.8))
}


ReadData <- function() {
    n.cosmos <- 248

    fnames <- sapply(seq_len(n.cosmos) - 1, function(ii) {
        rounded <- sprintf("%03d", ii)
        fname <- paste0("data/linc/dataMat/dataMat_cosmo", rounded, "_N10000.fits")
        return(fname)
    })

    xs <- lapply(fnames, ReadFits)
    x <- do.call(rbind, xs)

    x.obs <- matrix(c(507, 710, 692, 562, 256, 120, 24, 1, 0, 1, 0, 0, 0), nrow = 1)

    thetas <- lapply(fnames, ReadThetas)
    theta <- do.call(rbind, thetas)

    n.x <- nrow(xs[[1]])
    id <- rep(seq_len(n.cosmos), each = n.x)

    return(list(x.obs = x.obs, x = x, theta = theta, id = id))
}

lincdat <- ReadData()

SelectGroup <- function(n, ids) {
    selected <- rep(NA, length(ids))
    for (id in unique(ids)) {
        n.in.group <- sum(ids == id)
        stopifnot(n <= n.in.group)
        selected[id == ids] = c(rep(TRUE, n), rep(FALSE, n.in.group - n))
    }
    return(selected)
}

methods <- list(
    "KCDE" = function(x_train, theta_train, train_ids, theta_sample,
                               sample_ids) {
        sampler <- function(...) kcde_sample(..., diag = TRUE)
        return(round(local_sample(x_train = x_train, theta_train = theta,
                                  train_ids = train_ids, theta_sample = theta,
                                  sample_ids = sample_ids,
                                  k = n.neighbors, sample_fun = sampler)))
    },
    ## Gaussian density
    "Gaussian" = function(x_train, theta_train, train_ids, theta_sample,
                       sample_ids) {
        sampler <- gaussian_sample
        return(local_sample(x_train = x_train, theta_train = theta,
                            train_ids = train_ids, theta_sample = theta,
                            sample_ids = sample_ids,
                            k = n.neighbors, sample_fun = sampler))

    },

    ## Poisson density
    "Poisson" = function(x_train, theta_train, train_ids, theta_sample,
                         sample_ids) {
        sampler <- poisson_sample
        return(local_sample(x_train = x_train, theta_train = theta,
                            train_ids = train_ids, theta_sample = theta,
                            sample_ids = sample_ids,
                            k = n.neighbors, sample_fun = sampler))
    }
)

tests <- list(
    "Regression" = function(sample, generated, ...) {
        regression_test(sample, generated, n_bootstrap = 100)
    },
    "MMD" = function(sample, generated, ...) {
            energy_test(sample, generated, n_bootstrap = 100)
})


likelihood_evals <- list (
  "KCDE" = function(x_train, x_test) {
    return(kcde_loglik(x_train, x_test, diag=TRUE))
  },
  
  "Gaussian" = function(x_train, x_test) {
    return(return(gaussian_loglik(x_train, x_test)))
    
  },
  
  "Poisson" = function(x_train, x_test) {
    return(poisson_loglik(x_train, x_test))
  }
)

################################
#### Calculating test results

theta <- as.matrix(lincdat$theta)

params <- expand.grid(method = names(methods),
                      n_train = train_sizes)

outdir <- "data/linc/"
if (!dir.exists(outdir)) {
    dir.create(outdir, FALSE)
}

df <- mdply(params, function(method, n_train) {
    print(paste0(n_train, method))

    subset_indicator <- SelectGroup(n_train + n_test, lincdat$id)

    x.subset  <- lincdat$x[subset_indicator, ]
    subset_ids <- lincdat$id[subset_indicator]

    test_indicator <- SelectGroup(n_test, subset_ids) # so it's always the front

    x.test <- x.subset[test_indicator, ]
    test_ids <- subset_ids[test_indicator]

    x.train <- x.subset[!test_indicator, ]
    train_ids <- subset_ids[!test_indicator]

    samples <- methods[[method]](x_train = x.train, theta_train = theta, train_ids = train_ids,
        theta_sample = theta, sample_ids = test_ids)
    write.csv(samples, file = paste0(outdir, "/", method, "-", n_train, "-samples.csv"),
              row.names = FALSE)
    test_df <- gof_test(x.test, samples, test_ids, test_ids, tests)
    write.csv(test_df, file = paste0(outdir, "/", method, "-", n_train, "-tests.csv"),
              row.names = FALSE)

    test_df$method <- method
    test_df$omega.m <- theta[test_df$id, 1]
    test_df$sigma.8 <- theta[test_df$id, 2]
    return(test_df)
})

ddply(df, .(method, test, n_train), summarize,
      rez = round(ks.test(pval, "punif")$p.value, digits = 3)
)

fig <- ggplot(data = subset(df, test = "Regression"), mapping = aes(x = pval)) +
    geom_histogram() +
    facet_grid(n_train ~ method) +
    theme_bw()
print(fig)

fig <- ggplot(subset(df, (test == "Regression") & (n_train == 1000)),
              aes(x = omega.m, y = sigma.8, fill = pval))+
  geom_raster() +
    facet_grid(. ~ method) +
    xlab(TeX("$\\Omega_{M}$")) +
    ylab(TeX("$\\sigma_{8}$")) +
    scale_fill_distiller(name = "p-value",limits = c(0, 1),
                         breaks = c(0, 0.5, 1.0), palette = "Spectral") +
    theme_minimal(base_size = 20) +
    theme(legend.position = "bottom")
ggsave("figs/linc-gof.png", fig, height = 4, width = 8)


##########################################
# Calculating KL Divergence

kl_df <- mdply(params, function(method, n_train) {
  print(paste0(n_train, method))
  
  subset_indicator <- SelectGroup(n_train + n_test, lincdat$id)
  
  x.subset  <- lincdat$x[subset_indicator, ]
  subset_ids <- lincdat$id[subset_indicator]
  
  test_indicator <- SelectGroup(n_test, subset_ids) # so it's always the front
  
  x.test <- x.subset[test_indicator, ]
  test_ids <- subset_ids[test_indicator]
  
  x.train <- x.subset[!test_indicator, ]
  train_ids <- subset_ids[!test_indicator]
  
  train_lookup <- cumsum(seq_len(nrow(theta)) %in% train_ids)
  test_lookup <- cumsum(seq_len(nrow(theta)) %in% test_ids)
  theta_train <- theta[sort(unique(train_ids)), ]
  theta_test <- theta[sort(unique(test_ids)), ]
  n_x <- ncol(x.train)
  k <- n.neighbors
  search_obj <- RANN::nn2(theta_train, k = k, query = theta)
  search_obj_test <- RANN::nn2(theta_test, k = k, query = theta)
  
  lik_eval_mat <- matrix(NA, length(unique(test_ids)), 1)
  for (j in 1:length(unique(test_ids))) {
    group <- unique(test_ids)[j]
    idx <- search_obj$nn.idx[group, ]
    train_incl <- train_lookup[train_ids] %in% idx
    stopifnot(sum(train_incl) > 0)
    local_x_train <- x.train[train_incl, , drop=FALSE]
    stopifnot(nrow(local_x_train) != 0)
    
    idx_test <- search_obj_test$nn.idx[group, ]
    test_incl <- test_lookup[test_ids] %in% idx_test
    stopifnot(sum(test_incl) > 0)
    local_x_test <- x.test[test_incl, , drop=FALSE]
    stopifnot(nrow(local_x_test) != 0)
    
    lik_eval <- likelihood_evals[[method]](x_train = local_x_train, 
                                           x_test = local_x_test)
    lik_eval_mat[j, ] <- sum(lik_eval)
  }
  return(lik_eval_mat)
})


kl_df %>% filter(is.finite(`1`)) %>%
  group_by(method, n_train) %>%
  summarise_all(sum) %>%
  mutate(kl.div = -`1`/1e5)


