#' Return a sample with the correct proportions that sums correctly
fair_sample <- function(props, n) {
    props[!is.finite(props)] <- 0.0

    samples <- trunc(props * n / sum(props))

    for (ii in seq_len(n - sum(samples))) {
        idx <- sample(seq_along(samples), size = 1, prob = props)
        samples[idx]  <- samples[idx] + 1
    }

    stopifnot(sum(samples[idx]) == n)
    return(samples)
}


#' @export
ml_select <- function(n_samples, x_train, theta_train, train_ids, x_test,
                              proposed_thetas, loglik_fun = kcde_loglik,
                              n_bootstrap = 100, nn = 2) {
    theta_train <- as.matrix(theta_train)
    proposed_thetas <- as.matrix(proposed_thetas)

    x_test <- matrix(x_test, nrow = nrow(proposed_thetas),
                     ncol = ncol(x_test), byrow = TRUE)

    model <- local_loglik(x_train = x_train, theta_train = theta_train,
                          train_ids = train_ids,
                          x_test = x_test, theta_test = proposed_thetas,
                          test_ids = seq_len(nrow(proposed_thetas)), k = nn,
                          loglik_fun = loglik_fun, nboot = n_bootstrap)

    ## Select those theta values which have upper bound higher than
    ## highest lower bound
    mle_lower <- max(model$boot_lower)
    keep_indic <- model$boot_upper >= mle_lower
    n_new <- fair_sample(keep_indic, n_samples)

    return(list(theta = proposed_thetas,
                n_new = n_new,
                loglik = model$loglik,
                lower = model$boot_lower,
                var = model$boot_var,
                upper = model$boot_upper))
}

#' @export
uniform_select <- function(n_samples, x_train, theta_train, train_ids, x_test,
                            proposed_thetas, loglik_fun = kcde_loglik,
                            n_bootstrap = 100, nn = 2) {
    theta_train <- as.matrix(theta_train)
    proposed_thetas <- as.matrix(proposed_thetas)

    x_test <- matrix(x_test, nrow = nrow(proposed_thetas),
                     ncol = ncol(x_test), byrow = TRUE)

    model <- local_loglik(x_train = x_train, theta_train = theta_train,
                          train_ids = train_ids,
                          x_test = x_test, theta_test = proposed_thetas,
                          test_ids = seq_len(nrow(proposed_thetas)), k = nn,
                          loglik_fun = loglik_fun, nboot = n_bootstrap)

    n_new <- fair_sample(rep(1, nrow(proposed_thetas)), n_samples)

    return(list(theta = proposed_thetas,
                n_new = n_new,
                loglik = model$loglik,
                lower = model$boot_lower,
                var = model$boot_var,
                upper = model$boot_upper))
}

#' @export
variance_select <- function(n_samples, x_train, theta_train, train_ids, x_test,
                            proposed_thetas, loglik_fun = kcde_loglik,
                            n_bootstrap = 100, nn = 2) {
    theta_train <- as.matrix(theta_train)
    proposed_thetas <- as.matrix(proposed_thetas)

    x_test <- matrix(x_test, nrow = nrow(proposed_thetas),
                     ncol = ncol(x_test), byrow = TRUE)

    model <- local_loglik(x_train = x_train, theta_train = theta_train,
                          train_ids = train_ids,
                          x_test = x_test, theta_test = proposed_thetas,
                          test_ids = seq_len(nrow(proposed_thetas)), k = nn,
                          loglik_fun = loglik_fun, nboot = n_bootstrap)

    model$boot_var[!is.finite(model$boot_var)] <- max(model$boot_var, na.rm = TRUE)
    n_new <- fair_sample(model$boot_var, n_samples)

    return(list(theta = proposed_thetas,
                n_new = n_new,
                loglik = model$loglik,
                lower = model$boot_lower,
                var = model$boot_var,
                upper = model$boot_upper))
}

#' @export
likelihood_select <- function(n_samples, x_train, theta_train, train_ids, x_test,
                              proposed_thetas, loglik_fun = kcde_loglik,
                              n_bootstrap = 100, nn = 2) {
    theta_train <- as.matrix(theta_train)
    proposed_thetas <- as.matrix(proposed_thetas)

    x_test <- matrix(x_test, nrow = nrow(proposed_thetas),
                     ncol = ncol(x_test), byrow = TRUE)

    model <- local_loglik(x_train = x_train, theta_train = theta_train,
                          train_ids = train_ids,
                          x_test = x_test, theta_test = proposed_thetas,
                          test_ids = seq_len(nrow(proposed_thetas)), k = nn,
                          loglik_fun = loglik_fun, nboot = n_bootstrap)

    n_new <- fair_sample(exp(model$loglik - max(model$loglik)), n_samples)

    return(list(theta = proposed_thetas,
                n_new = n_new,
                loglik = model$loglik,
                lower = model$boot_lower,
                var = model$boot_var,
                upper = model$boot_upper))
}

#' @export
ci_select <- function(n_samples, x_train, theta_train, train_ids, x_test,
                      proposed_thetas, loglik_fun = kcde_loglik,
                      n_bootstrap = 100, nn = 2, alpha = 0.05) {
    theta_train <- as.matrix(theta_train)
    proposed_thetas <- as.matrix(proposed_thetas)

    x_test <- matrix(x_test, nrow = nrow(proposed_thetas),
                     ncol = ncol(x_test), byrow = TRUE)

    model <- local_loglik(x_train = x_train, theta_train = theta_train,
                          train_ids = train_ids,
                          x_test = x_test, theta_test = proposed_thetas,
                          test_ids = seq_len(nrow(proposed_thetas)), k = nn,
                          loglik_fun = loglik_fun, nboot = n_bootstrap)

    ## Select those theta values which have upper bound higher than
    ## highest lower bound
    mle_idx <- which.max(model$loglik)
    threshold <- log(qchisq(1 - 0.05, df = 1)) - max(model$loglik)

    keep_indic <- (model$boot_lower <= threshold) &&
        (threshold <= model$boot_upper)
    n_new <- fair_sample(keep_indic, n_samples)

    return(list(theta = proposed_thetas,
                n_new = n_new,
                loglik = model$loglik,
                lower = model$boot_lower,
                var = model$boot_var,
                upper = model$boot_upper))
}

supersample_theta <- function(theta_grid) {
    new_theta <- theta_grid[-1] - diff(sort(theta_grid)) / 2
    return(c(theta_grid, new_theta))
}
