#' @export
gaussian_loglik <- function(x_train, x_test, sigma = NULL) {
    mu <- colMeans(x_train)

    if (is.null(sigma)) {
        sigma <- cov(x_train)
    }

    return(mvtnorm::dmvnorm(x_test, mu, sigma, log = TRUE))
}

#' @export
gaussian_sample <- function(n_samples, x_train, sigma = NULL) {
    n_x <- ncol(x_train)
    mu <- colMeans(x_train)

    if (is.null(sigma)) {
        sigma <- cov(x_train)
    }

    return(mvtnorm::rmvnorm(n_samples, mu, sigma))
}

#' @export
poisson_loglik <- function(x_train, x_test) {
    mu <- colMeans(x_train)
    loglik <- apply(x_test, 1, function(xx) {
        sum(dpois(xx, mu, log = TRUE))
    })
}

#' @export
poisson_sample <- function(n_samples, x_train) {
    n_x <- ncol(x_train)
    mu <- colMeans(x_train)

    return(matrix(rpois(n_x * n_samples, mu), n_samples, n_x, byrow = TRUE))
}
