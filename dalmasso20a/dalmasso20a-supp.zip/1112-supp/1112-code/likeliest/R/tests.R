## Goodness of fit tests

#' @export
energy_test <- function(sample, generated, n_bootstrap = 10000) {
    sample <- as.matrix(sample)
    generated <- as.matrix(generated)
    combined <- rbind(sample, generated)

    etest <- energy::eqdist.etest(combined,
                                  sizes = c(nrow(sample), nrow(generated)),
                                  R = n_bootstrap)
    return(etest$p.value)
}

#' @export
mmd_test <- function(sample, generated, n_bootstrap = 10000) {
    sample <- as.matrix(sample)
    generated <- as.matrix(generated)
    combined <- rbind(sample, generated)

    kpar <- list(sigma = kernlab::sigest(combined, scaled = FALSE)[2])

    mmdstat <- kernlab::mmdstats(kernlab::kmmd(sample, generated, kpar = kpar))[1]

    boot_stats <- replicate(n_bootstrap, {
        boot_ids <- sample(nrow(combined), nrow(sample))
        sample_boot <- combined[boot_ids, , drop = FALSE]
        generated_boot <- combined[-boot_ids, , drop = FALSE]
        return(kernlab::mmdstats(kernlab::kmmd(sample_boot, generated_boot, kpar = kpar))[1])
    })

    return((1 + sum(mmdstat <= boot_stats)) / (1 + n_bootstrap))
}

regstat <- function(X, y) {
    ## mod <- glm(y ~ X, family = "binomial")
    mod <- randomForest::randomForest(X, as.factor(y))
    prob <- predict(mod, type = "prob")[, 2]
    return(mean((prob - mean(y)) ^ 2))
}

#' @export
regression_test <- function(sample, generated, n_bootstrap = 10000) {
    sample <- as.matrix(sample)
    generated <- as.matrix(generated)

    y <- c(rep(0, nrow(sample)), rep(1, nrow(generated)))
    X <- rbind(sample, generated)

    stat <- regstat(X, y)

    null <- replicate(n_bootstrap, {
        y <- sample(y)
        return(regstat(X, y))
    })

    return((sum(stat <= null) + 1) / (n_bootstrap + 1))
}

gof_test <- function(x_test, samples, test_ids, sample_ids, tests, parallel = FALSE,
                     ...) {
    return(plyr::ldply(unique(test_ids), function(id) {
        real <- x_test[test_ids == id, ]
        gen <- samples[sample_ids == id, ]

        return(plyr::ldply(names(tests), function(name) {
            data.frame(id = id, test = name, pval = tests[[name]](real, gen, ...))
        }))
    }, .parallel = parallel))
}
