#' @export
local_loglik <- function(x_train, theta_train, train_ids,
                         x_test, theta_test, test_ids,
                         epsilon = NULL, k = NULL,
                         loglik_fun, nboot = 0, alpha = 0.95) {

    ## Restrict theta_train to only be those points which have been
    ## observed; need to update the indices appropriately
    train_lookup <- cumsum(seq_len(nrow(theta_train)) %in% train_ids)
    theta_train <- theta_train[sort(unique(train_ids)), ]

    if (!is.null(epsilon)) {
        search_obj <- RANN::nn2(theta_train, k = nrow(theta_train),
                                query = theta_test, searchtype = "radius",
                                radius = epsilon)
        stopifnot((all(rowSums(search_obj$nn.idx != 0)[unique(test_ids)] > 0)))
    }
    if (!is.null(k)) {
        search_obj <- RANN::nn2(theta_train, k = k, query = theta_test)
    }

    if (nboot != 0) {
        boot_lower <- rep(NA, nrow(x_test))
        boot_upper <- rep(NA, nrow(x_test))
        boot_var <- rep(NA, nrow(x_test))
    }

    loglik <- rep(NA, nrow(x_test))
    for (group in unique(test_ids)) {
        idx <- search_obj$nn.idx[group, ]
        train_incl <- train_lookup[train_ids] %in% idx
        stopifnot(sum(train_incl) > 0)
        local_x_train <- x_train[train_incl, , drop = FALSE]
        stopifnot(nrow(local_x_train) != 0)

        test_incl <- test_ids == group
        local_x_test <- x_test[test_incl, , drop = FALSE]
        tmp <- rep(NA, nrow(local_x_test))
        tryCatch(tmp <- loglik_fun(local_x_train, local_x_test),
                 error = function(e) {
                     tmp <<- rep(NA, nrow(local_x_test))
                 })
        loglik[test_incl] <- tmp

        if (nboot != 0) {
            boots <- matrix(NA, nboot, nrow(local_x_test))
            for (ii in seq_len(nboot)) {
                x_boot <- local_x_train[sample(nrow(local_x_train), replace = TRUE), ]
                tryCatch(tmp <- loglik_fun(x_boot, local_x_test),
                         error = function(e) {
                             tmp <- rep(NA, nrow(local_x_test))
                         })
                boots[ii, ] <- tmp
            }
            boot_lower[test_incl] <- apply(boots, 2, quantile, (1 - alpha) / 2)
            boot_upper[test_incl] <- apply(boots, 2, quantile, 1 - (1 - alpha) / 2)
            boot_var[test_incl] <- apply(boots, 2, var)
        }
    }

    if (nboot != 0) {
        return(list(loglik = loglik,
                    boot_lower = boot_lower,
                    boot_upper = boot_upper,
                    boot_var = boot_var))
    }
    return(loglik)
}

#' @export
local_sample <- function(x_train, theta_train, train_ids, theta_sample,
                         sample_ids, epsilon = NULL, k = NULL, sample_fun) {
    ## Restrict theta_train to only be those points which have been
    ## observed; need to update the indices appropriately
    train_lookup <- cumsum(seq_len(nrow(theta_train)) %in% train_ids)
    theta_train <- theta_train[sort(unique(train_ids)), ]

    n_x <- ncol(x_train)

    if (!is.null(epsilon)) {
        search_obj <- RANN::nn2(theta_train, k = nrow(theta_train),
                                query = theta_sample,
                                searchtype = "radius", radius = epsilon)
        stopifnot((all(rowSums(search_obj$nn.idx != 0)[unique(sample_ids)] > 0)))
    }
    if (!is.null(k)) {
        search_obj <- RANN::nn2(theta_train, k = k, query = theta_sample)
    }

    samples <- matrix(NA, length(sample_ids), n_x)
    for (group in unique(sample_ids)) {
        idx <- search_obj$nn.idx[group, ]
        train_incl <- train_lookup[train_ids] %in% idx
        stopifnot(sum(train_incl) > 0)
        local_x_train <- x_train[train_incl, , drop=FALSE]
        stopifnot(nrow(local_x_train) != 0)

        test_incl <- sample_ids == group
        n_in_group <- sum(test_incl)
        samples[test_incl, ] <- sample_fun(n_in_group, local_x_train)
    }

    return(samples)
}
