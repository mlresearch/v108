#' Select from groups
#' @export
select_group <- function(n, ids) {
    selected <- rep(NA, length(ids))
    for (id in unique(ids)) {
        n_in_group <- sum(ids == id)
        stopifnot(n <= n_in_group)
        selected[id == ids] = c(rep(TRUE, n), rep(FALSE, n_in_group - n))
    }
    return(selected)
}
