#' @export
safe_bandwidth <- function(x) {
    tryCatch({
        return(ks::hpi(x))
    },
    error =  {return(1e-8)}
    )
}

#' @export
kcde_loglik <- function(x_train, x_test, bandwidth = NULL, diag = FALSE) {
  n_x <- nrow(x_train)
  d_x <- ncol(x_train)
  
  if (is.null(bandwidth)) {
    if (ncol(x_train) == 1) {
      bandwidth <- ks::hpi(x_train)
    } else {
      if (diag) {
        bandwidth <- diag(apply(x_train, 2, safe_bandwidth))
        ##bandwidth <- ks::Hpi.diag(x_train)
      } else {
        bandwidth <- ks::Hpi(x_train)
      }
    }
  }
  
  #lik <- rep(NA, nrow(x_test))
  #for (ii in seq_len(nrow(x_test))) {
  # there's issues with large x_test points since apparently it allocates an entire vector for it?
  #    lik[ii] <- ks::kde(x_train, H = bandwidth, binned = FALSE, eval.points = x_test[ii, ])$estimate
  #}
  
  lik <- ks::kde(as.matrix(as.numeric(x_train)), H = bandwidth, binned=FALSE,
                 eval.points = as.matrix(as.numeric(x_test)))$estimate
  return(log(lik))
}

#' @export
kcde_sample <- function(n_samples, x_train, bandwidth = NULL, diag = FALSE) {
    n_x <- nrow(x_train)
    d_x <- ncol(x_train)

    if (is.null(bandwidth)) {
        if (ncol(x_train) == 1) {
            bandwidth <- ks::hpi(x_train)
        } else {
            if (diag) {
                bandwidth <- diag(apply(x_train, 2, safe_bandwidth))
                ## bandwidth <- ks::Hpi.diag(x_train)
            } else {
                bandwidth <- ks::Hpi(x_train)
            }
        }
    }
    sqrt_bandwidth <- expm::sqrtm(bandwidth)

    samples <- matrix(NA, nrow = n_samples, ncol = d_x)
    for (ii in seq_len(n_samples)) {
        mu <- x_train[sample(n_x, 1), ]
        noise <- mvtnorm::rmvnorm(1, rep(0, d_x)) %*% sqrt_bandwidth
        samples[ii, ] <- mu + noise
    }
    return(samples)
}
