#' Estimate a global bandwidth
#' @export
global_bandwidth <- function(x, ids, scaled = FALSE) {
    sigma <- matrix(0.0, ncol(x), ncol(x))
    l_ply(unique(ids), function(id) {
        x_tab <- x[ids == id, ]
        sigma <<- sigma + cov(x_tab)
    })
    sigma <- sigma / length(unique(ids))
    n <- nrow(x)
    d <- ncol(x)

    if (scaled) {
        bandwidth_const <- (4 / (n * (d + 2))) ^ (2 / (d + 4))
        sigma <- sigma * bandwidth_const
    }

    return(sigma)
}
