transform <- function(x_train, x_test, train_ids, test_ids,
                      shift = TRUE, scale = TRUE) {

    stopifnot(all(sort(unique(train_ids)) == sort(unique(test_ids))))

    xt_train <- x_train
    xt_test <- x_test
    log_adjust <- rep(0, nrow(x_test))
    for (id in unique(train_ids)) {
        train_indic <- train_ids == id
        train_subset <- x_train[train_indic, , drop = FALSE]
        test_indic <- test_ids == id
        test_subset <- x_test[test_indic, , drop = FALSE]

        if (shift) {
            mu <- colMeans(train_subset)
            xt_train[train_indic, ] <- sweep(train_subset, 2, mu)
            xt_test[test_indic, ] <-  sweep(test_subset, 2, mu)
        }

        if (scale) {
            sigma <- cov(xt_train[train_indic, ])
            scale_mat <- expm::sqrtm(solve(sigma))

            xt_train[train_indic, ] <-  xt_train[train_indic, ] %*% scale_mat
            xt_test[test_indic, ] <-  xt_test[test_indic, ] %*% scale_mat
            log_adjust[test_indic] <- determinant(scale_mat, log = TRUE)$modulus
        }
    }

    return(list(x_train = xt_train,
                x_test = xt_test,
                log_adjust = log_adjust))
}
