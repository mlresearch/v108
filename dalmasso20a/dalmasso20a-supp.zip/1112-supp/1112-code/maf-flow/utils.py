import numpy as np
from sklearn.ensemble import RandomForestClassifier


def repeat(tensor, dims):
    if len(dims) != len(tensor.shape):
        raise ValueError("The length of the second argument must equal the number of dimensions of the first.")
    for index, dim in enumerate(dims):
        repetition_vector = [1]*(len(dims)+1)
        repetition_vector[index+1] = dim
        new_tensor_shape = list(tensor.shape)
        new_tensor_shape[index] *= dim
        tensor = tensor.unsqueeze(index+1).repeat(repetition_vector).reshape(new_tensor_shape)
    return tensor


def regstat(X, y):
    model = RandomForestClassifier(n_estimators=10)
    model.fit(X=X, y=y)
    probabilities = model.predict_proba(X)[:, 1]
    return np.average((probabilities - np.average(y)) ** 2)


def ilmun_test(sample, generated, d, n_bootstrap=100):

    y = np.concatenate((np.zeros((sample.shape[0],)), np.ones((generated.shape[0],))))
    X = np.vstack((sample, generated)).reshape(-1, d)

    stat = regstat(X, y)
    null = [regstat(X=X, y=np.random.choice(y, size=y.shape)) for _ in range(n_bootstrap)]

    return (np.sum(null >= stat) + 1) / float(n_bootstrap + 1)
