library(plyr)
library(kernlab)

devtools::load_all("likeliest")

## Parameters
prefix <- "data/synthetic/"
dir.create(prefix, showWarnings = FALSE)
train_sizes <- c(50, 100, 500, 1000, 10000)
n_iters <- 100

n_cores <- 10
if (!is.na(n_cores)) {
    library(doMC)
    doMC::registerDoMC(cores = n_cores)
}

logiks <- function(x_test, samples, test_ids, sample_ids) {
    return(ldply(unique(sample_ids), function(id) {
        theta <- theta_grid[id, ]



        return(data.frame(med_dist = median(d),
                          id = id))
    }))
}

## methods <- c("kcde", "gauss", "poisson", "maf")
methods <- c("kcde", "kcde-discrete", "gauss", "poisson", "true")

sims <- expand.grid(n_train = train_sizes,
                    method = methods,
                    iter = seq_len(n_iters))

m_ply(sims, function(n_train, method, iter) {
    dirname <- paste0(prefix, method, "-", n_train, "-", iter, "/")
    print(dirname)
    fname <- paste0(dirname, "dists.csv")
    if (file.exists(fname)) {
        ## warning(paste("Sim not ran:", dirname))
        warning(paste("Test already ran:", dirname))
        return()
    }

    dat <- readRDS(paste0(dirname, "samples.rds"))
    set.seed(iter)
    df <- with(dat, distances(x_test, samples, test_ids, sample_ids))
    write.csv(df, file = fname, row.names = FALSE)
})
