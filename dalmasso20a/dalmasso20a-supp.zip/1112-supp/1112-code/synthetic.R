gen_data <- function(theta) {
    if (theta[2] > 0.5) {
        mu <- 10000
    } else {
        mu <- 1
    }

    while (TRUE) {
        draw <- rpois(2, mu)
        if (theta[1] > 0.5) {
            return(draw)
        } else {
            if (diff(draw)[1] <= 0) {
                return(draw)
            }
        }
    }
}

synthetic_data <- function(n_train, n_test, n_grid = 100) {
    n_each <- floor(sqrt(n_grid))
    stopifnot(n_each ^ 2 == n_grid)

    theta <- expand.grid(theta1 = seq(0, 1, length.out = n_each + 2)[-c(1, n_each)],
                         theta2 = seq(0, 1, length.out = n_each + 2)[-c(1, n_each)])

    train_ids <- rep(1:nrow(theta), each = n_train)
    test_ids <- rep(1:nrow(theta), each = n_test)

    x_train <- t(apply(theta[train_ids, ], 1, gen_data))
    x_test <- t(apply(theta[test_ids, ], 1, gen_data))

    return(list(x_train = x_train,
                x_test = x_test,
                train_ids = train_ids,
                test_ids = test_ids,
                theta = theta))
}
