library(readr)
library(tidyverse)
library(randomForest)
library(pdp)
library(edarf)
library(caret)
library(latex2exp)

## Function to fit Random Forest Model and Calculate statistics
rf_fit <- function(X, y){
  rf_model <- randomForest::randomForest(as.data.frame(X), as.factor(y))
  rf_predictions <- predict(rf_model, type='prob')[, 2]
  return(mean((rf_predictions - mean(y)) ^ 2))
}

# Setup variables and import data: simulation of fiducial point and fiducial
# simulations are imported
n_bootstrap <- 100
gaussian_1000_samples <- read_csv(file = "data/fiducial_gaussian_sample_200training.csv",
                                  col_names = c("Bin1", "Bin2", "Bin3", "Bin4", "Bin5", "Bin6", "Bin7")) %>%
  as_tibble()
dim(gaussian_1000_samples)
gaussian_1000_samples

sim_samples <- read_csv(file = "data/fiducial_testing_sample.csv") %>%
  as_tibble()
dim(sim_samples)
sim_samples


## Partial Dependency Plot
generated <- sim_samples
sample <- gaussian_1000_samples
sample <- as.matrix(sample)
generated <- as.matrix(generated)

y <- c(rep(0, nrow(sample)), rep(1, nrow(generated)))
X <- rbind(sample, generated)
full_data <- as.data.frame(cbind(X, y))
full_data$y <- as.character(full_data$y)
full_data$y <- as.factor(full_data$y)
rf_model <- randomForest::randomForest(y ~ ., data=full_data, importance=TRUE)

pd_temp_df <- edarf::partial_dependence(fit=rf_model, vars=paste0('Bin7'),
                                        data=as.data.frame(X), n=c(400, 400)) #%>%

plot(pd_temp_df[,1], pd_temp_df[,3], type='l', main=paste0('Bin7'),
     xlab='Bin7', ylab='PROB')
for (val in seq(0,150)){
  abline(v=val, lty=2)
}

## Local Comparison in High Dimension -- TODO: include it in a function
# Getting the data
generated <- sim_samples
sample <- gaussian_1000_samples
sample <- as.matrix(sample)
generated <- as.matrix(generated)

# Merge them together
y <- c(rep(0, nrow(sample)), rep(1, nrow(generated)))
X <- rbind(sample, generated)

# Create training and test
train_size <- floor(0.66*nrow(X)) 
train_id <- sample(seq_len(nrow(X)),size = train_size)
X_train <- X[train_id, ]
X_test <- X[-train_id, ]
y_train <- y[train_id]
y_test <- y[-train_id]

full_data_train <- as.data.frame(cbind(X_train, y_train))
full_data_train$y <- as.character(full_data_train$y)
full_data_train$y <- as.factor(full_data_train$y)
rf_model <- randomForest::randomForest(X_train, as.factor(y_train))

rf_pred_vec <- as.numeric(predict(rf_model, newdata = as.data.frame(X_test), type='prob')[, 2])
stat_vec <- as.numeric((rf_pred_vec - mean(y_train))^2)

stat_mat <- c()
for (k in c(1:500)){
  y_train <- base::sample(y_train)
  rf_model_temp <- randomForest::randomForest(X_train, as.factor(y_train))
  rf_pred_vec <- as.numeric(predict(rf_model_temp, newdata = as.data.frame(X_test),  type='prob')[, 2])
  stat_mat <- cbind(as.numeric((rf_pred_vec - mean(y_train))^2), stat_mat)
}

pval_vec <- numeric(nrow(X_test))
for (k in c(1:n_bootstrap)){
  stat_temp <- stat_vec[k]
  null <- stat_mat[k, ]
  p_val_temp <- (sum(stat_temp <= null) + 1) / (n_bootstrap + 1)
  pval_vec[k] <- p_val_temp
}
sign_vec <- ifelse(pval_vec < 0.05/(nrow(X) - train_size), 'Significant', 'Not Significant')
sign_df <- tibble(sign=as.factor(sign_vec), 
                  y_level=ifelse(sign_vec == 'Significant', 0.41, 0.43),
                  x_level = as.numeric(X_test[, 7]))

## PLOT THE RESULTS

# Limited
ggplot() +
  geom_line(aes(x=Bin7, y=`1`), data=pd_temp_df %>% filter(Bin7 >= 75, Bin7 <= 105), lwd=1.5) +
  geom_point(aes(x=x_level, y=y_level, shape=sign), size=6, color='red', 
             data=sign_df %>% filter(x_level >= 75, x_level <=105, sign=='Significant')) +
  geom_hline(yintercept = 0.5, linetype=4) +
  theme_bw() + 
  labs(x = expression('X'[7]), y = 'P(Y=1|X)') +
  theme(axis.title.x = element_text(size = 28),
        axis.text.x = element_text(size = 20),
        axis.title.y = element_text(size = 28),
        axis.text.y = element_text(size = 20),
        title = element_text(size=26),
        panel.grid.minor.x = element_line(colour="black", size=0.15, linetype=2),
        panel.grid.major.x = element_line(colour="black", size=0.15, linetype=2)) +
  scale_x_continuous(minor_breaks = seq(75,105)) +
  ylim(c(0.4, 0.6)) +
  scale_shape_manual(values=c(4)) +
  scale_color_manual(values=c('red', 'blue')) +
  labs(shape=TeX('Test $\\left|\\hat{m}(X) - \\hat{\\pi_1}\\right|$')) +
  theme(legend.text = element_text(size=26),
        legend.title =  element_text(size=26))


