import numpy as np
import matplotlib.pylab as plt
plt.rcParams['ps.useafm'] = True
plt.rcParams['pdf.use14corefonts'] = True
plt.rcParams['text.usetex'] = True

def calcError(stopping_time,Optimal_times,exec_num,path):
    stopping_time_error = np.abs(stopping_time - Optimal_times)
    stopping_time_error_mean = stopping_time_error.mean(axis=0)
    stopping_time_error_var = stopping_time_error.std() / np.sqrt(exec_num)
    index_stopping = np.argmin(stopping_time_error_mean)

    s = "{0} \pm {1}\n".format(stopping_time_error_mean, round(stopping_time_error_var, 2))
    with open(path, mode='w') as f:
        f.write(s)

    return index_stopping

def calcErrors(path, stopping_times,exec_num):

    calcError(stopping_times["GroundTruth"],stopping_times["Optimal"],exec_num,path)
    calcError(stopping_times["GroundTruth"],stopping_times["Optimal"],exec_num,path)
    best_indecies = {}
    best_indecies["PAC"] = calcError(stopping_times["PAC"],stopping_times["Optimal"][:,None],exec_num,path)
    best_indecies["CV"]  = calcError(stopping_times["CV"],stopping_times["Optimal"][:,None],exec_num,path)
    best_indecies["Maxvar"]  = calcError(stopping_times["Maxvar"],stopping_times["Optimal"][:,None],exec_num,path)

    return best_indecies


def plot_stopping_time(stopping_criterion, stopping_times, start_num, train_size,best_indecies,exec_num,data_name,save_dir):
    f_size = 30
    label_f_size = 40
    Optimal_criteria = stopping_criterion["Optimal"]
    Optimal_criteria_mean = Optimal_criteria.mean(axis=0)
    ymin = Optimal_criteria_mean.min()
    ymax = Optimal_criteria_mean.max()

    stopping_times_mean = {}
    stopping_times_mean["Optimal"] = stopping_times["Optimal"].mean(axis=0)
    stopping_times_mean["RUN"] = stopping_times["RUN"].mean(axis=0)
    stopping_times_mean["GroundTruth"] = stopping_times["GroundTruth"].mean(axis=0)
    stopping_times_mean["PAC"] = stopping_times["PAC"].mean(axis=0)[best_indecies["PAC"]]
    stopping_times_mean["Maxvar"] = stopping_times["Maxvar"].mean(axis=0)[best_indecies["Maxvar"]]
    stopping_times_mean["CV"] = stopping_times["CV"].mean(axis=0)[best_indecies["CV"]]

    stopping_times_var = {}
    stopping_times_var["Optimal"] = stopping_times["Optimal"].std(axis=0) / np.sqrt(exec_num)
    stopping_times_var["RUN"] = stopping_times["RUN"].std(axis=0) / np.sqrt(exec_num)
    stopping_times_var["GroundTruth"] = stopping_times["GroundTruth"].std(axis=0) / np.sqrt(exec_num)
    stopping_times_var["PAC"] = stopping_times["PAC"].std(axis=0)[best_indecies["PAC"]] / np.sqrt(exec_num)
    stopping_times_var["Maxvar"] = stopping_times["Maxvar"].std(axis=0)[best_indecies["Maxvar"]] / np.sqrt(exec_num)
    stopping_times_var["CV"] = stopping_times["CV"].std(axis=0)[best_indecies["CV"]] / np.sqrt(exec_num)

    fig = plt.figure(0, [12, 8])
    fig.subplots_adjust(bottom=0.15,left=0.15)
    ax = fig.add_subplot(111)
    ax.cla()
    ax.set_xlabel("data size", fontsize=label_f_size)
    ax.set_ylabel("error", fontsize=label_f_size)
    iterations = np.array(range(start_num, train_size))
    ax.plot(iterations, Optimal_criteria_mean, c='k')

    ax.plot([stopping_times_mean["Optimal"], stopping_times_mean["Optimal"]], [ymin, ymax], c='k', label='optimal time')
    ax.errorbar(stopping_times_mean["Optimal"], 0.2*ymax+0.8*ymin, xerr=stopping_times_var["Optimal"], capsize=10, fmt='o', markersize=5, ecolor='k',
                 markeredgecolor="k", color='k')

    ax.plot([stopping_times_mean["RUN"], stopping_times_mean["RUN"]], [ymin, ymax], c='r', label='proposed', linestyle="--", linewidth=4)
    ax.errorbar(stopping_times_mean["RUN"], 0.22*ymax+0.78*ymin, xerr=stopping_times_var["RUN"], capsize=10, fmt='o', markersize=5, ecolor='r',
                 markeredgecolor="r", color='r')

    ax.plot([stopping_times_mean["PAC"], stopping_times_mean["PAC"]], [ymin, ymax], c='b', label='PAC Bayesian', linestyle="dashed")
    ax.errorbar(stopping_times_mean["PAC"], 0.24*ymax+0.76*ymin, xerr=stopping_times_var["PAC"], capsize=10, fmt='o', markersize=5, ecolor='b',
                 markeredgecolor="b", color='b')

    ax.plot([stopping_times_mean["GroundTruth"], stopping_times_mean["GroundTruth"]], [ymin, ymax], c='purple', label='Ground truth', linestyle="dashdot")
    ax.errorbar(stopping_times_mean["GroundTruth"], 0.26*ymax+0.74*ymin, xerr=stopping_times_var["GroundTruth"], capsize=10, fmt='o', markersize=5, ecolor='purple',
                 markeredgecolor="purple", color='purple')

    ax.plot([stopping_times_mean["Maxvar"], stopping_times_mean["Maxvar"]], [ymin, ymax], c='g', label='max variance', linestyle="dotted")
    ax.errorbar(stopping_times_mean["Maxvar"], 0.28*ymax+0.72*ymin, xerr=stopping_times_var["Maxvar"], capsize=10, fmt='o', markersize=5, ecolor='g',
                 markeredgecolor="g", color='g')

    ax.plot([stopping_times_mean["CV"], stopping_times_mean["CV"]], [ymin, ymax], c='cyan', label='cross varidation', linewidth=4)
    ax.errorbar(stopping_times_mean["CV"], 0.3*ymax+0.7*ymin, xerr=stopping_times_var["CV"], capsize=10, fmt='o', markersize=5, ecolor='cyan',
                 markeredgecolor="cyan", color='cyan')

    if data_name is "artificial":
        plt.legend(loc='upper right', fontsize=f_size)
    ax.tick_params(labelsize=22)
    plt.savefig(save_dir + "ex_" + data_name + ".pdf")
