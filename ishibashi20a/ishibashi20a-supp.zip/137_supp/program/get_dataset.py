import numpy as np
import csv

def f(x):
    return np.exp(-(x - 2) ** 2) + np.exp(-(x - 6) ** 2 / 10) + 1 / (x ** 2 + 1)

def f_add_noise(x, noise=0.03):
    F = f(x)
    return F + np.random.normal(0, noise, x.shape[0])

def get_dataset(data_name):
    if data_name == "artificial":
        xmin=-5
        xmax=15
        all_size = 2000
        noise_level = 0.03
        input = ((xmax - xmin) * np.random.rand(all_size) + xmin)[:, np.newaxis]
        output = f_add_noise(input[:, 0], noise_level)
        return [input, output]

    if data_name == "housing":
        dataset = np.loadtxt("./dataset/housing/housing.data")
        input = dataset[:,:-1]
        input = (input - input.mean(axis=0)[np.newaxis,:])/input.std(axis=0)
        output = dataset[:,-1]
        output = (output - output.mean())/output.std()
        return [input,output]

    if data_name == "power_plant":
        dataset = np.loadtxt("./dataset/power_plant/ccpp.txt")
        input = dataset[:,:-1]
        input = (input - input.mean(axis=0)[np.newaxis,:])/input.std(axis=0)
        output = dataset[:,-1]
        output = (output - output.mean())/output.std()
        return [input,output]

    if data_name == "carbon_nanotubes":
        dataset = np.loadtxt("./dataset/carbon_nanotubes/carbon_nanotubes.txt")
        input = dataset[:,:-1]
        input = (input - input.mean(axis=0)[np.newaxis,:])/input.std(axis=0)
        output = dataset[:,-1]
        output = (output - output.mean())/output.std()
        return [input,output]

    if data_name == "protein":
        dataset = np.loadtxt("./dataset/protein/CASP.txt")
        input = dataset[:,:-1]
        input = (input - input.mean(axis=0)[np.newaxis,:])/input.std(axis=0)
        output = dataset[:,-1]
        output = (output - output.mean())/output.std()
        return [input,output]

    if data_name == "yacht":
        dataset = np.loadtxt("./dataset/yacht/hydro.txt")
        input = dataset[:,:-1]
        input = (input - input.mean(axis=0)[np.newaxis,:])/input.std(axis=0)
        output = dataset[:,-1]
        output = (output - output.mean())/output.std()
        return [input,output]

    if data_name == "airfoil":
        dataset = np.loadtxt("./dataset/airfoil/airfoil_self_noise.txt")
        input = dataset[:,:-1]
        input = (input - input.mean(axis=0)[np.newaxis,:])/input.std(axis=0)
        output = dataset[:,-1]
        output = (output - output.mean())/output.std()
        return [input,output]

    if data_name == "concrete":
        dataset = np.loadtxt("./dataset/concrete/concrete_data.txt")
        input = dataset[:,:-1]
        input = (input - input.mean(axis=0)[np.newaxis,:])/input.std(axis=0)
        output = dataset[:,-1]
        output = (output - output.mean())/output.std()
        return [input,output]

    if data_name == "energy":
        dataset = np.loadtxt("./dataset/energy/energy.txt")
        input = dataset[:,3:-2]
        input = (input - input.mean(axis=0)[np.newaxis,:])/input.std(axis=0)
        output = dataset[:,2]
        output = (output - output.mean())/output.std()
        return [input,output]

    if data_name == "white_wine":
        dataset = np.loadtxt("./dataset/wine/winequality-white.txt")
        input = dataset[:,:-1]
        input = (input - input.mean(axis=0)[np.newaxis,:])/input.std(axis=0)
        output = dataset[:,-1]
        output = (output - output.mean())/output.std()
        return [input,output]

    if data_name == "red_wine":
        dataset = np.loadtxt("./dataset/wine/winequality-red.txt")
        input = dataset[:,:-1]
        input = (input - input.mean(axis=0)[np.newaxis,:])/input.std(axis=0)
        output = dataset[:,-1]
        output = (output - output.mean())/output.std()
        return [input,output]

    if data_name == "bike":
        dataset = np.loadtxt("./dataset/bike/bike.txt")
        # input = dataset[:,2:-1]
        input_binary = dataset[:,2:9]
        input = []
        for d in range(input_binary.shape[1]):
            index = (input_binary[:,d]-input_binary[:,d].min()).astype(dtype=int)
            input_tmp = np.eye(index.max()+1)[index]
            if d == 0:
                input = input_tmp
            else:
                input = np.concatenate([input, input_tmp], axis=1)
            # print(input_tmp)
        input_continuous = dataset[:,2:9]
        input_continuous = (input_continuous - input_continuous.mean(axis=0)[np.newaxis,:])/input_continuous.std(axis=0)
        input = np.concatenate([input,input_continuous],axis=1)
        output = dataset[:,-1]
        output = (output - output.mean())/output.std()
        return [input,output]
