from sklearn.gaussian_process.kernels import RBF, WhiteKernel
from get_dataset import get_dataset
from active_learning import *
from evaluation import *
import os

def main():
    best_thresh_dir = './results/'
    data_names = ["airfoil","artificial","power_plant","protein","concrete","yacht"] # dataset
    is_tuning_threshold = True
    is_KL_fast = False
    train_sizes = [100,50,100,100,100,100]
    for d,data_name in enumerate(data_names):
        np.random.seed(3)
        random.seed(3)
        # get dataset and hyperparameter estimation
        save_dir = best_thresh_dir+data_name+'/'
        os.makedirs(save_dir, exist_ok=True)
        whole_dataset = get_dataset(data_name)
        whole_size = whole_dataset[0].shape[0]
        train_size = train_sizes[d]
        indecies = random.sample(range(whole_dataset[0].shape[0]),whole_size)
        whole_dataset_resample = [whole_dataset[0][indecies],whole_dataset[1][indecies]]
        train_input = whole_dataset_resample[0][:train_size]
        train_output = whole_dataset_resample[1][:train_size]

        length_scale_bounds = (1e-8, 1e3)
        noise_level_bounds=(1e-8, 1e3)
        Length = (length_scale_bounds[1]-length_scale_bounds[0])*np.random.rand()+length_scale_bounds[0]
        noise_level = (noise_level_bounds[1]-noise_level_bounds[0])*np.random.rand()+noise_level_bounds[0]
        kernel = RBF(length_scale=Length, length_scale_bounds=length_scale_bounds)+WhiteKernel(noise_level=noise_level, noise_level_bounds=noise_level_bounds)
        gp = GaussianProcessRegressor(kernel=kernel,alpha=0.0,n_restarts_optimizer=500).fit(train_input, train_output)
        params = np.exp(gp.kernel_.theta)
        print(params)

        Length = params[0]
        Var = params[1]
        kernel = RBF(length_scale=Length, length_scale_bounds=length_scale_bounds)+WhiteKernel(noise_level=Var, noise_level_bounds=noise_level_bounds)

        xmax = whole_dataset[0].max()
        xmin = whole_dataset[0].min()
        ymax = whole_dataset[1].max() - whole_dataset[1].min()
        ymin = 0
        output_range = [ymin,ymax] # range of the cost function
        start_num = 1 # size of initial dataset
        splits = 5 # number of cross validation
        delta = 0.01 # confidence parameter of PAC-Bayesian criterion

        # calculating the threshold of optimal timing and ground truth criterion by bootstrap
        bootstrap_num = 100 # the number of bootstrap
        thresholds = calcThreshold(whole_dataset_resample[0],whole_dataset_resample[1], train_size, kernel, Var, bootstrap_num,is_tuning_threshold,best_thresh_dir)

        # active learning
        exec_num = 100 # the number of executions
        stopping_criterion,stopping_times = active_learning(start_num, whole_dataset, train_size, kernel, output_range, Var, delta, splits, thresholds,exec_num,is_KL_fast)

        # calculating the error in each criterion.
        path = save_dir+"e_stop_"+data_name+".txt"
        best_indecies = calcErrors(path,stopping_times,exec_num)

        # saving best threshold
        if is_tuning_threshold:
            best_threshhold = []
            best_threshhold.append(thresholds["PAC"][best_indecies["PAC"]])
            best_threshhold.append(thresholds["CV"][best_indecies["CV"]])
            best_threshhold.append(thresholds["Maxvar"][best_indecies["Maxvar"]])
            best_threshhold = np.array(best_threshhold)
            np.savetxt(best_thresh_dir+'best_threshhold.txt', best_threshhold)
            is_tuning_threshold = False

        # visualizing the stopping timing
        plot_stopping_time(stopping_criterion, stopping_times, start_num, train_size,best_indecies,exec_num,data_name,save_dir)

    plt.show()

if __name__ == "__main__":
    main()
