from stopping_criterion import *
import random

def active_learning(start_num, whole_dataset, train_size, kernel, output_range, Var, delta, splits, thresholds,exec_num,is_KL_fast):
    stopping_criterion = {}
    stopping_criterion["Optimal"] = np.zeros((exec_num,train_size - start_num))
    stopping_criterion["PAC"] = np.zeros((exec_num,train_size - start_num))
    stopping_criterion["RUN"] = np.zeros((exec_num,train_size - start_num))
    stopping_criterion["CV"] = np.zeros((exec_num,train_size - start_num))
    stopping_criterion["GroundTruth"] = np.zeros((exec_num,train_size - start_num))
    stopping_criterion["Maxvar"] = np.zeros((exec_num,train_size - start_num))
    stopping_times = {}
    stopping_times["Optimal"] = np.zeros(exec_num)
    stopping_times["PAC"] = np.zeros((exec_num,thresholds["PAC"].shape[0]))
    stopping_times["RUN"] = np.zeros(exec_num)
    stopping_times["CV"] = np.zeros((exec_num,thresholds["CV"].shape[0]))
    stopping_times["GroundTruth"] = np.zeros(exec_num)
    stopping_times["Maxvar"] = np.zeros((exec_num,thresholds["Maxvar"].shape[0]))
    for i in range(exec_num):
        # sampling training dataset and test dataset
        whole_size = whole_dataset[0].shape[0]
        indecies = random.sample(range(whole_size), whole_size)
        whole_input = whole_dataset[0]
        whole_output = whole_dataset[1]
        train_input = whole_input[indecies[:train_size]]
        train_output = whole_output[indecies[:train_size]]

        test_size = whole_size - train_size
        test_input = whole_input[indecies[train_size:train_size + test_size]]
        test_output = whole_output[indecies[train_size:train_size + test_size]]

        # sampling initial input and output
        index = np.linspace(0, start_num, start_num).astype(np.int)
        old_input = train_input[index].copy()
        old_output = train_output[index].copy()
        train_input = np.delete(train_input, index, axis=0)
        train_output = np.delete(train_output, index, axis=0)

        # active learning
        gp_old = GaussianProcessRegressor(kernel=kernel, alpha=0.0, optimizer=None).fit(old_input, old_output)
        for t in range(train_size - start_num):
            # determining a new datum
            index = aquisition_function(train_input, gp_old)
            new_input = np.concatenate([old_input, train_input[index][np.newaxis, :]], axis=0)
            new_output = np.append(old_output, train_output[index])
            train_input = np.delete(train_input, index, axis=0)
            train_output = np.delete(train_output, index, axis=0)
            # estimating the predictor
            gp_new = GaussianProcessRegressor(kernel=kernel, alpha=0.0, optimizer=None).fit(new_input, new_output)
            K = kernel(new_input, new_input)
            prior = [np.zeros(K.shape[0]), K]
            pos_new = gp_new.predict(new_input, return_cov=True)
            pos_old = gp_old.predict(new_input, return_cov=True)
            pos_new_test = gp_new.predict(test_input, return_std=True, return_cov=False)
            K_test = kernel.diag(test_input)
            # K_test = kernel(test_input, test_input)

            prior_test = [np.zeros(K_test.shape[0]), K_test]

            N = pos_old[0].shape[0]
            test_size = test_output.shape[0]
            E_Qnew_test = (((test_output - pos_new_test[0]) ** 2).sum() + (pos_new_test[1] ** 2).sum()) / (
                    2 * Var * test_size) - 0.5 * np.log(2 * np.pi * Var)
            E_Qpri_test = (((test_output - prior_test[0]) ** 2).sum() + (prior_test[1].sum())) / (
                    2 * Var * test_size) - 0.5 * np.log(2 * np.pi * Var)

            KL_prior = calcKL(pos_new, prior)
            E_Qnew = (((new_output - pos_new[0]) ** 2).sum() + np.trace(pos_new[1])) / (2 * Var * N) - (1 / 2) * np.log(
                2 * np.pi * Var)

            stopping_criterion["RUN"][i,t] = calcRun(pos_old,pos_new,new_input[-1][None,:],new_output[-1],gp_old,Var,output_range,is_KL_fast)
            stopping_criterion["GroundTruth"][i,t] = calcGroundTruth(E_Qpri_test,E_Qnew_test)
            stopping_criterion["PAC"][i,t] = calcPAC(E_Qnew,KL_prior,delta,N,output_range)
            stopping_criterion["CV"][i,t] = calcCV(new_input,new_output,splits,kernel,Var)
            stopping_criterion["Maxvar"][i,t] = calcMaxvar(train_input,gp_new)
            stopping_criterion["Optimal"][i,t] = E_Qnew_test

            gp_old = gp_new
            old_input = new_input.copy()
            old_output = new_output.copy()

        # determining the optimal time and discriminating the stop timing of learning in each criterion.
        Optimal_time = train_size - start_num - 1
        for t in range(train_size - start_num):
            if stopping_criterion["Optimal"][i,t] < thresholds["Optimal"] and t >= splits:
                Optimal_time = t
                break
        stopping_times["Optimal"][i] = Optimal_time

        GroundTruth_time = train_size - start_num - 1
        for t in range(train_size - start_num):
            if stopping_criterion["GroundTruth"][i,t] > thresholds["GroundTruth"] and t >= splits:
                GroundTruth_time = t
                break
        stopping_times["GroundTruth"][i] = GroundTruth_time

        RUN_time = train_size - start_num - 1
        for t in range(train_size - start_num):
            if t >= splits:
                if runTest(stopping_criterion["RUN"][i,:t]):
                    RUN_time = t
                    break
        stopping_times["RUN"][i] = RUN_time

        PAC_time = (train_size - start_num - 1) * np.ones(thresholds["PAC"].shape[0])
        cv_time = (train_size - start_num - 1) * np.ones(thresholds["CV"].shape[0])
        maxvar_time = (train_size - start_num - 1) * np.ones(thresholds["Maxvar"].shape[0])
        for k in range(thresholds["PAC"].shape[0]):
            for t in range(train_size - start_num):
                if stopping_criterion["PAC"][i,t] < thresholds["PAC"][k] and t >= splits:
                    PAC_time[k] = t
                    break
            for t in range(train_size - start_num):
                if stopping_criterion["CV"][i,t] < thresholds["CV"][k] and t >= splits:
                    cv_time[k] = t
                    break
            for t in range(train_size - start_num):
                if stopping_criterion["Maxvar"][i,t] < thresholds["Maxvar"][k] and t >= splits:
                    maxvar_time[k] = t
                    break
        stopping_times["PAC"][i] = PAC_time
        stopping_times["CV"][i] = cv_time
        stopping_times["Maxvar"][i] = maxvar_time

    return [stopping_criterion, stopping_times]
