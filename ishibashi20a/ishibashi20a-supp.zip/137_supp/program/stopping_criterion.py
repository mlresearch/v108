import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
import statistics
import scipy.stats as st
from sklearn.model_selection import KFold
import random

def aquisition_function(XStar, GP):
    [F, S] = GP.predict(XStar, return_cov=True)
    index = np.argmax(np.diag(S))
    return index

def calcThreshold(whole_input,whole_output, train_size, kernel, Var, bootstrap_num, is_tuning_threshold,best_thresh_dir):
    Optimal_criterion = np.zeros(bootstrap_num)
    GroundTruth = np.zeros(bootstrap_num)
    whole_size = whole_input.shape[0]
    thresholds = {}
    for i in range(bootstrap_num):
        indecies = random.sample(range(whole_size), whole_size)
        train_input = whole_input[indecies[:train_size]]
        train_output = whole_output[indecies[:train_size]]

        test_size = whole_size - train_size
        test_input = whole_input[indecies[train_size:train_size + test_size]]
        test_output = whole_output[indecies[train_size:train_size + test_size]]

        # active learning
        gp = GaussianProcessRegressor(kernel=kernel, alpha=0.0, optimizer=None).fit(train_input, train_output)
        pos = gp.predict(test_input, return_std=True, return_cov=False)
        cov = pos[1] ** 2
        E_Q_test = (((test_output - pos[0]) ** 2).sum() + cov.sum()) / (2 * Var * test_size) - 0.5 * np.log(2 * np.pi * Var)
        Optimal_criterion[i] = E_Q_test

        K_test = kernel.diag(test_input)
        pri = [np.zeros(K_test.shape[0]), K_test]
        E_prior_test = (((test_output - pri[0]) ** 2).sum() + K_test.sum()) / (2 * Var * test_size) - 0.5 * np.log(2 * np.pi * Var)
        GroundTruth[i] = E_prior_test - E_Q_test

    Optimal_criterion_mean = Optimal_criterion.mean()
    Optimal_criterion_std = Optimal_criterion.std()
    thresholds["Optimal"] = Optimal_criterion_mean + 2 * Optimal_criterion_std

    GroundTruth_mean = GroundTruth.mean()
    GroundTruth_std = GroundTruth.std()
    thresholds["GroundTruth"] = GroundTruth_mean - 2 * GroundTruth_std

    # obtaining thresholds of the PAC-Bayesian, cross validation and max variance criteria
    if is_tuning_threshold:
        # defining candidates of thresholds
        Node = 10000
        pac_max = 100
        pac_min = 0.01
        thresholds["PAC"] = np.linspace(pac_min, pac_max, Node)

        cv_max = 10
        cv_min = 0.001
        thresholds["CV"] = np.linspace(cv_min, cv_max, Node)

        maxvar_max = 1
        maxvar_min = 0.0001
        thresholds["Maxvar"] = np.linspace(maxvar_min, maxvar_max, Node)
    else:
        best_threshhold = np.loadtxt(best_thresh_dir + 'best_threshhold.txt')
        thresholds["PAC"] = np.array([best_threshhold[0]])
        thresholds["CV"] = np.array([best_threshhold[1]])
        thresholds["Maxvar"] = np.array([best_threshhold[2]])
    return thresholds

def runTest(criteria):
    median = statistics.median(criteria)
    n_one = 0
    n_zero = 0
    K = 0
    pre_num = -1
    runs = []
    for c in criteria:
        if c - median < 0:
            runs.append(0)
            n_zero += 1
            if pre_num != 0:
                K += 1
            pre_num = 0
        else:
            runs.append(1)
            n_one += 1
            if pre_num != 1:
                K += 1
            pre_num = 1
    n = n_zero + n_one
    mu = 2 * n_zero * n_one / n + 1
    if n_zero == 0 or n_one == 0:
        return False
    sigma = 2 * n_zero * n_one * (2 * n_zero * n_one - n) / ((n ** 2) * (n - 1))
    Z = (K - mu) / np.sqrt(sigma)
    cdf = st.norm.cdf(Z)
    alpha = 0.001
    if cdf <= alpha:
        return True
    else:
        return False

def calcKL(pos1, pos2):
    epsilon = 0.01
    N = pos1[0].shape[0]
    f2 = pos2[0]
    f1 = pos1[0]
    S2 = pos2[1] + epsilon * np.eye(N)
    S1 = pos1[1] + epsilon * np.eye(N)
    S2_inv = np.linalg.inv(S2)
    S = S2_inv @ S1
    trace = np.trace(S)
    logdet = np.log(np.linalg.det(S))
    se = (f2 - f1).T @ S2_inv @ (f2 - f1)
    KL = 0.5 * (trace - logdet + se - N)
    return KL

def calcKL_fast(new_input,new_output,gpOld,beta):
    [m,k] = gpOld.predict(new_input, return_cov=True)
    m = m[0]
    k = k[0,0]
    trace = beta*k
    logdet = np.log(1+beta*k)
    se = 1/(k+1/beta)**2*(k+k*beta*k)*(new_output-m)**2
    KL = 0.5*(trace - logdet + se)
    return KL

def calcRun(pos_old,pos_new,new_input,new_output,gp_old,Var,output_range,is_KL_fast):
    if is_KL_fast:
        KL = calcKL_fast(new_input,new_output,gp_old,1/Var)
    else:
        KL = calcKL(pos_old, pos_new)
    C = 2 * np.log(0.5 * (np.exp(output_range[0]) + np.exp(output_range[1]))) - output_range[0] - output_range[1]
    return KL + C

def calcGroundTruth(E_Qpri_test,E_Qnew_test):
    GroundTruth = E_Qpri_test - E_Qnew_test
    return GroundTruth

def calcPAC(E_Qnew,KL_prior,delta,N,range):

    PAC = E_Qnew + KL_prior / N - np.log(delta) / N + 0.5 * (range[1] - range[0]) ** 2
    return PAC

def calcCV(new_input,new_output,splits,kernel,Var):
    if new_input.shape[0] >= splits:
        kf = KFold(n_splits=splits)
        cv_L = 0
        for id_train, id_test in kf.split(new_input):
            cv_train_input = new_input[id_train]
            cv_train_output = new_output[id_train]
            cv_test_input = new_input[id_test]
            cv_test_output = new_output[id_test]
            gpCV = GaussianProcessRegressor(kernel=kernel, alpha=0.0, optimizer=None).fit(cv_train_input,
                                                                                          cv_train_output)
            posCV = gpCV.predict(cv_test_input, return_cov=True)
            cv_L += (((cv_test_output - posCV[0]) ** 2).sum() + np.trace(posCV[1])) / (
                        2 * Var * len(id_test)) - 0.5 * np.log(2 * np.pi * Var)
        cv_L = cv_L / splits
        cv = cv_L
    else:
        cv = 1e10
    return cv

def calcMaxvar(train_input,gp_new):
    if len(train_input) is not 0:
        index = aquisition_function(train_input, gp_new)
        pos = gp_new.predict(train_input, return_cov=True)
        maxvar = pos[1][index, index]
    else:
        maxvar = 1e10
    return maxvar

