# The Diabetes Classification problem is from a Kaggle competition https://www.kaggle.com/c/pf2012-diabetesand

# The data cleaning process is partially based on an open source Kaggle competetion solution https://github.com/kthouz/Diabetes-PracticeFusion
    
# The process to deal with the medication dataset is as follows:


# 1. Convert medication names into documents. Each document will be a list of terms
# 2. Build a vocabulary: This is a hash table of all unique terms found in all documents
# 3. Calculate how important each term is for each document by using [tf-idf](http://scikit-learn.org/stable/tutorial/text_analytics/working_with_text_data.html)
# 4. Remove noisy terms. Noisy terms will be added to the list of stop_words.
# 5. With the right vocabulary in hands (initial vocabulary without noisy terms), we will build a table of tf-idfs that will serve as independent variables of the predictive model to be built.


import pandas as pd
import numpy as np
import datetime as dt
import matplotlib.pyplot as plt

import glob, os, re, random

from sklearn.preprocessing import Imputer, LabelEncoder
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer, TfidfTransformer

from sklearn.model_selection import train_test_split



def clean_text(txt,stop_words):
    """
    This function is to clean text. It remove all non alphanumeric characters
    """
    # make sure input is of type str
    if type(txt) is not str:
        txt = str(txt)
    #lower case
    txt = txt.lower()
    #remove non-alphabetic characters
    txt = re.sub("[^\s\w]"," ",txt).split(" ")
    #remove stop words
    txt = filter(lambda w:not (w in stop_words),txt)
    txt = ' '.join(txt)
    return txt

def main():
    df0 = pd.read_csv('data/trainingSet/training_SyncPatient.csv')
    df0.index = df0.PatientGuid
    df0 = df0.drop('PatientGuid',axis=1).sort_index()
    df1 = pd.read_csv('data/trainingSet/training_SyncMedication.csv')
    df1 = df1[~df1.MedicationName.isnull()]
    patient_medication = df1.loc[:,('PatientGuid','MedicationName')]
    patient_medication.MedicationName += ' '
    patient_medication = patient_medication.groupby('PatientGuid').sum().sort_index()


    stop_words = [' ','','10','100','104','1000','11','12','120','12d','13','15','150','16','1a','1b','1x','20','200','2011','2012','21', '23','24','24d','25','28','30','300','325','3350','35','40','400','50','500','60','600','625','2a','64','650','750','75','80','81','900']

    # clean text
    medText = patient_medication.MedicationName.apply(lambda w:clean_text(w,stop_words))

    # create corpus
    corpus = medText.values.tolist()

    # initialize the term frequency object
    tf1 = TfidfVectorizer(analyzer='word', min_df=0, stop_words=stop_words, ngram_range=(1,1))

    #create the tf-idf matrix
    tf1_matrix = tf1.fit_transform(corpus)
    medications_tfidf = pd.DataFrame(tf1_matrix.todense(),
                                     index = patient_medication.index,
                                     columns = sorted(tf1.vocabulary_),)
    print(len(medications_tfidf.columns))

    # save table to csv for later use
    medications_tfidf.to_csv('agg_data/medication.csv')


    tfidf_agg = medications_tfidf.sum().sort_values(ascending=False)
    d_tfidf_agg = -(tfidf_agg - tfidf_agg.shift())
    tfidf_agg.plot()
    d_tfidf_agg.plot()
    plt.yscale('log')
    plt.title("Aggregate Term Frequency")
    plt.xticks(rotation=90)
    plt.legend(['tf-idf','derivative'])
    plt.show()

if __name__ == '__main__':
    main()


