import sys, math
sys.path.append('..')
from mxnet import autograd, gluon, init, nd
from mxnet.gluon import loss as gloss, nn, rnn, utils as gutils
import numpy as np
import time
import pandas as pd
from scipy.stats import norm

from LORD import gamma, LORD_weight, LORD_weight_H
from SAFFRON import gamma_s, SAFFRON_weight, SAFFRON_weight_H

from Generate_synthetic_data import generate_features, comb_features, generate_pval


# define MLP model with ReLU as activation function

class Model(nn.Block):
    def __init__(self, num_nodes, num_layers, scale, **kwargs):
        super(Model, self).__init__(**kwargs)
        self.scale = scale
        with self.name_scope():
            self.net = nn.Sequential()
            for i in range(num_layers - 1):
                self.net.add(nn.Dense(num_nodes, activation='relu'))
            self.dense = nn.Dense(1)

    def forward(self, x):
        x = self.dense(self.net(x))
        x = x.exp() * scale
        return x


# define MLP model with leaky ReLU as activation function


class Model_Leaky(nn.Block):
    def __init__(self, num_nodes, num_layers, scale, **kwargs):
        super(Model_Leaky, self).__init__(**kwargs)
        self.scale = scale
        with self.name_scope():
            self.net = nn.Sequential()
            for i in range(num_layers - 1):
                self.net.add(nn.Dense(num_nodes))
            self.dense = nn.Dense(1)

    def forward(self, x):
        for i, b in enumerate(self.net):
            x = nd.LeakyReLU(b(x), act_type='leaky', slope=0.2)
        x = nd.LeakyReLU(self.dense(x), act_type='leaky', slope=0.2)
        x = x.exp() * scale
        return x


def softloss(alpha, p):
    return -nd.sigmoid((alpha - p.reshape(alpha.shape)) * 1000).sum() / len(p)


def hardloss(alpha, p):
    return -(p.reshape(alpha.shape) < alpha).sum() * 1.0 / len(p)


def get_batch(pval, X, i):
    seq_len = min(batch_size, len(pval)-1-i)
    p = pval[i : i+seq_len]
    x = X[i : i+seq_len]
    return p, x

def eval_model_SAFFRON(net, p_val, x_val):
    weight = net(x_val)
    alpha = SAFFRON_weight(p_val, weight, desireLevel, InitWealth, 0.5, 2.5)
    dr_sum = -hardloss(alpha, p_val)
    return dr_sum


def train_network_SAFFRON(net, pval, X, desireLevel, InitWealth, dim, ctx=None):
    train_dr_sum = nd.array([0.0], ctx=ctx)
    start_time = time.time()
    train_size = len(pval)

    for batch_i, idx in enumerate(range(0, train_size - 1, batch_size)):
        if batch_i == 20:
            trainer.set_learning_rate(trainer.learning_rate * 0.1)
        if batch_i == 100:
            trainer.set_learning_rate(trainer.learning_rate * 0.1)
        p_train, x_train = get_batch(pval, X, idx)

        with autograd.record():
            weight = net(x_train)
            alpha = SAFFRON_weight(p_train, weight, desireLevel, InitWealth, 0.5, 2.5)
            loss = softloss(alpha, p_train)

        ## if number of zeros in alpha is large, gradients are almost zero and trainig process will stuck in local optimum
        if sum(alpha == 0) < len(p_train) / 10.0:
            loss.backward(retain_graph=True)
            grads = [p.grad(ctx) for p in net.collect_params().values()]
            gutils.clip_global_norm(
                grads, clipping_theta * batch_size)
            trainer.step(1)
        train_dr_sum -= loss

        if (batch_i + 1) % eval_period == 0 and batch_i > 0:
            cur_dr = train_dr_sum / eval_period
            print('batch', batch_i, 'train discovery rate', cur_dr.asscalar())
            train_dr_sum = nd.array([0], ctx=ctx)

    print('time %.2fs'
          % (time.time() - start_time))


desireLevel = 0.1 # the pre-assigned level alpha under which we desire to control FDR
num_hyp = 10**5  # total number of hypotheses
InitWealth = 0.045 # initial wealth w0
dim = 10  # number of dimensions of contextual features
frac1 = 0.4  # fraction of non-nulls


X = generate_features(num_hyp, dim, 0, 1)
beta = nd.random.uniform(-2, 2, shape = (dim,))
means = comb_features(X, beta) # mu(X) = <beta, X>
H, pval = generate_pval(num_hyp, frac1, means)


num_nodes = 10
num_layers = 10
scale = 1
lr = 0.5
clipping_theta = 0.9
clipping_theta_ada = 0.1
batch_size = 1000
# drop_prob = 0.2
eval_period = 10


net = Model(num_nodes, num_layers, scale)
net.initialize(init= init.Xavier())
print(net.collect_params())

trainer = gluon.Trainer(net.collect_params(), 'sgd', {'learning_rate': lr, 'momentum': 0.3, 'wd': 0.08})

train_network_SAFFRON(net, pval, X, desireLevel, InitWealth, dim, ctx = None)



## implement baseline SAFFRON on validation set

rep = 20

dr0_sum = nd.array([0.0])
fdr0_sum = nd.array([0.0])
maxfdr0_sum = nd.array([0.0])
tdr0_sum = nd.array([0.0])

for r in range(rep):
    X = generate_features(num_hyp, dim, 0, 1)
    means = comb_features(X, beta)  # mu(X) = <beta, X>
    H, pval = generate_pval(num_hyp, frac1, means)
    weight = nd.ones(len(pval))
    alpha, D, DP, TDP, FDP = SAFFRON_weight_H(pval, weight, desireLevel, InitWealth, 0.5, H, 2.5)

    dr0 = D / len(pval)
    dr0_sum += dr0
    if FDP != []:
        fdr0_sum += FDP[-1]
        maxfdr0_sum += max(FDP)
    if TDP != []:
        tdr0_sum += sum(TDP) / len(pval)

print('Baseline SAFFRON discovery rate', dr0_sum / rep)
print('Baseline SAFFRON average false discovery rate (FDR)', fdr0_sum / rep)
print('Baseline SAFFRON max false discovery rate (FDR)', maxfdr0_sum / rep)
print('Baseline SAFFRON true discovery rate (TDR)', tdr0_sum / rep)




## implement weighted SAFFRON on validation set

rep = 20

dr_sum = nd.array([0.0])
fdr_sum = nd.array([0.0])
maxfdr_sum = nd.array([0.0])
tdr_sum = nd.array([0.0])

for r in range(rep):
    X_val = generate_features(num_hyp, dim, 0, 1)
    means_val = comb_features(X_val, beta)  # mu(X) = <beta, X>
    H_val, p_val = generate_pval(num_hyp, frac1, means_val)
    weight = net(X_val)
    alpha, D, DP, TDP, FDP = SAFFRON_weight_H(p_val, weight, desireLevel, InitWealth, 0.5, H_val, 2.5)

    dr = D / len(p_val)
    dr_sum += dr
    fdr_sum += FDP[-1]
    maxfdr_sum += max(FDP)
    tdr_sum += sum(TDP) / len(p_val)

print('Discovery rate for weighted SAFFRON', dr_sum / rep)
print('Average false discovery rate (FDR) for weighted SAFFRON', fdr_sum / rep)
print('Maximum false discovery rate (FDR) for weighted SAFFRON', maxfdr_sum / rep)
print('Average tdr for weighted SAFFRON', tdr_sum / rep)



## Train weight function by using MLP with leaky ReLU as activation function

net_leaky = Model_Leaky(num_nodes, num_layers, scale)
net_leaky.initialize(init= init.Xavier())
print(net_leaky.collect_params())

trainer = gluon.Trainer(net_leaky.collect_params(), 'sgd', {'learning_rate': lr, 'momentum': 0.2, 'wd': 0.08})
train_network_SAFFRON(net_leaky, pval, X, desireLevel, InitWealth, dim, ctx = None)

## implement weighted SAFFRON trained with leaky ReLU on validation set

rep = 20

dr_sum = nd.array([0.0])
fdr_sum = nd.array([0.0])
maxfdr_sum = nd.array([0.0])
tdr_sum = nd.array([0.0])

for r in range(rep):
    X_val = generate_features(num_hyp, dim, 0, 1)
    means_val = comb_features(X_val, beta)  # mu(X) = <beta, X>
    H_val, p_val = generate_pval(num_hyp, frac1, means_val)
    weight = net_leaky(X_val)
    alpha, D, DP, TDP, FDP = SAFFRON_weight_H(p_val, weight, desireLevel, InitWealth, 0.5, H_val, 2.5)

    dr = D / len(p_val)
    dr_sum += dr
    fdr_sum += FDP[-1]
    maxfdr_sum += max(FDP)
    tdr_sum += sum(TDP) / len(p_val)

print('Discovery rate for weighted SAFFRON with leaky ReLU', dr_sum / rep)
print('Average false discovery rate (FDR) for weighted SAFFRON with leaky ReLU', fdr_sum / rep)
print('Maximum false discovery rate (FDR) for weighted SAFFRON with leaky ReLU', maxfdr_sum / rep)
print('Average tdr for weighted SAFFRON with leaky ReLU', tdr_sum / rep)


## After comparison, we choose to use MLP with ReLU rather than leaky ReLU.