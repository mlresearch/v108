# ! pip install scipy

import sys, math
sys.path.append('..')
from mxnet import autograd, gluon, init, nd
from mxnet.gluon import loss as gloss, nn, rnn, utils as gutils
import numpy as np
import time
import pandas as pd
from scipy.stats import norm

from LORD import gamma, LORD_weight, LORD_weight_H

from Generate_synthetic_data import generate_features, comb_features, generate_pval



# Contruct weight function as a neural network model (multilayer perceptron)

class Model(nn.Block):
    def __init__(self, num_nodes, num_layers, scale, **kwargs):
        super(Model, self).__init__(**kwargs)
        self.scale = scale
        with self.name_scope():
            self.net = nn.Sequential()
            for i in range(num_layers - 1):
                self.net.add(nn.Dense(num_nodes, activation = 'relu'))
            self.dense = nn.Dense(1)
            
    def forward(self, x):
        x = self.dense(self.net(x))
        x = x.exp()*scale
        return x


## Define the loss functions: hard loss is true loss, and soft loss is an approximate of true loss by using sigmoid function.

def softloss(alpha, p):
    return -nd.sigmoid((alpha - p.reshape(alpha.shape)) * 1000).sum() / len(p)


def hardloss(alpha, p):
    return -(p.reshape(alpha.shape) < alpha).sum() * 1.0 / len(p)


desireLevel = 0.1 # the pre-assigned level alpha under which we desire to control FDR
num_hyp = 3 * (10**5)  # total number of hypotheses
InitWealth = 0.045 # initial wealth w0
dim = 10 # number of dimensions of contextual features
frac1 = 0.5
H = np.random.binomial(1, frac1, num_hyp)
mu = 0.1 * H
#print(mu[2])

X = generate_features(num_hyp, dim, mu, 1)
beta = nd.random.uniform(-2, 2, shape = (dim,))
means = comb_features(X, beta) # mu(X) = <beta, X>
H, pval = generate_pval(num_hyp, H, means)


num_nodes = 10
num_layers = 10
scale = 1
lr = 0.6
clipping_theta = 0.7
clipping_theta_ada = 0.1
batch_size = 1000
eval_period = 10


net = Model(num_nodes, num_layers, scale)
net.initialize(init= init.Xavier())

trainer = gluon.Trainer(net.collect_params(), 'sgd', {'learning_rate': lr, 'momentum': 0.3, 'wd': 0})


# get the i-th mini batch

def get_batch(pval, X, i):
    seq_len = min(batch_size, len(pval)-1-i)
    p = pval[i : i+seq_len]
    x = X[i : i+seq_len]
    return p, x

# evaluate the weighted LORD model by returning the discovery rate

def eval_model_LORD(net, p_val, x_val):
    weight = net(x_val)
    alpha = LORD_weight(p_val, weight, desireLevel, InitWealth)
    dr_sum = -hardloss(alpha, p_val)
    return dr_sum


# train the model

def train_network(net, pval, X, desireLevel, InitWealth):
    train_dr_sum = nd.array([0.0])
    start_time = time.time()
    train_size = len(pval)

    for batch_i, idx in enumerate(range(0, train_size - 1, batch_size)):
        if batch_i == 20:
            trainer.set_learning_rate(trainer.learning_rate * 0.1)
        if batch_i == 100:
            trainer.set_learning_rate(trainer.learning_rate * 0.1)
        p_train, x_train = get_batch(pval, X, idx)

        with autograd.record():
            weight = net(x_train)
            alpha = LORD_weight(p_train, weight, desireLevel, InitWealth)
            loss = softloss(alpha, p_train)

        ## if number of zeros in alpha is large, gradients are almost zero and trainig process will stuck in local optimum
        if sum(alpha == 0) < len(p_train) / 10.0:
            loss.backward(retain_graph=True)
            grads = [p.grad() for p in net.collect_params().values()]
            gutils.clip_global_norm(
                grads, clipping_theta * batch_size)
            trainer.step(1)
        train_dr_sum -= loss

        if (batch_i + 1) % eval_period == 0 and batch_i > 0:
            cur_dr = train_dr_sum / eval_period
            print('batch', batch_i, 'train discovery rate', cur_dr.asscalar())
            train_dr_sum = nd.array([0])

    print('time %.2fs'
          % (time.time() - start_time))


def train_val_network(net, p, X, X_val0, X_val1, desireLevel, InitWealth):
    train_dr_sum = nd.array([0.0])
    start_time = time.time()
    train_size = len(p)

    for batch_i, idx in enumerate(range(0, train_size - 1, batch_size)):
        if batch_i == 20:
            trainer.set_learning_rate(trainer.learning_rate * 0.1)
        if batch_i == 100:
            trainer.set_learning_rate(trainer.learning_rate * 0.1)
        p_train, x_train = get_batch(p, X, idx)

        with autograd.record():
            weight = net(x_train)
            alpha = LORD_weight(p_train, weight, desireLevel, InitWealth)
            loss = softloss(alpha, p_train)

        ## if number of zeros in alpha is large, gradients are almost zero and trainig process will stuck in local optimum
        if sum(alpha == 0) < len(p_train) / 10.0:
            loss.backward(retain_graph=True)
            grads = [p.grad() for p in net.collect_params().values()]
            file_name = "net.params"
            net.save_parameters(file_name)
            # param0 = [net[i].weight.data().copy() for i in range(num_layers)]
            # param1 = [net[i].bias.data().copy() for i in range(num_layers)]

            gutils.clip_global_norm(grads, clipping_theta * batch_size)
            trainer.step(1)
            weight_1 = net(X_val0)
            weight_0 = net(X_val1)
            if batch_i >= 50 and (sum(weight_1)/len(weight_1)) < (sum(weight_0)/len(weight_0)):
                net.load_parameters(file_name)
                # for i in range(num_layers):
                #     net[i].weight.set_data(param0[i])
                #     net[i].bias.set_data(param1[i])
        train_dr_sum -= loss

        if (batch_i + 1) % eval_period == 0 and batch_i > 0:
            cur_dr = train_dr_sum / eval_period
            print('batch', batch_i, 'train discovery rate', cur_dr.asscalar())
            train_dr_sum = nd.array([0])

    print('time %.2fs'
          % (time.time() - start_time))

# We generate a random copy of features from same distribution and use that as input of weight function
# This is because in theoretical power analysis we require contextual features X to be independent with pvalues
# as a sufficient condition (not necessary).
# But in practice we do not need this sufficient condition and still expect that the true discovery rate can be significantly increased compared to the baseline.
# That is to say, if we use X as input of weight function, we can get similar training results of that from X_random.

X_random = generate_features(num_hyp, dim, mu, 1)
mu_0 = [0] * batch_size
mu_1 = [0.1] * batch_size
X_0 = generate_features(batch_size, dim, mu_0, 1)
X_1 = generate_features(batch_size, dim, mu_1, 1)
#train_network(net, pval, X_random, desireLevel, InitWealth)
# train_network(net, pval, X, desireLevel, InitWealth)
train_val_network(net, pval, X_random, X_0, X_1, desireLevel, InitWealth)



## Validate the model on validation set

## Implement baseline LORD on validation set

rep = 20  # number of repeats

dr0_sum = nd.array([0.0])
fdr0_sum = nd.array([0.0])
maxfdr0_sum = nd.array([0.0])
tdr0_sum = nd.array([0.0])

dr_sum = nd.array([0.0])
fdr_sum = nd.array([0.0])
maxfdr_sum = nd.array([0.0])
tdr_sum = nd.array([0.0])
num_hyp = 10**5
for r in range(rep):
    H_val = np.random.binomial(1, frac1, num_hyp)
    mu_val = 0.1 * H_val
    X_val = generate_features(num_hyp, dim, mu_val, 1)
    means_val = comb_features(X_val, beta)  # mu(X) = <beta, X>
    H_val, p_val = generate_pval(num_hyp, H_val, means_val)
    weight0 = nd.ones(len(p_val))
    alpha0, D0, DP0, estFDP0, TDP0, FDP0 = LORD_weight_H(p_val, weight0, desireLevel, InitWealth, H_val)

    dr0 = D0 / len(p_val)
    dr0_sum += dr0
    fdr0_sum += FDP0[-1]
    maxfdr0_sum += max(FDP0)
    tdr0_sum += sum(TDP0) / len(p_val)

    weight = net(X_val)
    alpha, D, DP, estFDP, TDP, FDP = LORD_weight_H(p_val, weight, desireLevel, InitWealth, H_val)

    dr = D / len(p_val)
    dr_sum += dr
    fdr_sum += FDP[-1]
    maxfdr_sum += max(FDP)
    tdr_sum += sum(TDP) / len(p_val)



print('Baseline discovery rate', dr0_sum / rep)
print('Baseline average false discovery rate (FDR)', fdr0_sum / rep)
print('Baseline max false discovery rate (FDR)', maxfdr0_sum / rep)
print('Baseline true discovery rate (TDR)', tdr0_sum / rep)

print('Discovery rate for weighted LORD', dr_sum / rep)
print('Average false discovery rate (FDR) for weighted LORD', fdr_sum / rep)
print('Maximum false discovery rate (FDR) for weighted LORD', maxfdr_sum / rep)
print('Average true discovery rate (TDR) for weighted LORD', tdr_sum / rep)


## Implement weighted LORD on validation set




# for r in range(rep):
#
#     X_val = generate_features(num_hyp, dim, 0, 1)
#     means_val = comb_features(X_val, beta)  # mu(X) = <beta, X>
#     H_val, p_val = generate_pval(num_hyp, frac1, means_val)
#     X_val_random = generate_features(num_hyp, dim, 0, 1)
#     # We generate a random copy of features from same distribution and use that as input of weight function
#     # This is because in theoretical power analysis we require contextual features X to be independent with pvalues
#     # as a sufficient condition (not necessary).
#     # But in practice we do not need this sufficient condition and still expect that the true discovery rate
#     # can be significantly increased compared to the baseline.
#     # That is to say, if we use X_val as input of weight function, we can get similar results of that from X_val_random.
#
#     weight = net(X_val_random)
#     alpha, D, DP, estFDP, TDP, FDP = LORD_weight_H(p_val, weight, desireLevel, InitWealth, H_val)
#
#     dr = D / len(p_val)
#     dr_sum += dr
#     fdr_sum += FDP[-1]
#     maxfdr_sum += max(FDP)
#     tdr_sum += sum(TDP) / len(p_val)
#
# print('Discovery rate for weighted LORD', dr_sum / rep)
# print('Average false discovery rate (FDR) for weighted LORD', fdr_sum / rep)
# print('Maximum false discovery rate (FDR) for weighted LORD', maxfdr_sum / rep)
# print('Average true discovery rate (TDR) for weighted LORD', tdr_sum / rep)
