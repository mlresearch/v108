## Here we clean transcripts and diagnosis datasets.

import pandas as pd
import numpy as np
import datetime as dt
import matplotlib.pyplot as plt

import glob, os, re, random

from sklearn.preprocessing import Imputer, LabelEncoder
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer, TfidfTransformer

from sklearn.model_selection import train_test_split


imputers = {}
labelEncoders = {}


filenames = glob.glob('data/trainingSet/*.csv')
data = {'trainingSet':{}}
for filename in filenames:
    k = os.path.basename(filename)[:-4].replace('training_','')
    data['trainingSet'][k] = pd.read_csv(filename)
    print(k)


df0 = data['trainingSet']['SyncPatient'].copy()
df1 = data['trainingSet']['SyncDiagnosis'].copy()
df2 = data['trainingSet']['SyncTranscriptDiagnosis'].copy()
df3 = data['trainingSet']['SyncTranscript'].copy()

# calculate patient age
df0['Age'] = 2018 - df0['YearOfBirth']
patient_agg = df0[['Age','Gender','State','DMIndicator']].copy()
patient_agg.index = df0.PatientGuid

lePatient = LabelEncoder()
patient_agg['State'] = lePatient.fit_transform(patient_agg['State'])
patient_agg['Gender'] = lePatient.fit_transform(patient_agg['Gender'] )
labelEncoders['lePatient'] = lePatient

# create aggregated patient data
patient_agg.to_csv('agg_data/patient.csv')



## Transcript Records Cleaning

def check_outliers(df, col, scaley = False):
    plt.figure(figsize=(4,3))
    df[col].hist()
    if scaley:
        plt.yscale('log')
    plt.title(col)
    plt.show()
    f1 = calculate_fences(df[col], 1)
    f2 = calculate_fences(df[col], 2)
    print("strategy1:\tq1:", f1[0], "q2:", f1[1], "q3:", f1[2],"range:", (f1[3],f1[4]))
    print("strategy2:\tstd:", f2[0], "mean:", f2[1], "range:", (f2[2],f2[3]))

    
def calculate_fences(x, strategy):
    if strategy == 1:
        q1 = np.percentile(x.dropna(), 25)
        q2 = np.percentile(x.dropna(), 50)
        q3 = np.percentile(x.dropna(), 75)
        iq = q3 - q1
        lbound = q1 - 1.5*iq
        ubound = q3 + 1.5*iq
        return q1, q2, q3, lbound, ubound
    if strategy == 2:
        std = round(x.dropna().std(), 2)
        mean = round(x.dropna().mean(), 2)
        lbound = round(mean - 3*std, 2)
        ubound = round(mean + 3*std, 2)
        return std, mean, lbound, ubound
    

def drop_outliers(x, lbound = None, ubound = None, val = None):
    if (lbound == None) or (ubound == None) or (val == None):
        r = calculate_fences(x, 1)
        val, lbound, ubound = r[1], r[3], r[4]
    i = x[(x<lbound) | (x>ubound)].index
    x.loc[i] = val
    return x


# Features with more than 50% missing values to be dropped: HeartRate.
df3.drop(['HeartRate',], axis=1, inplace=True)


check_outliers(df3, 'BMI', True)


df3['Height'] = drop_outliers(df3.Height.copy())
df3['Weight'] = drop_outliers(df3.Weight.copy())
df3['BMI'] = drop_outliers(df3.BMI.copy())
df3['DiastolicBP'] = drop_outliers(df3.DiastolicBP.copy())


## Aggregate physician speciality as a sparse matrix whose columns are each speciality and 
## each row value represents how many times a patient visited that specialist

physician_specialty = df3[['PatientGuid','PhysicianSpecialty']].sort_values('PatientGuid').copy()
physician_specialty.fillna('x Unknown or N/A',inplace=True)
physician_specialty.replace(to_replace=['Psychiatry - Child & Adolescent', 'Addiction Medicine (Psychiatry)', 
                        'Developmental \xe2\x80\x93 Behavioral Pediatrics', 'Physical Medicine & Rehabilitation', 
                        'Physical Therapy', 'x Academic (I am a student)', 'x Unknown or N/A'],
            value=['Psychiatry', 'Addiction Psychiatry', 'Developmental Behavioral Pediatrics',
                   'Physical Medecine', 'Physical Medecine', 'Academic', 'Unknown'],
            inplace=True)
physician_specialty.index = physician_specialty.PatientGuid
physician_specialty.drop('PatientGuid', inplace=True, axis=1)
physician_specialty = pd.get_dummies(pd.DataFrame(physician_specialty.PhysicianSpecialty), prefix='PhySp')

physician_specialty.columns = map(lambda x:x.replace(' & ',' ',).replace(' ','_').replace(';','_'), physician_specialty.columns)
physician_specialty = physician_specialty.reset_index().groupby('PatientGuid').sum()


## Let's fill missing values starting with visit year. 
## There are fours years 2009,2010,2011,2012 all with a probability distribution. 
## We will fill missing visitYear by randomly choosing a year accordin to its probability

s1 = df3[df3.VisitYear!=0].VisitYear.value_counts(normalize=1).sort_index()
s2 = df3[df3.VisitYear == 0].index
s3 = np.random.choice(a=s1.index.tolist(), p=s1.values.tolist(), size=s2.shape[0])
df3.VisitYear.replace(to_replace=0, value=dict(zip(s2,s3)), inplace=True)


## Use Imputer from sklearn to impute missing values with average

## copy numeric features from df3
df3_numeric_vars = [u'VisitYear', u'Height', u'Weight', u'BMI', u'SystolicBP', u'DiastolicBP', 
                    u'RespiratoryRate', u'Temperature']

imputerTranscript = Imputer(strategy='mean')
imputerTranscript.fit(df3[df3_numeric_vars])
imputers['imputerTranscript'] = imputerTranscript
df3[df3_numeric_vars] = imputerTranscript.transform(df3[df3_numeric_vars])


## aggregata data by min, max, std and mean
tdf = df3[[u'PatientGuid', u'Height', u'Weight', u'BMI', u'SystolicBP', u'DiastolicBP', u'RespiratoryRate', u'Temperature']].copy()
transcript_max = tdf.groupby('PatientGuid').max().sort_index()
transcript_min = tdf.groupby('PatientGuid').min().sort_index()
transcript_std = tdf.groupby('PatientGuid').std().sort_index()
transcript_mean = tdf.groupby('PatientGuid').mean().sort_index()


## Aggregate data by recent activities: generate a table where each patient is matched with his/her 2 most recent visits. From here, we will be able to determine changes in BMI, BP and Weight which are in most cases signs of diabetes.


tdf = df3[[u'PatientGuid', u'VisitYear', u'Height', u'Weight', u'BMI', u'SystolicBP', u'DiastolicBP', u'RespiratoryRate', u'Temperature']].copy()
transcript_last_0 = tdf.sort_values(['VisitYear','PatientGuid']).groupby('PatientGuid').nth([-1]).sort_index()
transcript_last_1 = tdf.sort_values(['VisitYear','PatientGuid']).groupby('PatientGuid').nth([-2]).sort_index()
transcript_change = (transcript_last_0 - transcript_last_1).abs()
transcript_change['VisitYear'] += 1
transcript_change = (transcript_change.T / transcript_change.VisitYear).T
transcript_change.drop('VisitYear', axis=1, inplace=True)


# rename columns
transcript_max.columns = map(lambda x:x+'_Max',transcript_max.columns)
transcript_min.columns = map(lambda x:x+'_Min',transcript_min.columns)
transcript_std.columns = map(lambda x:x+'_Std',transcript_std.columns)
transcript_mean.columns = map(lambda x:x+'_Mean',transcript_mean.columns)
transcript_change.columns = map(lambda x:x+'_Change',transcript_change.columns)
# merge dataframes into one
transcript_agg = pd.concat([transcript_max,transcript_min,transcript_std,transcript_mean,transcript_change], axis=1)


transcript_agg.to_csv('agg_data/transcript.csv')
physician_specialty.to_csv('agg_data/physician_specialty.csv')



## Diagnosis - Aggregation

## We will categorize ICD9Code among 20 categories refering to https://en.wikipedia.org/wiki/List_of_ICD-9_codes. Then we shall use get_dummies to get a binary table.

## We will also run quick analysis with the purpose to find patients that were diagnozed with one diagnosis multiple times. We will verify if this diagnosis is to acute or chronic.



def categorize_icd9code(code, method=1):
    icd9code = {
        '001-139': 'infectious and parasitic',
        '140-239': 'neoplasms',
        '240-279': 'endocrine, nutritional and metabolic, immunity disorders',
        '280-289': 'diseases of the blood and blood-forming organs',
        '290-319': 'mental disorders',
        '320-359': 'nervous system',
        '360-389': 'sense organs',
        '390-459': 'circulatory system',
        '460-519': 'respiratory system',
        '520-579': 'digestive system',
        '580-629': 'genitourinary system',
        '630-679': 'complications of pregnancy, childbirth, and the puerperium',
        '680-709': 'skin and subcutaneous tissue',
        '710-739': 'musculoskeletal system and connective tissue',
        '740-759': 'congenital anomalies',
        '760-779': 'certain conditions originating in the perinatal period',
        '780-799': 'symptoms, signs, and ill-defined conditions',
        '800-999': 'injury and poisoning',
        'E-V': 'external causes of injury and supplemental classification'
    }
    if method == 1:
        code = code.split('.')[0]
        if ('E' in code.upper()) or ('V' in code.upper()):
            return 'E-V'
        elif int(code) < 139:
            return '001-139'
        elif int(code) < 239:
            return '140-239'
        elif int(code) < 279:
            return '240-279'
        elif int(code) < 289:
            return '280-289'
        elif int(code) < 319:
            return '290-319'
        elif int(code) < 359:
            return '320-359'
        elif int(code) < 389:
            return '360-389'
        elif int(code) < 459:
            return '390-459'
        elif int(code) < 519:
            return '460-519'
        elif int(code) < 579:
            return '520-579'
        elif int(code) < 629:
            return '580-629'
        elif int(code) < 679:
            return '630-679'
        elif int(code) < 709:
            return '680-709'
        elif int(code) < 739:
            return '710-739'
        elif int(code) < 759:
            return '740-759'
        elif int(code) < 779:
            return '760-779'
        elif int(code) < 799:
            return '780-799'
        elif int(code) < 899:
            return '800-899'
        else:
            return 'Unknown'

    if method == 2:
        return icd9code[categorize_icd9code(code)]

    if method == 3:
        return icd9code[code]



# drop StartYear and StopYear since they either have more than 50% as 0 or NaN
df1.drop(['StartYear', 'StopYear'], axis=1, inplace=True)
df1['ICD9CodeCategory'] = df1.ICD9Code.apply(lambda x: categorize_icd9code(x, 1))

diagnosis_agg = df1[['ICD9CodeCategory']]
diagnosis_agg.index = df1.PatientGuid
diagnosis_agg = pd.get_dummies(diagnosis_agg, prefix='Icd9', prefix_sep='_').reset_index().groupby('PatientGuid').sum()

s1 = diagnosis_agg.sum(axis=1)
s2 = (diagnosis_agg > 0).sum(axis=1)
diagnosis_agg['DiagnosisCount'] = s1
diagnosis_agg['VisitCount'] = s2
diagnosis_agg['DiagnosisFreq'] = s1 / s2

diagnosis_agg['AcuteCount'] = df1[['PatientGuid', 'Acute']].groupby('PatientGuid').sum()
diagnosis_agg['AcuteFreq'] = df1[['PatientGuid', 'Acute']].groupby('PatientGuid').sum() / df1[
    ['PatientGuid', 'Acute']].groupby('PatientGuid').count()

diagnosis_agg.to_csv('agg_data/diagnosis.csv')


