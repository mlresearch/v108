import sys, math
# sys.path.append('..')
from mxnet import autograd, gluon, init, nd
from mxnet.gluon import loss as gloss, nn, rnn, utils as gutils
import numpy as np
import time
import pandas as pd
from scipy.stats import norm

import sklearn
import matplotlib
import matplotlib.pyplot as plt
from scipy import stats

from sklearn.model_selection import train_test_split
from sklearn import metrics   #model optimization and valuation tools

from LORD import gamma, LORD_weight


## Contruct weight function as a neural network (multilayer perceptron)

class Model(nn.Block):
    def __init__(self, num_nodes, num_layers, scale, **kwargs):
        super(Model, self).__init__(**kwargs)
        self.scale = scale
        with self.name_scope():
            self.net = nn.Sequential()
            for i in range(num_layers - 1):
                self.net.add(nn.Dense(num_nodes, activation='relu'))
            self.dense = nn.Dense(1)

    def forward(self, x):
        x = self.dense(self.net(x))
        x = x.exp() * scale
        return x

## Define the loss functions: hard loss is true loss, and soft loss is an approximate of true loss by using sigmoid function.

def softloss(alpha, p):
    return -nd.sigmoid((alpha - p.reshape(alpha.shape)) * 1000).sum() / len(p)

def hardloss(alpha, p):
    return -(p.reshape(alpha.shape) < alpha).sum() * 1.0 / len(p)

def get_batch(pval, X, i):
    seq_len = min(batch_size, len(pval) - 1 - i)
    p = pval[i: i + seq_len]
    x = X[i: i + seq_len]
    return p, x

## Use context features in the weighted LORD++
## train weight function by multilayer perceptron


def train_network(trainer, net, pval, X, desireLevel, InitWealth, dim, ctx=None):
    train_dr_sum = nd.array([0.0], ctx=ctx)
    start_time = time.time()
    train_size = len(pval)
    steps = int(train_size / batch_size)
    cur_dr = 0

    for batch_i, idx in enumerate(range(0, steps * batch_size - 1, batch_size)):
        if batch_i == 10:
            trainer.set_learning_rate(trainer.learning_rate * 0.1)
        if batch_i == 20:
            trainer.set_learning_rate(trainer.learning_rate * 0.1)

        p_train, x_train = get_batch(pval, X, idx)

        with autograd.record():
            weight = net(x_train)
            alpha = LORD_weight(p_train, weight, desireLevel, InitWealth)
            loss = softloss(alpha, p_train)

        if sum(alpha == 0) < len(p_train) / 10.0:
            loss.backward(retain_graph=True)

            grads = [p.grad(ctx) for p in net.collect_params().values()]
            gutils.clip_global_norm(
                grads, clipping_theta * batch_size)
            trainer.step(1)
        train_dr_sum -= loss

        if (batch_i + 1) % eval_period == 0 and batch_i > 0:
            cur_dr = train_dr_sum / eval_period
            print('batch', batch_i, 'train discovery rate', cur_dr.asscalar())
            train_dr_sum = nd.array([0], ctx=ctx)

    print('time %.2fs'
          % (time.time() - start_time))
    return cur_dr


def LORD_weight_H(pval, weight, desireLevel, InitWealth, H=None):
    num_hyp = len(pval)
    gamma_vec = gamma(num_hyp)
    wealth = [nd.array([InitWealth])]  # the budget(wealth) starts from w0
    alpha = [0]
    rewards = desireLevel - InitWealth  # In LORD, psi[i] = b[i] is the pay-off (rewards) of a rejection

    tau = 0  # record the time of most recent discovery
    D = 0  # number of discoveries
    Non_nulls = 0  # number of true alternatives

    DP = []
    estFDP = []
    Power = 0  # record true discoveries
    Error = 0  # record false discoveries
    TDP = []
    FDP = []

    alpha_sum = 0.0
    for i in range(1, num_hyp + 1):
        p = pval[i - 1]  # pval starts from pval[0]

        # calculate alpha
        if tau == 0:
            level = gamma_vec[i - 1] * InitWealth * weight[i - 1]
        else:
            level = gamma_vec[i - 1 - tau] * desireLevel * weight[i - 1]
            rewards = desireLevel
        # print('level', level)

        # compare alpha to current wealth
        if wealth[i - 1] < level:
            alpha.append(wealth[i - 1])
            wealth.append(nd.array([0]))
        else:
            alpha.append(level)
            wealth.append(wealth[i - 1] - alpha[i])  # In LORD, alpha[i] = phi[i] is the pay-out for each test

        # perform current test
        if p <= alpha[i]:
            tau = i
            D += 1
            wealth[i] = wealth[i] + rewards
            if H is not None:
                if H[i - 1] == 0:
                    Error += 1
                else:
                    Power += 1

        if H is not None:
            Non_nulls += (H[i - 1] == 1)

        if tau != 0:
            DP.append(D * 1.0 / i)  # record discovery proportion at time i after first discovery
            TDP.append(Power * 1.0 / max(Non_nulls, 1))  # record exact TDP

        FDP.append(Error * 1.0 / max(D, 1))  # record exact FDP
        alpha_sum += alpha[i]
        estFDP.append(alpha_sum * 1.0 / max(D, 1))

    alpha = alpha[1:]
    alpha = nd.stack(*alpha)

    if H is not None:
        return alpha, D, DP, estFDP, TDP, FDP
    else:
        return alpha, D, DP, estFDP

## The parameters need to be re-tuned when conducting different experiments

num_nodes = 10
num_layers = 10
scale = 1
# lr = 0.5 # for 1D
lr = 0.3 # for 2D, 3D
clipping_theta = 0.7
batch_size = 100  ## mini-batch size
eval_period = 30

desireLevel = 0.4
InitWealth = 0.2

rep = 20  # number of repeats


def main():

    ## read data
    gtex = pd.read_csv('data_gtex.csv')
    # gtex_sort = gtex.sort_values(by = [' p_value'], ascending = [True])

    ## GTEx 1d with x_value (log of x1) as feature
    x_value = gtex['x_value']
    # x_value = np.log(gtex['x2'])
    # x_value = gtex['x3']
    p_value = gtex[' p_value']

    ## GTEx 2d with x_value and log of x2 as features
    # x1 = gtex['x_value']
    # x2 = np.log(gtex['x2'])
    # x_value = pd.concat([x1, x2], axis=1)
    # p_value = gtex[' p_value']

    ## GTEx 3d with x_value, log of x2 and x3 as features
    # x1 = gtex['x_value']
    # x2 = np.log(gtex['x2'])
    # x3 = gtex['x3']
    # x_value = pd.concat([x1, x2, x3], axis = 1)
    # p_value = gtex[' p_value']



    # plot the histogram of pvalues

    hy, hx = np.histogram(p_value, bins=20, normed=True)
    plt.figure(figsize=(5, 3))
    plt.bar(hx[:-1], hy, width=0.03, color='blue', edgecolor='none')
    plt.xlabel("p_value")
    plt.ylabel("Count")
    plt.show()

    # plot the histogram of xvalues (contextual features: log count of each genes)

    hy1, hx1 = np.histogram(x_value[:100], bins=20, normed=True)
    plt.figure(figsize=(5, 3))
    plt.bar(hx1[:-1], hy1, width=0.5, color='green', edgecolor='none')
    plt.xlabel("x_value")
    plt.ylabel("Count")
    plt.show()

    # record results for baseline LORD++
    d0 = 0
    dr0_sum = nd.array([0.0])
    fdr0_sum = nd.array([0.0])
    tdr0_sum = nd.array([0.0])

    # record results for weighted LORD++
    d_weight = 0
    dr_sum_weight = nd.array([0.0])
    fdr_sum_weight = nd.array([0.0])
    tdr_sum_weight = nd.array([0.0])

    for r in range(rep):

        # random split the dataset into two parts for training(50%), and testing(50%).

        Xtrain, Xtest, ptrain, ptest = train_test_split(x_value, p_value, test_size=0.4)
        ptrain = nd.array(ptrain.tolist())
        Xtrain = nd.array(Xtrain.values.tolist())
        ptest = nd.array(ptest.tolist())
        Xtest = nd.array(Xtest.values.tolist())

        ## 1. apply the baseline LORD to the test data return the empirical estimated FDR, discovery number and discovery proportion

        weight0 = nd.ones(len(ptest))  # set weight to be ones
        alpha0, D0, DP0, estFDP0 = LORD_weight_H(ptest, weight0, desireLevel, InitWealth, H=None)
        d0 += D0
        dr0_sum += D0 / len(ptest)
        fdr0_sum += sum(estFDP0) / len(ptest)

        ## 2. train weight function on the training set

        net = Model(num_nodes, num_layers, scale)
        net.initialize(init=init.Xavier())
        trainer = gluon.Trainer(net.collect_params(), 'sgd', {'learning_rate': lr, 'momentum': 0.2, 'wd': 0})

        dim = len(Xtrain[0])  # number of context predictors

        train_dr = train_network(trainer, net, ptrain, Xtrain, desireLevel, InitWealth, dim, ctx=None)

        ## 3. apply the weighted LORD to the test data

        if train_dr < 0.001:
            weight = nd.ones(len(ptest))
        else:
            weight = net(Xtest)
        alpha_weight, D_weight, DP_weight, estFDP_weight = LORD_weight_H(ptest, weight, desireLevel, InitWealth, H=None)
        d_weight += D_weight
        dr_sum_weight += D_weight / len(ptest)
        fdr_sum_weight += sum(estFDP_weight) / len(ptest)

    print('Number of discoveries of LORD with weight:', d_weight / rep)
    print('Discovery rate of LORD with weight:', dr_sum_weight / rep)
    print('Average empirical false discovery rate (FDR) of LORD with weight:', fdr_sum_weight / rep, '\n')

    print('Baseline number of discoveries:', d0 / rep)
    print('Baseline discovery rate:', dr0_sum / rep)
    print('Baseline average empirical false discovery rate (FDR):', fdr0_sum / rep, '\n')


if __name__ == "__main__":
    main()


