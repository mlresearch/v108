import sys, math
sys.path.append('..')
from mxnet import autograd, gluon, init, nd
from mxnet.gluon import loss as gloss, nn, rnn, utils as gutils

import time
import pandas as pd
from scipy.stats import norm

import numpy as np

import sklearn
import matplotlib
import matplotlib.pyplot as plt
from scipy import stats

from sklearn.linear_model import LogisticRegression
from sklearn import metrics   # model optimization and valuation tools
from sklearn.model_selection import train_test_split

from LORD import gamma, LORD_weight, LORD_weight_H



def hist_numerical(df,col,nbins=10,target='DMIndicator',yscale='linear',normalize=False):
    """
    This function generate histogram of numerical variables
    df (pandas.dataframe): original dataset
    col (str): independent variable to be on x-axis. It has to be a column of df
    nbins (int): number of bins to be created
    target (str): dependent variable. It has to be a column of df
    yscale (str): use either linear for linear scale or log for log scale
    normalize (bool): True - bars are normalized or - not otherwise
    """
    x = df[col]
    hy1,hx1 = np.histogram(df[col][df[target] == 1],bins=nbins,normed=normalize)
    hy2,hx2 = np.histogram(df[col][df[target] == 0],bins=hx1,normed=normalize)
    w = 0.4*(hx1[1] - hx1[0])
    plt.figure(figsize=(5,3))
    plt.bar(hx1[:-1],hy1,width=w,color='blue',edgecolor='none')
    plt.bar(hx2[:-1]+w,hy2,width=w,color='green',edgecolor='none')
    plt.xlabel(col)
    plt.ylabel("Count")
    plt.yscale(yscale)
    plt.legend([1,0],title=target)
    print(col, stats.ttest_ind(df[col][df[target] == 1],df[col][df[target] == 0]))


patients = pd.read_csv('agg_data/patient.csv',index_col='PatientGuid').sort_index()
diagnosis = pd.read_csv('agg_data/diagnosis.csv',index_col='PatientGuid').sort_index()
physicians = pd.read_csv('agg_data/physician_specialty.csv',index_col='PatientGuid').sort_index()
transcripts = pd.read_csv('agg_data/transcript.csv',index_col='PatientGuid').sort_index()
medications = pd.read_csv('agg_data/medication.csv',index_col='PatientGuid').sort_index()
medications.columns = map(lambda x:'med_'+x,medications.columns)


data = pd.concat([diagnosis,physicians,transcripts,medications,patients], axis=1, sort = False)
data.fillna(0,inplace=True)
target = 'DMIndicator'

# Create artifical IDs. These will be useful later to keep track of training and validation sets
data['ID'] = range(data.shape[0])
print("size of dataframe:", data.shape)


# Duplicate each diabetic patient’s records 3 times because the data set was highly skewed (upsampling)
data_dup = data.copy()
data_dup1 = data_dup.loc[data_dup['DMIndicator'] == 1]
data_dup = pd.concat([data_dup, data_dup1, data_dup1, data_dup1], axis = 0)



# Random split dataset into 40%, 40%, 20% as training set, validation set and test set
# Fit a logistic model with all features on training set

predictors = [x for x in data_dup.columns if 'DMIndicator' not in x]
Xtrain, Xtest, Ytrain, Ytest = train_test_split(data_dup[predictors], data_dup[target], test_size=0.2)
Xtrain, Xval, Ytrain, Yval = train_test_split(Xtrain, Ytrain, test_size = 1/2.)
model = LogisticRegression()
model.fit(Xtrain, Ytrain)
y_val_proba = model.predict_proba(Xval)
y_test_proba = model.predict_proba(Xtest)
y_test_pred = model.predict(Xtest)
report = metrics.classification_report(Ytest.ravel(), y_test_pred)
print(report)
fpr, tpr, _ = sklearn.metrics.roc_curve(Ytest, y_test_proba[:,1])
auc = sklearn.metrics.auc(fpr, tpr)
print('auc of test set:', auc)
cm = metrics.confusion_matrix(Ytest, y_test_pred)
print(cm)
roc_rates = [fpr, tpr]
plt.title("Logistic Regression with full features", fontsize = 20)
plt.xlabel("False positive rate")
plt.ylabel("True positive rate")
labelname = "Logistic Regression" + ", (area = %0.4f)" % auc
plt.plot(roc_rates[0], roc_rates[1], linewidth = 2, label = labelname)
plt.legend(loc = 4)


## Compute pvalues for test set by using predictive scores in validation set as an empirical null distribution

def computePval(y_test_proba, y_val_proba0):
    pval = []
    for j in range(len(y_test_proba)):
        s = 0.0
        n0 = len(y_val_proba0)
        for i in range(n0):
            if y_val_proba0[i] < y_test_proba[j][0]:
                s += 1
        pval.append(s/n0)
    return pval




I0 = [i for i in range(len(Yval)) if Yval[i] == 0] ## index of null set
y_val_proba0 = [y_val_proba[i][0] for i in I0 if y_val_proba[i][0] > 0] ## predictive scores for null distribution
pval = computePval(y_test_proba, y_val_proba0) 
pvalues = pd.DataFrame({'pval': pval, 'DMIndicator': Ytest})
hist_numerical(pvalues,'pval', nbins=20, yscale='linear', normalize=True)
plt.show()


# Split features into two parts, one part is for training logistic model, the other provides context features in testing process (LORD).
# Features in diagnosis, physicians, medications are used for training logistic model
# Features in transcripts, patients are considered as context, and used in training the weight function

# Random split dataset into 40%, 40%, 20% as training set, validation set and test set
# Fit a logistic model with first part of the features on training set

train = pd.concat([data_dup[diagnosis.columns], data_dup[physicians.columns], data_dup[medications.columns]], axis = 1)
context = pd.concat([data_dup[transcripts.columns], data_dup[patients.columns]], axis = 1)

Xtrain, Xtest, Ytrain, Ytest = train_test_split(train, context[target],test_size = 0.2)
Xtrain, Xval, Ytrain, Yval = train_test_split(Xtrain, Ytrain, test_size = 1/2.)
model1 = LogisticRegression()
model1.fit(Xtrain, Ytrain)
y_val_proba = model1.predict_proba(Xval)
y_val_pred = model1.predict(Xval)
y_test_proba = model1.predict_proba(Xtest)
y_test_pred = model1.predict(Xtest)
report = metrics.classification_report(Ytest.ravel(), y_test_pred)
print(report)
fpr, tpr, _ = sklearn.metrics.roc_curve(Ytest, y_test_proba[:,1])
auc = sklearn.metrics.auc(fpr, tpr)
print('auc of test set:', auc)
cm = metrics.confusion_matrix(Ytest, y_test_pred)
print(cm)
roc_rates = [fpr, tpr]
plt.title("Logistic Regression with part features", fontsize = 20)
plt.xlabel("False positive rate")
plt.ylabel("True positive rate")
labelname = "Logistic Regression" + ", (area = %0.4f)" % auc
plt.plot(roc_rates[0], roc_rates[1], linewidth = 2, label = labelname)
plt.legend(loc = 4)


# Visualize the empirical histograms of pvalues for model with first part of features

I0 = [i for i in range(len(Yval)) if Yval[i] == 0] ## index of null set
y_val_proba0 = [y_val_proba[i][0] for i in I0 if y_val_proba[i][0] > 0] ## predictive scores for null distribution
pval = computePval(y_test_proba, y_val_proba0) 
pvalues = pd.DataFrame({'pval': pval, 'DMIndicator': Ytest})
hist_numerical(pvalues,'pval',nbins=20,yscale='linear',normalize=True)
plt.show()



## Contruct weight function as a neural network (multilayer perceptron)

class Model(nn.Block):
    def __init__(self, num_nodes, num_layers, scale, **kwargs):
        super(Model, self).__init__(**kwargs)
        self.scale = scale
        with self.name_scope():
            self.net = nn.Sequential()
            for i in range(num_layers - 1):
                self.net.add(nn.Dense(num_nodes, activation = 'relu'))
            self.dense = nn.Dense(1)
            
    def forward(self, x):
        x = self.dense(self.net(x))
        x = x.exp()*scale
        return x


## Define the loss functions: hard loss is true loss, and soft loss is an approximate of true loss by using sigmoid function.

def softloss(alpha, p):
    return -nd.sigmoid((alpha - p.reshape(alpha.shape)) * 1000).sum() / len(p)

def hardloss(alpha, p):
    return -(p.reshape(alpha.shape) < alpha).sum() * 1.0 / len(p)


def get_batch(pval, X, i):
    seq_len = min(batch_size, len(pval)-1-i)
    p = pval[i : i+seq_len]
    x = X[i : i+seq_len]
    return p, x


## Use context features in the weighted LORD++
## train weight function by multilayer perceptron


def train_network(net, pval, X, desireLevel, InitWealth, dim, ctx = None):
    train_dr_sum = nd.array([0.0], ctx=ctx)
    start_time = time.time()
    train_size = len(pval)
    steps = int(train_size / batch_size)
    cur_dr = 0
                
    for batch_i, idx in enumerate(range(0, steps * batch_size - 1, batch_size)):
        if batch_i == 10:
            trainer.set_learning_rate(trainer.learning_rate * 0.1)
        if batch_i == 20:
            trainer.set_learning_rate(trainer.learning_rate * 0.1)
        if batch_i == 100:
            trainer.set_learning_rate(trainer.learning_rate * 0.5)
        p_train, x_train = get_batch(pval, X, idx)
        
        with autograd.record():
            weight = net(x_train)
            alpha = LORD_weight(p_train, weight, desireLevel, InitWealth)
            loss = softloss(alpha, p_train)
            
        if sum(alpha==0) < len(p_train)/10.0:  
            loss.backward(retain_graph=True)
            
            grads = [p.grad(ctx) for p in net.collect_params().values()]
            gutils.clip_global_norm(
                    grads, clipping_theta * batch_size)
            trainer.step(1)
        train_dr_sum -= loss
        
        if (batch_i+1) % eval_period == 0 and batch_i > 0:
            cur_dr = train_dr_sum / eval_period
            print('batch', batch_i, 'train discovery rate', cur_dr.asscalar())
            train_dr_sum = nd.array([0], ctx=ctx)
        
    print('time %.2fs'
        % (time.time() - start_time))
    return cur_dr


num_nodes = 10
num_layers = 10
scale = 1
lr = 0.2
clipping_theta = 0.7
batch_size = 15  ## mini-batch size
eval_period = 30


desireLevel = 0.2  ## pre-chosen FDR control level
InitWealth = 0.1   ## initial wealth


rep = 20  # number of repeats


# Fit logistic model with first part of features and record results for baseline LORD++
d0_part = 0
dr0_sum_part = nd.array([0.0])
fdr0_sum_part = nd.array([0.0])
tdr0_sum_part = nd.array([0.0])

# Fit logistic model with first part of features and train weight function with second part of features,
# record results for weighted LORD++
d_weight = 0
dr_sum_weight = nd.array([0.0])
fdr_sum_weight = nd.array([0.0])
tdr_sum_weight = nd.array([0.0])

for r in range(rep):

    # Random split the dataset into four parts trainset1(40%), trainset2(20%), testset1(20%), testset2(20%).
    # Trainset1 is used for training a prediction model, and trainset2 is used to provide empirical null distribution. 
    # Testset1 is used for traininig the weight function in weighted LORD, testset2 is used to compare the performance of weighted and unweighted LORD.

    predictors = [x for x in data_dup.columns if 'DMIndicator' not in x]
    Xtrain, Xtest, Ytrain, Ytest = train_test_split(data_dup[predictors], data_dup[target], test_size=0.4)
    Xtrain1, Xtrain2, Ytrain1, Ytrain2 = train_test_split(Xtrain, Ytrain, test_size=1 / 3.)
    Xtest1, Xtest2, Ytest1, Ytest2 = train_test_split(Xtest, Ytest, test_size=1 / 2.)

    # split the features into two parts: train_predictors, context_predictors

    train_predictors = [x for x in Xtrain.columns if x in diagnosis.columns or x in physicians.columns or x in
                        medications.columns]
    context_predictors = [x for x in Xtrain.columns if 'DMIndicator' not in x and
                          (x in transcripts.columns or x in patients.columns)]
    F_train1, F_train2, F_test1, F_test2 = Xtrain1[train_predictors], Xtrain2[train_predictors], Xtest1[
        train_predictors], Xtest2[train_predictors],
    C_train1, C_train2, C_test1, C_test2 = Xtrain1[context_predictors], Xtrain2[context_predictors], Xtest1[
        context_predictors], Xtest2[context_predictors]



    ## 1. Train logistic model using first part of the features, compute pvalues of testset2 (ignore testset1), and apply baseline LORD++

    model_part = LogisticRegression()
    model_part.fit(F_train1, Ytrain1)

    y_train2_proba = model_part.predict_proba(F_train2)
    y_test2_proba = model_part.predict_proba(F_test2) 
    
    
    I0 = [i for i in range(len(Xtrain2)) if Ytrain2[i] == 0]
    y_train2_proba0 = [y_train2_proba[i][0] for i in I0]  
    pval_test = computePval(y_test2_proba, y_train2_proba0) # compute scores for trainset2 using model_part to get null distribution
    pvalues_test = pd.DataFrame({'pval_test': pval_test, 'DMIndicator': Ytest2})
    pvalues_test_sort = pvalues_test.sort_values(by=['pval_test'], ascending = [True]) # sort pvalues ascendingly to get more discoveries
    
    pval_test = pvalues_test_sort.pval_test
    H_test = pvalues_test_sort.DMIndicator
    
    weight_part = nd.ones(len(pval_test))
    alpha0_part, D0_part, DP0_part, estFDP0_part, TDP0_part, FDP0_part = LORD_weight_H(pval_test, weight_part,
                                                                                       desireLevel, InitWealth, H_test)
    d0_part += D0_part
    dr0_sum_part += D0_part / len(pval_test)
    fdr0_sum_part += FDP0_part[-1]
    tdr0_sum_part += sum(TDP0_part) / len(pval_test)
    
    
    ## 2.1 compute pvalues of testset1

    y_test1_proba = model_part.predict_proba(F_test1)

    pval = computePval(y_test1_proba, y_train2_proba0)  # compute pvalues for test dataset1
    pvalues = pd.DataFrame({'pval': pval, 'DMIndicator': Ytest1})
    pvalues = pd.concat([pvalues, C_test1], axis=1)  # get a dataframe consisting pvalues, DMIndicators and contexts

    pval = pvalues.pval
    H = pvalues.DMIndicator
    Context = pvalues[context_predictors]
    pval = nd.array(pval.tolist())
    H = nd.array(H.tolist())
    Context = nd.array(Context.values.tolist())



    ## 2.2 Using pvalues of testset1 to train weight function with second part of the features (context predictors)

    net = Model(num_nodes, num_layers, scale)
    net.initialize(init=init.Xavier())
    trainer = gluon.Trainer(net.collect_params(), 'sgd', {'learning_rate': lr, 'momentum': 0.3, 'wd': 0})

    dim = len(Context[0])  # number of context predictors

    train_dr = train_network(net, pval, Context, desireLevel, InitWealth, dim, ctx=None)


    ## 2.3 For the same pvalues of testset2, apply the weighted LORD++ trained in last step

    pval_test = computePval(y_test2_proba, y_train2_proba0)
    pvalues_test = pd.DataFrame({'pval_test': pval_test, 'DMIndicator': Ytest2})
    pvalues_test = pd.concat([pvalues_test, C_test2], axis=1)
    pvalues_test = pvalues_test.sort_values(by=['pval_test'], ascending=[True])

    pval_test = pvalues_test.pval_test
    H_test = pvalues_test.DMIndicator
    Context_test = pvalues_test[context_predictors]
    pval_test = nd.array(pval_test.tolist())
    H_test = nd.array(H_test.tolist())
    Context_test = nd.array(Context_test.values.tolist())

    if train_dr < 0.01:
        weight = nd.ones(len(pval_test))
    else:
        weight = net(Context_test)
    alpha_weight, D_weight, DP_weight, estFDP_weight, TDP_weight, FDP_weight = LORD_weight_H(pval_test, weight,
                                                                                             desireLevel, InitWealth,
                                                                                             H_test)
    d_weight += D_weight
    dr_sum_weight += D_weight / len(pval_test)
    fdr_sum_weight += FDP_weight[-1]
    tdr_sum_weight += sum(TDP_weight) / len(pval_test)



print('Number of discoveries of weighted LORD with partial features:', d_weight / rep)
print('Discovery rate of weighted LORD with partial features:', dr_sum_weight / rep)
print('Average false discovery rate (FDR) of weighted LORD with partial features:', fdr_sum_weight / rep)
print('Average true discovery rate (TDR) of weighted LORD with partial features:', tdr_sum_weight / rep, '\n')

print('Baseline number of discoveries with partial features:', d0_part / rep)
print('Baseline discovery rate with partial features:', dr0_sum_part / rep)
print('Baseline average false discovery rate (FDR) with partial features:', fdr0_sum_part / rep)
print('Baseline average true discovery rate (TDR) with partial features:', tdr0_sum_part / rep, '\n')





## Repeat the above experiments but use full features in training a logistic regression

# fit logistic model with full features and record results for baseline LORD++ 
d0 = 0
dr0_sum = nd.array([0.0])
fdr0_sum = nd.array([0.0])
tdr0_sum = nd.array([0.0])


# fit logistic model with full features and train weight function with contextual features (part of full features),
# record results for weighted LORD++ 
d_weight = 0
dr_sum_weight = nd.array([0.0])
fdr_sum_weight = nd.array([0.0])
tdr_sum_weight = nd.array([0.0])

for r in range(rep):
    
    # random split the dataset into four parts trainset1(40%), trainset2(20%), testset1(20%), testset2(20%).
    
    predictors = [x for x in data_dup.columns if 'DMIndicator' not in x]
    Xtrain, Xtest, Ytrain, Ytest = train_test_split(data_dup[predictors], data_dup[target], test_size=0.4)
    Xtrain1, Xtrain2, Ytrain1, Ytrain2 = train_test_split(Xtrain, Ytrain, test_size = 1/3.)
    Xtest1, Xtest2, Ytest1, Ytest2 = train_test_split(Xtest, Ytest, test_size = 1/2.)
    
    # split the features into two parts: train_predictors, context_predictors

    train_predictors = [x for x in Xtrain.columns if x in diagnosis.columns or x in physicians.columns or x in
                       medications.columns]
    context_predictors = [x for x in Xtrain.columns if 'DMIndicator' not in x and 
                      (x in transcripts.columns or x in patients.columns)]
    C_train1, C_train2, C_test1, C_test2 = Xtrain1[context_predictors], Xtrain2[context_predictors], Xtest1[context_predictors], Xtest2[context_predictors]
    
    
    ## 1. train logistic model using all the features, compute pvalues of testset2 (ignore testset1), apply baseline LORD++
    
    model = LogisticRegression()
    model.fit(Xtrain1, Ytrain1) 
    
    y_train2_proba = model.predict_proba(Xtrain2) # compute scores for trainset2 using full model to get null distribution
    y_test2_proba = model.predict_proba(Xtest2) # compute scores and pvalues for testset2, ignore test dataset1.
    
    I0 = [i for i in range(len(Xtrain2)) if Ytrain2[i] == 0]
    y_train2_proba0 = [y_train2_proba[i][0] for i in I0]
    pval_test = computePval(y_test2_proba, y_train2_proba0)
    pvalues_test = pd.DataFrame({'pval_test': pval_test, 'DMIndicator': Ytest2})
    pvalues_test_sort = pvalues_test.sort_values(by=['pval_test'], ascending = [True]) # sort pvalues ascendingly to get more discoveries
    
    pval_test = pvalues_test_sort.pval_test
    H_test = pvalues_test_sort.DMIndicator
    
    weight = nd.ones(len(pval_test)) # set weight to be ones
    alpha0, D0, DP0, estFDP0, TDP0, FDP0 = LORD_weight_H(pval_test, weight, desireLevel, InitWealth, H_test)
    d0 += D0
    dr0_sum +=  D0/len(pval_test)
    fdr0_sum += FDP0[-1]
    tdr0_sum += sum(TDP0)/len(pval_test)
    
    
    
    ## 2.1 compute pvalues of testset1

    y_test1_proba = model.predict_proba(Xtest1)

    pval = computePval(y_test1_proba, y_train2_proba0)   # compute pvalues for test dataset1
    pvalues = pd.DataFrame({'pval': pval, 'DMIndicator': Ytest1})
    pvalues = pd.concat([pvalues, C_test1], axis = 1) # get a dataframe consisting pvalues, DMIndicators and contexts
    
    pval = pvalues.pval
    H = pvalues.DMIndicator
    Context = pvalues[context_predictors]
    pval = nd.array(pval.tolist())
    H = nd.array(H.tolist())
    Context = nd.array(Context.values.tolist())
    
    
    ## 2.2 Using pvalues of testset1 to train weight function with contextual features
    
    net = Model(num_nodes, num_layers, scale)
    net.initialize(init= init.Xavier())
    trainer = gluon.Trainer(net.collect_params(), 'sgd', {'learning_rate': lr, 'momentum': 0.3, 'wd': 0})
    
    dim = len(Context[0]) # number of context predictors

    train_dr = train_network(net, pval, Context, desireLevel, InitWealth, dim, ctx = None) 
   
    
    ## 2.3 compute pvalues for testset2 and apply the weighted LORD++ on them using trained weight function 
    
    pvalues_test_context = pd.concat([pvalues_test, C_test2], axis = 1)
    pvalues_test_context = pvalues_test_context.sort_values(by=['pval_test'], ascending = [True])
    
    pval_test = pvalues_test_context.pval_test
    H_test = pvalues_test_context.DMIndicator
    Context_test = pvalues_test_context[context_predictors]
    pval_test = nd.array(pval_test.tolist())
    H_test = nd.array(H_test.tolist())
    Context_test = nd.array(Context_test.values.tolist())
    
    if train_dr < 0.01:
        weight = nd.ones(len(pval_test))
    else:
        weight = net(Context_test) 
    alpha_weight, D_weight, DP_weight, estFDP_weight, TDP_weight, FDP_weight = LORD_weight_H(pval_test, weight, desireLevel, InitWealth, H_test)
    d_weight  += D_weight 
    dr_sum_weight  +=  D_weight /len(pval_test)
    fdr_sum_weight  += FDP_weight [-1]
    tdr_sum_weight  += sum(TDP_weight )/len(pval_test)
    
    
    
print('Number of discoveries of weighted LORD with full features:', d_weight /rep)
print('Discovery rate of weighted LORD with full features:', dr_sum_weight / rep)
print('Average false discovery rate (FDR) of weighted LORD with full features:', fdr_sum_weight / rep)
print('Average true discovery rate (TDR) of weighted LORD with full features:', tdr_sum_weight / rep, '\n')


print('Baseline number of discoveries with full features:', d0 /rep)
print('Baseline discovery rate with full features:', dr0_sum / rep)
print('Baseline average false discovery rate (FDR) with full features', fdr0_sum / rep)
print('Baseline average true discovery rate (TDR) with full features:', tdr0_sum / rep, '\n')



