## MXNet and Gluon should be installed before running the codes.


import sys, math
sys.path.append('..')
from mxnet import autograd, gluon, init, nd

import numpy as np


## function generate the hyperparameter gamma in the LORD procedure

def gamma(num_hyp):
    # discounting factor gamma
    tmp = range(1, num_hyp + 1)
    gamma_vec =  np.true_divide(np.log(np.maximum(tmp,np.ones(len(tmp))*2)), np.multiply(tmp, np.exp(np.sqrt(np.log(np.maximum(np.ones(len(tmp)), tmp))))))
    gamma_vec = gamma_vec / np.float(sum(gamma_vec))
    return nd.array(gamma_vec)


## implementation of weighted LORD++

def LORD_weight(pval, weight, desireLevel, InitWealth):
    num_hyp = len(pval)
    gamma_vec = gamma(num_hyp)
    wealth = [nd.array([InitWealth])]  # the budget(wealth) starts from w0
    alpha = [0]
    rewards = desireLevel - InitWealth  # In LORD, psi[i] = b[i] is the pay-off (rewards) of a rejection

    tau = 0  # record the time of most recent discovery

    for i in range(1, num_hyp + 1):
        p = pval[i - 1]  # pval starts from pval[0]

        # calculate significance level alpha
        if tau == 0:
            level = gamma_vec[i - 1] * InitWealth * weight[i - 1]
        else:
            level = gamma_vec[i - 1 - tau] * desireLevel * weight[i - 1]
            rewards = desireLevel

        # compare alpha to current wealth
        if wealth[i - 1] < level:
            alpha.append(wealth[i - 1])
            wealth.append(nd.array([0]))
        else:
            alpha.append(level)
            wealth.append(wealth[i - 1] - alpha[i])  # In LORD, alpha[i] = phi[i] is the pay-out for each test

        # perform current test
        if p <= alpha[i]:
            tau = i
            wealth[i] = wealth[i] + rewards

    alpha = alpha[1:]
    alpha = nd.stack(*alpha)
    return alpha



## implementation of weighted LORD++ and return FDP and TDP when having acess to ground truth

def LORD_weight_H(pval, weight, desireLevel, InitWealth, H):
    num_hyp = len(pval)
    gamma_vec = gamma(num_hyp)
    wealth = [nd.array([InitWealth])]    # the budget(wealth) starts from w0
    alpha = [0]    
    rewards = desireLevel - InitWealth   # In LORD, psi[i] = b[i] is the pay-off (rewards) of a rejection

    tau = 0  # record the time of most recent discovery
    D = 0    # number of discoveries
    Non_nulls = 0 # number of true alternatives
    
    DP = []   
    estFDP = []
    Power = 0  # record true discoveries
    Error = 0  # record false discoveries
    TDP = []    
    FDP = []
        
    alpha_sum = 0.0
    for i in range(1, num_hyp + 1):
        p = pval[i - 1]  # pval starts from pval[0]
        
        # calculate alpha
        if tau == 0:
            level = gamma_vec[i - 1] * InitWealth * weight[i-1]
        else:
            level = gamma_vec[i - 1 - tau] * desireLevel * weight[i-1]
            rewards = desireLevel
            
        # compare alpha to current wealth
        if wealth[i-1] < level:
            alpha.append(wealth[i-1])
            wealth.append(nd.array([0]))
        else:
            alpha.append(level)
            wealth.append(wealth[i-1] - alpha[i])  # In LORD, alpha[i] = phi[i] is the penalty for each test

        # perform current test
        if p <= alpha[i]:
            tau = i
            D += 1
            wealth[i] = wealth[i] + rewards # get a reward when make a rejection
            if H[i-1] == 0:
                Error += 1
            else:
                Power += 1
                    
        Non_nulls += (H[i-1] == 1)

        if tau != 0:
            DP.append(D * 1.0 / i)  # record discovery proportion at time i after first discovery
            TDP.append(Power * 1.0 / max(Non_nulls, 1))  # record exact TDP at time i after first discovery

        FDP.append(Error * 1.0 / max(D, 1)) # record exact FDP
        alpha_sum += alpha[i]
        estFDP.append(alpha_sum * 1.0 / max(D, 1)) #estimate of FDP

    alpha = alpha[1:]
    alpha = nd.stack(*alpha)

    return alpha, D, DP, estFDP, TDP, FDP



