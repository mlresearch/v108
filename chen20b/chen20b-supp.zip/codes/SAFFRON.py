import sys, math
sys.path.append('..')
from mxnet import autograd, gluon, init, nd

import numpy as np


# Create discounting factor gamma with varying the parameter s.

def gamma_s(num_hyp, s):
    # discounting factor gamma
    tmp = range(1, num_hyp + 1)
    gamma_vec = np.true_divide(np.ones(len(tmp)), np.power(tmp, s))
    gamma_vec = gamma_vec / np.float(sum(gamma_vec))
    return nd.array(gamma_vec)


## implementation of weighted SAFFRON

def SAFFRON_weight(pval, weight, desireLevel, InitWealth, lambda_, s=None):
    num_hyp = len(pval)
    if s == None:
        gamma_vec = gamma(num_hyp)
    else:
        gamma_vec = gamma_s(num_hyp, s)

    wealth = [nd.array([InitWealth])]  # the budget (wealth) starts from w0
    alpha = [0]
    rewards = (1 - lambda_) * desireLevel - InitWealth
    # In SAFFRON, psi[i] = b[i] is the pay-off (rewards) of a rejection
    candidacy = 0
    tau = 0  # record the time of most recent discovery

    for i in range(1, num_hyp + 1):

        p = pval[i - 1]  # pval starts from pval[0]

        # calculate alpha (significance level)

        if tau == 0:
            level = gamma_vec[i - 1 - candidacy] * InitWealth * weight[i - 1]
        else:
            level = gamma_vec[i - 1 - tau - candidacy] * rewards * weight[i - 1]
            rewards = (1 - lambda_) * desireLevel
        level = min(level, nd.array([lambda_]))

        # calculate C_j+ (recording the number of candidates)
        if p <= lambda_:
            candidacy = candidacy + 1
            alpha.append(level)
            wealth.append(wealth[i - 1])  # In SAFFRON, testing a candidacy will never lose wealth
        elif p > lambda_ and wealth[i - 1] < level:
            alpha.append(wealth[i - 1])
            wealth.append(nd.array([0]))
        else:
            alpha.append(level)
            wealth.append(wealth[i - 1] - level)  # In SAFFRON, alpha[i] = phi[i] is the pay-out (penalty) for each test

        # perform current test
        if p <= alpha[i]:
            tau = i
            candidacy = 0
            wealth[i] = wealth[i] + rewards

    alpha = alpha[1:]
    alpha = nd.stack(*alpha)
    return alpha


## implementation of weighted SAFFRON and return FDP and TDP when knowing ground truth (H)

def SAFFRON_weight_H(pval, weight, desireLevel, InitWealth, lambda_, H, s=None):
    num_hyp = len(pval)

    ## choose one version of hyper-parameter (discounting factor)
    if s == None:
        gamma_vec = gamma(num_hyp)
    else:
        gamma_vec = gamma_s(num_hyp, s)

    wealth = [nd.array([InitWealth])]  # the budget(wealth) starts from w0
    alpha = [0]
    rewards = (1 - lambda_) * desireLevel - InitWealth
    # In SAFFRON, psi[i] = b[i] is the pay-off (rewards) of a rejection
    candidacy = 0
    tau = 0  # record the time of most recent discovery

    tau = 0  # record the time of most recent discovery
    D = 0  # number of discoveries
    Non_nulls = 0  # number of true alternatives

    DP = []
    Power = 0  # record true discoveries
    Error = 0  # record false discoveries
    TDP = []
    FDP = []

    for i in range(1, num_hyp + 1):
        p = pval[i - 1]  # pval starts from pval[0]

        # calculate significance level alpha

        if tau == 0:
            level = gamma_vec[i - 1 - candidacy] * InitWealth * weight[i - 1]
        else:
            level = gamma_vec[i - 1 - tau - candidacy] * rewards * weight[i - 1]
            rewards = (1 - lambda_) * desireLevel
        level = min(level, nd.array([lambda_]))

        # calculate C_j+ (recording the number of candidates)
        if p <= lambda_:
            candidacy = candidacy + 1

        # compare alpha to current wealth
        if p > lambda_ and wealth[i - 1] < level:
            alpha.append(wealth[i - 1])
            wealth.append(nd.array([0]))
        elif p > lambda_:
            alpha.append(level)
            wealth.append(wealth[i - 1] - level)  # In SAFFRON, alpha[i] = phi[i] is the pay-out for each test
        else:
            alpha.append(level)
            wealth.append(wealth[i - 1])  # In SAFFRON, testing a candidacy will never lose wealth

        # perform current test
        if p <= alpha[i]:
            tau = i
            D += 1
            candidacy = 0
            wealth[i] = wealth[i] + rewards
            if H[i - 1] == 0:
                Error += 1
            else:
                Power += 1

        Non_nulls += (H[i - 1] == 1)

        if tau != 0:
            DP.append(D * 1.0 / i)  # record discovery proportion at time i after first discovery
            TDP.append(Power * 1.0 / max(Non_nulls, 1))  # record exact TDP

        FDP.append(Error * 1.0 / max(D, 1))  # record exact FDP

    alpha = alpha[1:]
    alpha = nd.stack(*alpha)

    return alpha, D, DP, TDP, FDP

