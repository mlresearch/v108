import sys, math
sys.path.append('..')
from mxnet import autograd, gluon, init, nd
from mxnet.gluon import loss as gloss, nn, rnn, utils as gutils
import numpy as np
import time
import pandas as pd
from scipy.stats import norm

# Randomly generate a contextual feature matrix of dimension (num_hyp*dim) from Normal(mu, sigma)
# Each row of the matrix represents a vector of contextual features of each hypothesis

def generate_features(num_hyp, dim, mu, sigma):
    X = []
    for i in range(num_hyp):
        X.append(np.random.normal(mu[i], sigma, dim))
    X = nd.array(X)
    return X

desireLevel = 0.1 # the pre-assigned level alpha under which we desire to control FDR
num_hyp = 10**5  # total number of hypotheses
InitWealth = 0.045 # initial wealth w0
dim = 10 # number of dimensions of contextual features
frac1 = 0.4
H = np.random.binomial(1, frac1, num_hyp)
mu = 1 * H
print(mu[1])

X = generate_features(num_hyp, dim, mu, 1)


# Take a linear combination of contextual features as X*beta

def comb_features(X, beta):
    X_comb = nd.dot(X, beta.T)
    return X_comb


# Generate hypothesis H and compute corresponding pvalues

def generate_pval(num_hyp, H, means):
    # num_hyp is total number of hypotheses
    # frac1 is the fraction of true alternative
    # means is a vector of means under althernative
    
#    H = np.random.binomial(1, frac1, num_hyp) # randomly generate H from binomial distribution with parameter frac1.
    H = nd.array(H)
    center = math.sqrt(2 * math.log(num_hyp)) * nd.multiply(H, means) # centers of normal distributions are H*means
    Z = []
    for i in range(num_hyp):
        # generate Z statistic from normal distribution under each hypothesis H
        Z.append(abs(nd.random.normal(center[i].asscalar(), 1, 1).asscalar())) 
    P = nd.array(2*(1 - norm.cdf(Z)))
    return H, P


