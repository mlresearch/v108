# How to run ?

Use `python main.py digits` to get the results for the MNIST digits 
dataset and `python main.py fashion` for the Fashion-MNIST dataset.

# Datasets

* MNIST digits dataset from (https://www.tensorflow.org/probability).
* Fashion-MNIST from (https://www.kaggle.com/zalando-research/fashionmnist#fashion-mnist_train.csv).
