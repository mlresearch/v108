Run the script `start_all.sh` to start all of the experiments.
