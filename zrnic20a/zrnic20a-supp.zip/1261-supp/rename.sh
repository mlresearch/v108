PLOTS=out

for EXT in png pkl
do
    mkdir -p $PLOTS/${EXT}s
done


for TASK in mean3 mean0
do
    for TESTERS in bbh bsbh bh sbh
    do
        for EXT in png pkl
        do
            cp $PLOTS/$TASK-$TESTERS/pi1s.$EXT $PLOTS/${EXT}s/${TASK}_${TESTERS}_pi1s.$EXT
        done
    done
done


for TASK in mean3 mean0
do
    for TESTERS in bbh bsbh
    do
        for EXT in png pkl
        do
            cp $PLOTS/$TASK-$TESTERS/pi1_10.$EXT $PLOTS/${EXT}s/${TASK}_${TESTERS}_pi1_1.$EXT
            cp $PLOTS/$TASK-$TESTERS/pi1_50.$EXT $PLOTS/${EXT}s/${TASK}_${TESTERS}_pi1_5.$EXT
            cp $PLOTS/$TASK-$TESTERS/monotone.$EXT $PLOTS/${EXT}s/monotone_${TASK}_${TESTERS}.$EXT
        done
    done
done
