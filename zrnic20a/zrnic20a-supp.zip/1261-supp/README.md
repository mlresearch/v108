## Setup

This code was developed using python 3.7.3. The code would likely run with anything as new as or newer than python 3.6, but this is untested. For the remainder of the README, `pip` refers to your pip installation for python3, and `python3` refers to your installation of python3.

The required packages are in `requirements.txt` and can be installed through pip with `pip install -r requirements.txt`.
Before installing the packages, you may want to create a virtual environment using [conda](https://docs.conda.io/projects/conda/en/latest/user-guide/tasks/manage-environments.html) or another tool in order to avoid overwriting any of your current python packages.


## Usage

The following steps will generate/save the plots and print the tables to standard out.

1. Clone the repo.
2. Download the `creditcard.csv` file from [Kaggle](https://www.kaggle.com/mlg-ulb/creditcardfraud) and place the file in the top level directory of the repo.
3. Run `python creditcard.py [--n-cpus CPUS]`, where `CPUS` is the number of cpus you would like to use. If `--n-cpus` is not present, the code will use all available cpus.
4. Run `bash run.sh CPUS`, where `CPUS` is the number of cpus you would like to use. If `CPUS` is not specified, the code will use all available cpus.

### Troubleshooting

Depending on how python is installed on your system, you may have to edit `run.sh` to use your desired python installation.


## Mapping of output files to figures

After running the above steps, use the following mapping to determine which image belongs to which figure in the paper.

| Figure #  | Path |
| --------- | ------------- |
| 1  | `out/imgs/mean3_bh_pi1s.png`  |
| 2  | `out/imgs/mean3_bbh_pi1s.png`  |
| 3  | `out/imgs/mean3_bsbh_pi1s.png`  |
| 4  | `out/imgs/mean3_bh_pi1s.png`  |
| 5  | `out/imgs/mean3_sbh_pi1s.png`  |
| 6  | `out/imgs/mean0_bbh_pi1s.png`  |
| 7  | `out/imgs/mean0_bsbh_pi1s.png`  |
| 8  | `out/imgs/mean0_bh_pi1s.png`  |
| 9  | `out/imgs/mean0_sbh_pi1s.png`  |

Use the following mapping to determine which image belongs to which figure in the appendix.

| Figure #  | Path |
| --------- | ------------- |
| 1  | `out/imgs/mean3_bbh_pi1_1.png`  |
| 2  | `out/imgs/mean3_bsbh_pi1_1.png`  |
| 3  | `out/imgs/mean3_bbh_pi1_5.png`  |
| 4  | `out/imgs/mean3_bsbh_pi1_5.png`  |
| 5  | `out/imgs/monotone_mean3_bbh.png`, `out/imgs/monotone_mean3_bsbh.png`  |
| 6  | `out/imgs/monotone_mean0_bbh.png`, `out/imgs/monotone_mean0_bsbh.png`  |

