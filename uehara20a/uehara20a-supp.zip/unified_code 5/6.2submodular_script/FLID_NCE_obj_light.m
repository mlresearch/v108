function [f,grad] = FLID_NCE_obj_light(params,x,suppx,y,suppy,q)
    N = sum(x);
    M = sum(y);
    V = length(q);
    L = (length(params)-1)/V-1;
    u = params(1:V);
    W = reshape(exp(params(V+1:V+V*L)),V,L);
    c = params(V+V*L+1);
    f = 0;
    grad = zeros(length(params),1);
    supp = union(suppx,suppy);
    tmp = x;
    x = zeros(1,length(supp));
    for i=1:length(suppx)
        x(find(supp==suppx(i))) = tmp(i);
    end
    tmp = y;
    y = zeros(1,length(supp));
    for i=1:length(suppy)
        y(find(supp==suppy(i))) = tmp(i);
    end
    for i=1:length(supp)
        b = dec2bin(supp(i)-1,V)-'0';
        n = 1;
        sumu = 0;
        subW = zeros(sum(b),L);
        ind = zeros(1,sum(b));
        k = 1;
        for j=1:V
            if b(V-j+1)>0
                n = n*q(j);
                sumu = sumu+u(j);
                subW(k,:) = W(j,:);
                ind(k) = j;
                k = k+1;
            else
                n = n*(1-q(j));
            end
        end
        if size(subW,1)>1
            divS = sum(max(subW)-sum(subW));
        else
            divS = 0;
        end
        p = exp(sumu+divS+c);
        f = f+x(i)*(log(N*p)-log(N*p+M*n))+y(i)*(-log(N*p+M*n));
        for j=1:V
            if b(V-j+1)>0
                grad(j) = grad(j)+x(i)*(1-N*p/(N*p+M*n))+y(i)*(-N*p/(N*p+M*n));
                grad(V+j:V:V+V*L) = grad(V+j:V:V+V*L)+x(i)*(-1+N*p/(N*p+M*n))+y(i)*(N*p/(N*p+M*n));
            end
        end
        for d=1:L
            [tmp,k] = max(subW(:,d));
            grad(V+(d-1)*V+ind(k)) = grad(V+(d-1)*V+ind(k))-x(i)*(-1+N*p/(N*p+M*n))-y(i)*(N*p/(N*p+M*n));
        end
        grad(V+V*L+1) = grad(V+V*L+1)+x(i)*(1-N*p/(N*p+M*n))+y(i)*(-N*p/(N*p+M*n));
    end
    f = -f;
    grad(V+1:V+V*L) = reshape(W,V*L,1).*grad(V+1:V+V*L);
    grad = -grad;
end

