function KL = FLID_KL_light(p1,u2,W2)
    V = size(W2,1);
    L = size(W2,2);
    p2 = zeros(1,2^V);
    for i=1:2^V
        b = dec2bin(i-1,V)-'0';
        sumu = 0;
        subW = zeros(sum(b),L);
        ind = zeros(1,sum(b));
        k = 1;
        for j=1:V
            if b(V-j+1)>0
                sumu = sumu+u2(j);
                subW(k,:) = W2(j,:);
                ind(k) = j;
                k = k+1;
            end
        end
        if size(subW,1)>1
            divS = sum(max(subW)-sum(subW));
        else
            divS = 0;
        end
        p2(i) = exp(sumu+divS);
    end
    p2 = p2/sum(p2);
    KL = sum(p1.*log(p1./p2));
end

