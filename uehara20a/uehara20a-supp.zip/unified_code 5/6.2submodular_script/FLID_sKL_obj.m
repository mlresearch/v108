function [f,grad] = FLID_sKL_obj(params,x,suppx,V)
    N = sum(x);
    L = (length(params)-1)/V-1;
    u = params(1:V);
    W = reshape(exp(params(V+1:V+V*L)),V,L);
    c = params(V+V*L+1);
    f = 0;
    grad = zeros(length(params),1);
    for i=1:length(suppx)
        b = dec2bin(suppx(i)-1,V)-'0';
        n = x(i)/N;
        sumu = 0;
        subW = zeros(sum(b),L);
        ind = zeros(1,sum(b));
        k = 1;
        for j=1:V
            if b(V-j+1)>0
                sumu = sumu+u(j);
                subW(k,:) = W(j,:);
                ind(k) = j;
                k = k+1;
            end
        end
        if size(subW,1)>1
            divS = sum(max(subW)-sum(subW));
        else
            divS = 0;
        end
        p = exp(sumu+divS+c);
        f = f-x(i)*(log(p)-p/n);
        for j=1:V
            if b(V-j+1)>0
                grad(j) = grad(j)-x(i)*(1-p/n);
                grad(V+j:V:V+V*L) = grad(V+j:V:V+V*L)+x(i)*(1-p/n);
            end
        end
        for d=1:L
            [tmp,k] = max(subW(:,d));
            grad(V+(d-1)*V+ind(k)) = grad(V+(d-1)*V+ind(k))-x(i)*(1-p/n);
        end
        grad(V+V*L+1) = grad(V+V*L+1)-x(i)*(1-p/n);
    end
    grad(V+1:V+V*L) = reshape(W,V*L,1).*grad(V+1:V+V*L);
end

