nmc = 1;
NUM_INIT = 10;
V = 12;
L = 2;
u = rand(V,1);
W = rand(V,L);
p = zeros(1,2^V);
for i=1:2^V
    b = dec2bin(i-1,V)-'0';
    sumu = 0;
    subW = zeros(sum(b),L);
    k = 1;
    for j=1:V
        if b(V-j+1)>0
            sumu = sumu+u(j);
            subW(k,:) = W(j,:);
            k = k+1;
        end
    end
    if size(subW,1)>1
        divS = sum(max(subW)-sum(subW));
    else
        divS = 0;
    end
    p(i) = exp(sumu+divS);
end
c = -log(sum(p));
p = p/sum(p);
ns = [500 1000 2000]*100;
u_est_NCE = zeros(V,nmc,length(ns));
W_est_NCE = zeros(V,L,nmc,length(ns));
time_NCE = zeros(nmc,length(ns));
u_est_sKL = zeros(V,nmc,length(ns));
W_est_sKL = zeros(V,L,nmc,length(ns));
time_sKL = zeros(nmc,length(ns));
u_est_gamma = zeros(V,nmc,length(ns));
W_est_gamma = zeros(V,L,nmc,length(ns));
time_gamma = zeros(nmc,length(ns));
for ins=1:length(ns)
    n = ns(ins);
    m = n;
    for mc=1:nmc
        ins,mc
        x = mnrnd(n,p);
        suppx = find(x>0);
        x = x(suppx);
        tic
        cnt = zeros(1,V);
        for i=1:length(suppx)
            b = dec2bin(suppx(i)-1,V)-'0';
            cnt(b==1) = cnt(b==1)+x(i);
        end
        cnt = fliplr(cnt);
        q = cnt/n;
        S = binornd(ones(m,V),ones(m,1)*q);
        tmp = S*2.^[0:V-1]'+1;
        suppy = unique(sort(tmp))';
        y = cell2mat(arrayfun(@(x)length(find(tmp == x)), suppy, 'Uniform', false));
        minobj = inf;
        update = 1;
        for kk=1:NUM_INIT
%            est_tmp = minimize_noshow([log(q./(1-q)) log(.001*rand(1,V*L)) sum(log(1-q))]','FLID_NCE_obj_light',10000,x,suppx,y,suppy,q);
            est_tmp = minimize([u; reshape(W,V*L,1); c],'FLID_NCE_obj_light',10000,x,suppx,y,suppy,q);
            tmp = FLID_NCE_obj_light(est_tmp,x,suppx,y,suppy,q);
            if tmp < minobj
                update = update+1;
                minobj = tmp;
                est = est_tmp;
            end
        end
        update;
        u_est_NCE(:,mc,ins) = est(1:V);
        W_est_NCE(:,:,mc,ins) = reshape(exp(est(V+1:V+V*L)),V,L);
        est(end)
        time_NCE(mc,ins) = toc;
        tic
        minobj = inf;
        update = 1;
        for kk=1:NUM_INIT
            est_tmp = minimize([u; reshape(W,V*L,1); c],'FLID_sKL_obj',10000,x,suppx,V);
            tmp = FLID_sKL_obj(est_tmp,x,suppx,V);
            if tmp < minobj
                update = update+1;
                minobj = tmp;
                est = est_tmp;
            end
        end
        update;
        u_est_sKL(:,mc,ins) = est(1:V);
        W_est_sKL(:,:,mc,ins) = reshape(exp(est(V+1:V+V*L)),V,L);
        time_sKL(mc,ins) = toc;
        tic
        alpha = 1.01;
        alphap = 0.01;
        gam = -(alpha-1)/(alphap-1);
        minobj = inf;
        update = 1;
        for kk=1:NUM_INIT
            est_tmp = minimize([u; reshape(W,V*L,1)],'FLID_gamma_obj',10000,x,suppx,alpha,alphap,gam,V);
            tmp = FLID_gamma_obj(est_tmp,x,suppx,alpha,alphap,gam,V);
            if tmp < minobj
                update = update+1;
                minobj = tmp;
                est = est_tmp;
            end
        end
        update;
        u_est_gamma(:,mc,ins) = est(1:V);
        W_est_gamma(:,:,mc,ins) = reshape(exp(est(V+1:V+V*L)),V,L);
        time_gamma(mc,ins) = toc;
    end
    save('FLID_large')
end
KL_NCE = zeros(1,length(ns));
KL_sKL = zeros(1,length(ns));
KL_gamma = zeros(1,length(ns));
KL_NCE_std = zeros(1,length(ns));
KL_sKL_std = zeros(1,length(ns));
KL_gamma_std = zeros(1,length(ns));
KLs = zeros(1,nmc);
for ins=1:length(ns)
    ins
    KLs = inf*ones(1,nmc);
    for mc=1:nmc
        mc
        KLs(mc) = FLID_KL_light(p,u_est_NCE(:,mc,ins),W_est_NCE(:,:,mc,ins));
    end
    KL_NCE(ins) = mean(KLs);
    KL_NCE_std(ins) = std(KLs);
    KLs = inf*ones(1,nmc);
    for mc=1:nmc
        mc
        KLs(mc) = FLID_KL_light(p,u_est_sKL(:,mc,ins),W_est_sKL(:,:,mc,ins));
    end
    KL_sKL(ins) = mean(KLs);
    KL_sKL_std(ins) = std(KLs);
    KLs = inf*ones(1,nmc);
    for mc=1:nmc
        mc
        KLs(mc) = FLID_KL_light(p,u_est_gamma(:,mc,ins),W_est_gamma(:,:,mc,ins));
    end
    KL_gamma(ins) = mean(KLs);
    KL_gamma_std(ins) = std(KLs);
end
KL_NCE
KL_sKL
KL_gamma
save('FLID_large')
