function [f,grad] = FLID_gamma_obj(params,x,suppx,alpha,alphap,gam,V)
    N = sum(x);
    L = length(params)/V-1;
    u = params(1:V);
    W = reshape(exp(params(V+1:V+V*L)),V,L);
    alphab = (alpha+gam*alphap)/(1+gam);
    f1 = 0;
    f2 = 0;
    f3 = 0;
    grad1 = zeros(length(params),1);
    grad2 = zeros(length(params),1);
    grad3 = zeros(length(params),1);
    for i=1:length(suppx)
        b = dec2bin(suppx(i)-1,V)-'0';
        sumu = 0;
        subW = zeros(sum(b),L);
        ind = zeros(1,sum(b));
        k = 1;
        for j=1:V
            if b(V-j+1)>0
                sumu = sumu+u(j);
                subW(k,:) = W(j,:);
                ind(k) = j;
                k = k+1;
            end
        end
        if size(subW,1)>1
            divS = sum(max(subW)-sum(subW));
        else
            divS = 0;
        end
        p = exp(sumu+divS);
        f1 = f1+(x(i)/N)^alpha*p^(1-alpha);
        f2 = f2+(x(i)/N)^alphap*p^(1-alphap);
        f3 = f3+(x(i)/N)^alphab*p^(1-alphab);
        for j=1:V
            if b(V-j+1)>0
                grad1(j) = grad1(j)+(x(i)/N)^alpha*(1-alpha)*p^(1-alpha);
                grad1(V+j:V:V+V*L) = grad1(V+j:V:V+V*L)-(x(i)/N)^alpha*(1-alpha)*p^(1-alpha);
                grad2(j) = grad2(j)+(x(i)/N)^alphap*(1-alphap)*p^(1-alphap);
                grad2(V+j:V:V+V*L) = grad2(V+j:V:V+V*L)-(x(i)/N)^alphap*(1-alphap)*p^(1-alphap);
                grad3(j) = grad3(j)+(x(i)/N)^alphab*(1-alphab)*p^(1-alphab);
                grad3(V+j:V:V+V*L) = grad3(V+j:V:V+V*L)-(x(i)/N)^alphab*(1-alphab)*p^(1-alphab);
            end
        end
        for d=1:L
            [tmp,k] = max(subW(:,d));
            grad1(V+(d-1)*V+ind(k)) = grad1(V+(d-1)*V+ind(k))+(x(i)/N)^alpha*(1-alpha)*p^(1-alpha);
            grad2(V+(d-1)*V+ind(k)) = grad2(V+(d-1)*V+ind(k))+(x(i)/N)^alphap*(1-alphap)*p^(1-alphap);
            grad3(V+(d-1)*V+ind(k)) = grad3(V+(d-1)*V+ind(k))+(x(i)/N)^alphab*(1-alphab)*p^(1-alphab);
        end
    end
    f = log(f1)/(1+gam)+log(f2)*gam/(1+gam)-log(f3);
    grad = grad1/f1/(1+gam)+grad2/f2*gam/(1+gam)-grad3/f3;
    grad(V+1:V+V*L) = reshape(W,V*L,1).*grad(V+1:V+V*L);
end

