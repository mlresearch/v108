
sigmoid <- function(z)
  1/(1+exp(-z))

bin_allvec <- function(d){
  ph <- c(1,-1)
  for(k in 1:(d-1)){
    ph <- rbind(cbind(ph,1),cbind(ph,-1))
  }
  ph
}

## exp(v^T W h)
dataGen_rbm <- function(W, nsample=1, iteration=1000){
  vmat <- c()
  dimv <- nrow(W); dimh <- ncol(W)
  vmat <- foreach(n=1:nsample, .combine=rbind)%dopar%{
    v <- sample(c(-1,1),dimv,replace=TRUE)
    for (ii in 1:iteration){
      ## v -> h
      h <- c(sign(sigmoid(2 * v %*% W) - runif(dimh)))
      ## h -> v
      v <- c(sign(sigmoid(2 * W%*%h) - runif(dimv)))
    }
    v
  }
  vmat
}


empirical_dist <- function(x){
  n <- nrow(x); dimv <- ncol(x)  
  decx <- as.vector(colSums(t(x>0) * 2^((1:dimv)-1)))
  tblx <- table(decx); tbl_idx <- as.integer(names(tblx))
  uniq_x <- foreach(i=1:length(tblx),.combine=rbind)%dopar%{
    x[which(tbl_idx[i]==decx)[1],]
  }
  emp_pr <- as.double(tblx/n)
  list(x=uniq_x, pr=emp_pr)
}

## f: 2x log x-2(1+x) log(1+x)
JS_rbm <- function(uniq_x, emp_pr, dimh=2, multistart=3, optim_method="BFGS", maxit=1000){
  dimv <- ncol(uniq_x)
  Loss <- function(tau){
    nc <- tau[1]; W <- matrix(tau[-1],dimv,dimh)
    ## log(q/eta) for each x in uniq_x
    logRatio <- c(-nc + rowSums(log(cosh(uniq_x %*% W))) - log(emp_pr))
    loss <- sum(emp_pr * (-2*logRatio + 4 * apply(cbind(0,logRatio),1,logSumExp)))
    loss
  }
  DLoss <- function(tau){
    nc <- tau[1]; W <- matrix(tau[-1],dimv,dimh)
    ## log(q/eta) for each x in uniq_x
    logRatio <- c(-nc + rowSums(log(cosh(uniq_x %*% W))) - log(emp_pr))
    ## dim: length(uniq_x)
    Ratio <- exp(logRatio)
    weight <- 2*(Ratio-1)/(Ratio+1) * emp_pr
    c(-sum(weight), c(t(uniq_x * weight) %*% tanh(uniq_x %*% W)))
  }
  op_itr <- foreach(j=1:multistart)%dopar%{
    tau <- rep(rnorm(dimv*dimh+1,sd=1/(dimv*dimh)))
    optim(tau, fn=Loss, gr=DLoss, method=optim_method, control = list(maxit = maxit))
  }
  optval <- Inf
  for(i in 1:multistart){
    if(optval > op_itr[[i]]$value){
      optidx <- i
      optval <- op_itr[[i]]$value
      op <- op_itr[[optidx]]
    }
  }
  estc <- op$par[1]
  estW <- matrix(op$par[-1],dimv,dimh)
  list(c=estc, W=estW, op=op)
}


## f: x log x
KL_rbm <- function(uniq_x, emp_pr, dimh=2, multistart=3, optim_method="BFGS", maxit=1000){
  dimv <- ncol(uniq_x)
  Loss <- function(tau){
    nc <- tau[1]; W <- matrix(tau[-1],dimv,dimh)
    ## log(q/eta) for each x in uniq_x
    logRatio <- c(-nc + rowSums(log(cosh(uniq_x %*% W))) - log(emp_pr))
    loss <- sum(emp_pr * (-1+exp(logRatio)-logRatio))
    loss
  }
  DLoss <- function(tau){
    nc <- tau[1]; W <- matrix(tau[-1],dimv,dimh)
    ## log(q/eta) for each x in uniq_x
    logRatio <- c(-nc + rowSums(log(cosh(uniq_x %*% W))) - log(emp_pr))
    ## dim: length(uniq_x)
    weight <- (exp(logRatio)-1) * emp_pr
    c(-sum(weight), c(t(uniq_x * weight) %*% tanh(uniq_x %*% W)))
  }
  op_itr <- foreach(j=1:multistart)%dopar%{
    tau <- rep(rnorm(dimv*dimh+1,sd=1/(dimv*dimh)))
    optim(tau, fn=Loss, gr=DLoss, method=optim_method, control = list(maxit = maxit))
  }
  optval <- Inf
  for(i in 1:multistart){
    if(optval > op_itr[[i]]$value){
      optidx <- i
      optval <- op_itr[[i]]$value
      op <- op_itr[[optidx]]
    }
  }
  estc <- op$par[1]
  estW <- matrix(op$par[-1],dimv,dimh)
  list(c=estc, W=estW, op=op)
}


## f: x^2/2
Chi_rbm <- function(uniq_x, emp_pr, dimh=2, multistart=3, optim_method="BFGS", maxit=1000){
  dimv <- ncol(uniq_x)
  Loss <- function(tau){
    nc <- tau[1]; W <- matrix(tau[-1],dimv,dimh)
    ## log(q/eta) for each x in uniq_x
    logRatio <- c(-nc + rowSums(log(cosh(uniq_x %*% W))) - log(emp_pr))
    Ratio <- exp(logRatio)
    loss <- sum(emp_pr * (-Ratio + Ratio^2/2))
    loss
  }
  DLoss <- function(tau){
    nc <- tau[1]; W <- matrix(tau[-1],dimv,dimh)
    ## log(q/eta) for each x in uniq_x
    logRatio <- c(-nc + rowSums(log(cosh(uniq_x %*% W))) - log(emp_pr))
    ## dim: length(uniq_x)
    Ratio <- exp(logRatio)
    weight <- Ratio*(Ratio-1) * emp_pr
    c(-sum(weight), c(t(uniq_x * weight) %*% tanh(uniq_x %*% W)))
  }
  op_itr <- foreach(j=1:multistart)%dopar%{
    tau <- rep(rnorm(dimv*dimh+1,sd=1/(dimv*dimh)))
    optim(tau, fn=Loss, gr=DLoss, method=optim_method, control = list(maxit = maxit))
  }
  optval <- Inf
  for(i in 1:multistart){
    if(optval > op_itr[[i]]$value){
      optidx <- i
      optval <- op_itr[[i]]$value
      op <- op_itr[[optidx]]
    }
  }
  estc <- op$par[1]
  estW <- matrix(op$par[-1],dimv,dimh)
  list(c=estc, W=estW, op=op)
}


MLE_rbm <- function(uniq_x, emp_pr, dimh=2, multistart=3, optim_method="BFGS", maxit=1000){
  dimv <- ncol(uniq_x); ph <- bin_allvec(dimh); pv <- bin_allvec(dimv)
  ##
  Loss <- function(tau){
    W <- matrix(tau,dimv,dimh)
    logq <- log(cosh(pv %*% W))
    lognc <- log(sum(exp(rowSums(logq))))
    logProb <- rowSums(log(cosh(uniq_x %*% W)))-lognc
    -sum(emp_pr * logProb)
  }
  DLoss <- function(tau){
    W <- matrix(tau,dimv,dimh)
    grA <- t(uniq_x * emp_pr) %*% tanh(uniq_x %*% W)
    logq <- log(cosh(pv %*% W))
    lognc <- log(sum(exp(rowSums(logq))))
    grB <- t(pv * exp(rowSums(logq))) %*% tanh(pv %*% W)/exp(lognc)
    c(-(grA - grB))
  }
  ## 
  op_itr <- foreach(j=1:multistart)%dopar%{
    tau <- rep(rnorm(dimv*dimh,sd=1/(dimv*dimh)))
    optim(tau, fn=Loss, gr=DLoss, method=optim_method, control = list(maxit = maxit))
  }
  optval <- Inf
  for(i in 1:multistart){
    if(optval > op_itr[[i]]$value){
      optidx <- i
      optval <- op_itr[[i]]$value
      op <- op_itr[[optidx]]
    }
  }
  list(W=matrix(op$par,dimv,dimh),op=op)
}


ContDiv_rbm <- function(uniq_x, emp_pr, dimh=2, multistart=3, optim_method="BFGS", nMCMC=1000, maxit=100){
  dimv <- ncol(uniq_x)
  Loss <- function(tau){
    W  <- matrix(tau,dimv,dimh)
    lossA <- sum(emp_pr * rowSums(log(cosh(uniq_x %*% W))))
    mx <- dataGen_rbm(W, nsample=nMCMC, iteration=1)
    logq  <- log(cosh(mx %*% W))
    lossB <- log(sum(exp(rowSums(logq))))
    -lossA + lossB
  }
  DLoss <- function(tau){
    W <- matrix(tau,dimv,dimh)
    grA <- t(uniq_x * emp_pr) %*% tanh(uniq_x %*% W)
    mx <- dataGen_rbm(W, nsample=nMCMC, iteration=10)
    grB <- t(mx) %*% tanh(mx %*% W) / nMCMC
    c(-grA + grB)
  }
  op_itr <- foreach(j=1:multistart)%dopar%{
    tau <- rep(rnorm(dimv*dimh,sd=1/(dimv*dimh)))
    optim(tau, fn=Loss, gr=DLoss, method=optim_method, control = list(maxit = maxit))
  }
  optval <- Inf
  for(i in 1:multistart){
    if(optval > op_itr[[i]]$value){
      optidx <- i
      optval <- op_itr[[i]]$value
      op <- op_itr[[optidx]]
    }
  }
  list(W=matrix(op$par,dimv,dimh),op=op)
}
