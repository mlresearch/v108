## usage:
## > source('calc-RBM.r')

library(doParallel)
library(matrixStats)

source('func.r')

## parallel computing setup
registerDoParallel(detectCores())

## parameter setting
dimv <- 5; dimh <- 2;   ## dim of v, dim of h
n <- 1000               ## number of samples
iterate <- 50           ## iterations of simulation
optim_method <- "L-BFGS-B"  ## optimization algorithm
multistart <- 1         ## num. of multistart points

cat('\n')
cat('dimV: ',dimv,'\n')
cat('dimH: ',dimh,'\n')
cat('dim of model/prob : ', dimv*dimh,'/',2^dimv-1,'\n',sep='')
cat('                 n: ',n,'\n')
cat('        iterations: ',iterate,'\n')
cat('\n')

ph <- bin_allvec(dimh); pv <- bin_allvec(dimv)

res <- foreach(ii=1:iterate, .combine=rbind)%dopar%{
  ## cat(ii,'\n')
  tKLerr <- c(); ttime <- c()
  W <- matrix(rnorm(dimv*dimh, sd=0.5),dimv,dimh)
  upr <- rowSums(exp(pv %*% W %*% t(ph)))
  pr <- upr/sum(upr)

  x <- dataGen_rbm(W,n)
  emp <- empirical_dist(x)
  uniq_x <- emp$x
  emp_pr <- emp$pr

  ## estimator: JS-div unnormalized
  systemtime <- system.time(est <- JS_rbm(uniq_x, emp_pr, dimh=dimh, multistart=multistart, optim_method=optim_method))[3]
  upr <- rowSums(exp(pv %*% est$W %*% t(ph)))
  est_pr <- upr/sum(upr)
  fullest_pr <- upr/exp(est$c)
  tKLerr <- c(tKLerr, sum(pr*log(pr/est_pr)))
  ttime  <- c(ttime, systemtime)
  
  ## estimator: KL-div unnormalized
  systemtime <- system.time(est <- KL_rbm(uniq_x, emp_pr, dimh=dimh, multistart=multistart, optim_method=optim_method))[3]
  upr <- rowSums(exp(pv %*% est$W %*% t(ph)))
  est_pr <- upr/sum(upr)
  fullest_pr <- upr/exp(est$c)
  tKLerr <- c(tKLerr, sum(pr*log(pr/est_pr)))
  ttime <- c(ttime, systemtime)

  ## estimator: KL-div unnormalized
  systemtime <- system.time(est <- Chi_rbm(uniq_x, emp_pr, dimh=dimh, multistart=multistart, optim_method=optim_method))[3]
  upr <- rowSums(exp(pv %*% est$W %*% t(ph)))
  est_pr <- upr/sum(upr)
  fullest_pr <- upr/exp(est$c)
  tKLerr <- c(tKLerr, sum(pr*log(pr/est_pr)))
  ttime <- c(ttime, systemtime)
  
  ## estimator: MLE
  systemtime <- system.time(est <- MLE_rbm(uniq_x, emp_pr, dimh=dimh, multistart=multistart, optim_method=optim_method))[3]
  upr <- rowSums(exp(pv %*% est$W %*% t(ph)))
  mle_pr <- upr/sum(upr)
  tKLerr <- c(tKLerr, sum(pr*log(pr/mle_pr)))
  ttime <- c(ttime, systemtime)
  c(tKLerr,ttime)
}


ncomp <- ncol(res)/2
KLerr <- res[,1:ncomp]; Times <- res[,(ncomp+1):ncol(res)]
dimnames(KLerr)[[2]] <- c('s-JS','s-KL','s-Chi','MLE')

## print summary
print(cbind(round(colMeans(KLerr) * n,2),round(apply(KLerr,2,sd) * n,2)))

