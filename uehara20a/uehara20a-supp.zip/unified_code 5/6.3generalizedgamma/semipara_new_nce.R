
#### Experiment Using Generalied Gamma distribtioon with NCE

aaa = 1.3
bbb = 1.3
ccc = 0.0

start_time <- Sys.time()

likelihood <- function(x,a.=aaa,b.=bbb,c.=ccc){
  return(-b.*(x)*(x)+log((x>0.0))+log((x>0.0))+a.*log(abs(x)))
}


number <- 2000
out <- metrop(likelihood, initial = 2.0, nbatch = number, blen=1, scale=0.2)
hist(out$batch)

ite <- 500
theta_list <- matrix(seq(0,0,length.out = 2*ite),ite,2)
theta_list2 <- matrix(seq(0,0,length.out = 2*ite),ite,2)

###mu <- c(0,0)                         # Mean
####Sigma <- matrix(c(1.2, 0.0, 0.0, 1.2), 2,2)  # Covariance matrix

for(jjj in 1:ite){
  print(jjj)
  out <- metrop(likelihood, initial = 0.9, nbatch = (200+number), blen=1, scale=0.5)
  sample_new <- out$batch
  sample_new <- matrix(out$batch[200:(200+number)],1,number)
  sample_new <- as.vector(sample_new)
  
  auxi_new <- rtmvnorm(number,mean = 0.0, sigma = 1.6*var(sample_new),lower= 0.0)
  
  log_unnormalized <- function(theta,x){
    return(theta[3]-theta[2]*x*x+theta[1]*log(abs(x))+log((x>0.0)))
  }
  
  auxi_density <- seq(0,0,number)
  for(i in 1:number){
    auxi_density[i] <- dtmvnorm(auxi_new[i],mean = mean(0.0),sigma = 1.6*var(sample_new),lower = 0.0)
  }
  objective <- function(theta,sample.=sample_new,auxi.=auxi_new,auxi_density.=auxi_density){
    
    a <- 0.0 
    for(i in 1:number){
      a <- a-1.0/number*log_unnormalized(theta,sample.[i]) 
    }
    
    for(i in 1:number){
      a <- a + 1.0/number*exp(log_unnormalized(theta,auxi.[i]))/auxi_density.[i]
    }
    return(a)
  }
  answer <- optim(c(1.0,3.0,3.0),objective,lower = c(0.1,0.1,-10.0), method="L-BFGS-B")
  theta_list[jjj,] <- answer$par[1:2]
}

dis <- function(x){
  return(x-c(1.3,1.3))
}
mean(apply(apply(theta_list,1,dis)*apply(theta_list,1,dis),2,sum))*number
sqrt(var(apply(apply(theta_list,1,dis)*apply(theta_list,1,dis),2,sum)))
end_time <- Sys.time()
end_time - start_time
#### 
#####hist(apply(apply(theta_list,1,dis)*apply(theta_list,1,dis),2,sum),breaks = 20,xlab="value",main="Histgram of error")