#### Experiment Using Generalied Gamma distribtioon with ns-gamma

aaa = 1.3
bbb = 1.3
ccc = 0.0


likelihood <- function(x,a.=aaa,b.=bbb,c.=ccc){
  return(-b.*(x)*(x)+log((x>0.0))+log((x>0.0))+a.*log(abs(x)))
}


number <- 500
out <- metrop(likelihood, initial = 0.0, nbatch = number, blen=1, scale=0.4)
hist(out$batch)

ite <- 500
theta_list <- matrix(seq(0,0,length.out = 2*ite),ite,2)
theta_list2 <- matrix(seq(0,0,length.out = 2*ite),ite,2)

###mu <- c(0,0)                         # Mean
####Sigma <- matrix(c(1.2, 0.0, 0.0, 1.2), 2,2)  # Covariance matrix

for(jjj in 1:ite){
  print(jjj)
  out <- metrop(likelihood, initial = 0.9, nbatch = (200+number), blen=1, scale=0.5)
  sample_new <- out$batch
  sample_new <- matrix(out$batch[200:(200+number)],1,number)
  sample_new <- as.vector(sample_new)
  density <- npudensbw(sample_new,ckerorder=6)
  density1 <- predict(density, newdata=sample_new)
  ###density_value <- density1
  density_value <- density1$dens
  ####density_value <- dnorm(sa`12mple,0.0,1.0)
  plot(sample_new,density_value)
  ####density_value <- dmvnorm(sample_multi,mean = mu, sigma = Sigma)
  
  log_unnormalized <- function(theta,x){
    return(-theta[2]*x*x-log((x>0.0))+theta[1]*log(abs(x)))
  }
  
  Alpha <- 1.01
  Beta <- 0.01
  Gamma <- -Alpha/Beta+1
  
  objective <- function(theta,sample.=sample_new,density_value.=density_value){
    d <- seq(0,0,length.out = number)
    
    for(i in 1:number){
      d[i] <- exp(log_unnormalized(theta,sample.[i])-log(abs(density_value.[i])+0.0000001))
    }
   a1 <- 0.0
   for(i in 1:number){
     a1 <- a1 + d[i]**Alpha
   }
   
  a2 <- 0.0
  for(i in 1:number){
    a2 <- a2 + d[i]**Beta
  }
    return(1.0/Gamma*log(a1)+(Gamma-1)/Gamma*log(a2))
  }
  
  answer <- optim(c(2.0,2.0),objective,lower = c(0.1,0.1), method="L-BFGS-B")
  theta_list[jjj,] <- answer$par
}

dis <- function(x){
  return(x-c(1.3,1.3))
}
apply(apply(theta_list,1,dis)*apply(theta_list,1,dis),1,median)
apply(apply(theta_list,1,dis)*apply(theta_list,1,dis),1,mean)

sum(apply(apply(theta_list,1,dis)*apply(theta_list,1,dis),1,mean))*number
sum(sqrt(apply(apply(theta_list,1,dis)*apply(theta_list,1,dis),1,var)))*number
#### 
#####hist(apply(apply(theta_list,1,dis)*apply(theta_list,1,dis),2,sum),breaks = 20,xlab="value",main="Histgram of error")