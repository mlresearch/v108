#### Experiment Using Generalied Gamma distribtioon with s-KL

aaa = 1.3
bbb = 1.3
ccc = 0.0

likelihood <- function(x,a.=aaa,b.=bbb,c.=ccc){
  return(-b.*(x)*(x)-c.*x+log((x>0.0))+a.*log(abs(x)))
}

number <- 2000
out <- metrop(likelihood, initial = 2.0, nbatch = number, blen=1, scale=0.4)
hist(out$batch)

ite <- 300
theta_list <- matrix(seq(0,0,length.out = 2*ite),ite,2)
theta_list2 <- matrix(seq(0,0,length.out = 2*ite),ite,2)

###mu <- c(0,0)                         # Mean
####Sigma <- matrix(c(1.2, 0.0, 0.0, 1.2), 2,2)  # Covariance matrix

start_time <- Sys.time()

for(jjj in 1:ite){
  print(jjj)
  out <- metrop(likelihood, initial = 0.9, nbatch = (200+number), blen=1, scale=0.5)
  sample_new <- out$batch
  sample_new <- matrix(out$batch[200:(200+number)],1,number)
  sample_new <- as.vector(sample_new)
  density <- npudensbw(sample_new,ckerorder=6,bwmethod = "cv.ml")
  density1 <- predict(density, newdata=sample_new)
  ###density_value <- density1
  density_value <- density1$dens
  ####density_value <- dnorm(sa`12mple,0.0,1.0)
  ####plot(sample_new,density_value)
  ####density_value <- dmvnorm(sample_multi,mean = mu, sigma = Sigma)
  
  log_unnormalized <- function(theta,x){
    return(-theta[2]*x*x-log((x>0.0))+theta[1]*log(abs(x)))
  }
  
  objective <- function(theta,sample.=sample_new,density_value.=density_value){
    c = 0.0
    d <- seq(0,0,length.out = number)
    
    for(i in 1:number){
      d[i] <- log_unnormalized(theta,sample.[i]) 
    }
    
    for(i in 1:number){
      c = c + 1.0/number*exp(d[i])/(density_value.[i])
    }
    
    a = 0.0
    
    for(i in 1:number){
      a = a + 1.0/number * d[i]
      a = a - 1.0/number * log(c)
    }
    return(-a)
  }
  answer <- optim(c(3.0,3.0),objective,lower = c(0.1,0.1), method="L-BFGS-B")
  theta_list[jjj,] <- answer$par
}

dis <- function(x){
  return(x-c(1.3,1.3))
}
apply(apply(theta_list,1,dis)*apply(theta_list,1,dis),1,mean)
sum(apply(apply(theta_list,1,dis)*apply(theta_list,1,dis),1,mean))*number
sqrt(var(apply(apply(theta_list,1,dis)*apply(theta_list,1,dis),2,sum)))*number
end_time <- Sys.time()

end_time - start_time
#### 
#####hist(apply(apply(theta_list,1,dis)*apply(theta_list,1,dis),2,sum),breaks = 20,xlab="value",main="Histgram of error")